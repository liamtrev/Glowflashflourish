<?php @session_start(); ?>
<?php require_once('../connection/localhost.php'); ?>
<?php
// Check if user is logged in
if (!isset($_SESSION['MM_Username'])) {
    header("Location: ../index.php");
    exit;
}

// Get statistics using mysqli
$total_members = $localhost->query("SELECT COUNT(*) as count FROM members_tbl");
$total_members_row = $total_members->fetch_assoc();

$active_members = $localhost->query("SELECT COUNT(*) as count FROM members_tbl WHERE status = 'Active'");
$active_members_row = $active_members->fetch_assoc();

$total_payments = $localhost->query("SELECT SUM(amount) as total FROM payments_tbl WHERE status = 'Paid'");
$total_payments_row = $total_payments->fetch_assoc();

$expiring_soon = $localhost->query("SELECT COUNT(*) as count FROM payments_tbl WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)");
$expiring_row = $expiring_soon->fetch_assoc();

$recent_members = $localhost->query("SELECT * FROM members_tbl ORDER BY id DESC LIMIT 5");

// Get current user
$username = $_SESSION['MM_Username'];
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TABBY'S GYM - Dashboard</title>
<link href="../css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
<style type="text/css">
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #0a0f1e 0%, #1a1f2f 100%);
    min-height: 100vh;
    color: #fff;
}

/* Header Styles */
#header {
    background: rgba(10, 15, 30, 0.95);
    backdrop-filter: blur(10px);
    border-bottom: 2px solid #ffd700;
    padding: 15px 0;
    position: sticky;
    top: 0;
    z-index: 1000;
    box-shadow: 0 2px 20px rgba(255, 215, 0, 0.2);
}

.header-content {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header-content h1 {
    font-size: 32px;
    background: linear-gradient(45deg, #ffd700, #ff6b6b, #4facfe);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    text-transform: uppercase;
    letter-spacing: 3px;
    text-shadow: 0 0 20px rgba(255, 215, 0, 0.3);
}

.user-info {
    display: flex;
    align-items: center;
    gap: 20px;
    background: linear-gradient(135deg, #2a2f3f, #1a1f2f);
    padding: 10px 20px;
    border-radius: 50px;
    border: 1px solid #ffd700;
}

.user-info span {
    color: #4facfe;
    font-weight: bold;
    font-size: 16px;
}

.user-info span i {
    color: #ffd700;
    margin-right: 8px;
}

.logout-btn {
    background: linear-gradient(45deg, #ff6b6b, #ff4757);
    color: white;
    padding: 8px 25px;
    border-radius: 25px;
    text-decoration: none;
    font-weight: bold;
    transition: all 0.3s;
    border: 1px solid #ffd700;
    display: flex;
    align-items: center;
    gap: 8px;
}

.logout-btn i {
    color: #ffd700;
}

.logout-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(255, 107, 107, 0.5);
    background: linear-gradient(45deg, #ff4757, #ff6b6b);
}

/* Container Layout */
#container {
    max-width: 1400px;
    margin: 30px auto;
    padding: 0 30px;
    display: grid;
    grid-template-columns: 280px 1fr;
    gap: 30px;
}

/* Sidebar Styles */
#sidebar {
    background: rgba(20, 25, 40, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 20px;
    padding: 25px 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    border: 1px solid #4facfe;
    height: fit-content;
    position: sticky;
    top: 100px;
}

#sidebar ul {
    list-style: none;
}

#sidebar ul li {
    margin-bottom: 10px;
}

#sidebar ul li a {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 20px;
    color: #ccc;
    text-decoration: none;
    border-radius: 12px;
    transition: all 0.3s;
    font-weight: 500;
}

#sidebar ul li a i {
    width: 24px;
    color: #ffd700;
    font-size: 18px;
}

#sidebar ul li a:hover {
    background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    color: #fff;
    transform: translateX(5px);
    box-shadow: 0 5px 15px rgba(79, 172, 254, 0.4);
}

#sidebar ul li a:hover i {
    color: #fff;
}

#sidebar ul li a.active {
    background: linear-gradient(135deg, #ffd700 0%, #ffb347 100%);
    color: #1a1f2f;
    font-weight: bold;
    box-shadow: 0 5px 20px rgba(255, 215, 0, 0.4);
}

#sidebar ul li a.active i {
    color: #1a1f2f;
}

/* Main Content */
#main-content {
    background: rgba(20, 25, 40, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    border: 1px solid #ffd700;
}

/* Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 25px;
    margin-bottom: 35px;
}

.stat-card {
    padding: 25px;
    border-radius: 15px;
    text-align: center;
    transition: all 0.3s;
    position: relative;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.1);
}

.stat-card::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
    opacity: 0;
    transition: opacity 0.3s;
}

.stat-card:hover::before {
    opacity: 1;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
}

.stat-card:nth-child(1) {
    background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    box-shadow: 0 5px 20px rgba(79, 172, 254, 0.4);
}

.stat-card:nth-child(2) {
    background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
    box-shadow: 0 5px 20px rgba(67, 233, 123, 0.4);
}

.stat-card:nth-child(3) {
    background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
    box-shadow: 0 5px 20px rgba(250, 112, 154, 0.4);
}

.stat-card:nth-child(4) {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
}

.stat-card i {
    font-size: 40px;
    color: rgba(255, 255, 255, 0.3);
    position: absolute;
    top: 10px;
    right: 10px;
}

.stat-card h3 {
    font-size: 18px;
    margin-bottom: 15px;
    color: rgba(255, 255, 255, 0.9);
    text-transform: uppercase;
    letter-spacing: 1px;
}

.stat-card .number {
    font-size: 42px;
    font-weight: bold;
    color: #fff;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
}

/* Recent Members Section */
.recent-members {
    margin-top: 40px;
}

.recent-members h2 {
    color: #ffd700;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 2px solid #4facfe;
    font-size: 28px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.recent-members h2 i {
    color: #4facfe;
    font-size: 28px;
}

/* Table Styles */
.members-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 10px;
}

.members-table thead tr {
    background: linear-gradient(135deg, #2a2f3f, #1a1f2f);
}

.members-table th {
    padding: 15px;
    text-align: left;
    color: #ffd700;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-size: 14px;
    border-bottom: 2px solid #4facfe;
}

.members-table td {
    padding: 15px;
    background: rgba(30, 35, 50, 0.8);
    border-radius: 10px;
    color: #fff;
    transition: all 0.3s;
}

.members-table tbody tr:hover td {
    background: rgba(40, 45, 60, 0.9);
    transform: scale(1.02);
    box-shadow: 0 5px 15px rgba(79, 172, 254, 0.3);
}

.members-table td:first-child {
    border-radius: 10px 0 0 10px;
}

.members-table td:last-child {
    border-radius: 0 10px 10px 0;
}

/* Status Badges */
.status-badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
    display: inline-block;
}

.status-active {
    background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
    color: #1a1f2f;
    box-shadow: 0 2px 10px rgba(67, 233, 123, 0.3);
}

.status-inactive {
    background: linear-gradient(135deg, #ff6b6b 0%, #ff4757 100%);
    color: #fff;
    box-shadow: 0 2px 10px rgba(255, 107, 107, 0.3);
}

.status-suspended {
    background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
    color: #1a1f2f;
    box-shadow: 0 2px 10px rgba(250, 112, 154, 0.3);
}

/* Footer */
#footer {
    text-align: center;
    padding: 20px;
    background: rgba(10, 15, 30, 0.95);
    color: #888;
    font-size: 14px;
    border-top: 2px solid #ffd700;
    margin-top: 50px;
    position: relative;
    bottom: 0;
    width: 100%;
}

#footer i {
    color: #ff6b6b;
    margin: 0 5px;
}

/* Responsive Design */
@media (max-width: 1024px) {
    #container {
        grid-template-columns: 1fr;
    }
    
    #sidebar {
        position: static;
    }
    
    #sidebar ul {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }
    
    #sidebar ul li {
        flex: 1 1 auto;
    }
}

@media (max-width: 768px) {
    .header-content {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .members-table {
        display: block;
        overflow-x: auto;
    }
    
    .user-info {
        width: 100%;
        justify-content: center;
    }
}

/* Animations */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.stat-card, .members-table tbody tr {
    animation: fadeIn 0.5s ease-out forwards;
}

.stat-card:nth-child(1) { animation-delay: 0.1s; }
.stat-card:nth-child(2) { animation-delay: 0.2s; }
.stat-card:nth-child(3) { animation-delay: 0.3s; }
.stat-card:nth-child(4) { animation-delay: 0.4s; }

/* Custom Scrollbar */
::-webkit-scrollbar {
    width: 10px;
}

::-webkit-scrollbar-track {
    background: #1a1f2f;
}

::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #4facfe, #ffd700);
    border-radius: 5px;
}

::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #ffd700, #4facfe);
}
</style>
</head>
<body>
    <div id="header">
        <div class="header-content">
            <h1><i class="fas fa-dumbbell"></i> TABBY'S GYM</h1>
            <div class="user-info">
                <span><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($username); ?></span>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>

    <div id="container">
        <div id="sidebar">
            <ul>
                <li><a href="home.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="members.php"><i class="fas fa-users"></i> Members</a></li>
                <li><a href="add_member.php"><i class="fas fa-user-plus"></i> Add Member</a></li>
                <li><a href="#"><i class="fas fa-calendar-alt"></i> Membership Plans</a></li>
                <li><a href="#"><i class="fas fa-credit-card"></i> Payments</a></li>
                <li><a href="#"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
            </ul>
        </div>

        <div id="main-content">
            <div class="stats-grid">
                <div class="stat-card">
                    <i class="fas fa-users"></i>
                    <h3>Total Members</h3>
                    <div class="number"><?php echo $total_members_row['count']; ?></div>
                </div>
                <div class="stat-card">
                    <i class="fas fa-user-check"></i>
                    <h3>Active Members</h3>
                    <div class="number"><?php echo $active_members_row['count']; ?></div>
                </div>
                <div class="stat-card">
                    <i class="fas fa-coins"></i>
                    <h3>Total Revenue</h3>
                    <div class="number">KSH <?php echo number_format($total_payments_row['total'] ?? 0, 2); ?></div>
                </div>
                <div class="stat-card">
                    <i class="fas fa-clock"></i>
                    <h3>Expiring Soon</h3>
                    <div class="number"><?php echo $expiring_row['count']; ?></div>
                </div>
            </div>

            <div class="recent-members">
                <h2><i class="fas fa-history"></i> Recent Members</h2>
                <table class="members-table">
                    <thead>
                        <tr>
                            <th>Member ID</th>
                            <th>Full Name</th>
                            <th>Phone</th>
                            <th>Join Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $colors = ['#4facfe', '#ffd700', '#43e97b', '#fa709a', '#667eea'];
                        $i = 0;
                        while($member = $recent_members->fetch_assoc()): 
                        ?>
                        <tr style="border-left: 4px solid <?php echo $colors[$i % 5]; ?>;">
                            <td><i class="fas fa-id-card" style="color: <?php echo $colors[$i % 5]; ?>; margin-right: 8px;"></i><?php echo htmlspecialchars($member['member_id']); ?></td>
                            <td><i class="fas fa-user" style="color: <?php echo $colors[$i % 5]; ?>; margin-right: 8px;"></i><?php echo htmlspecialchars($member['fullname']); ?></td>
                            <td><i class="fas fa-phone" style="color: <?php echo $colors[$i % 5]; ?>; margin-right: 8px;"></i><?php echo htmlspecialchars($member['phone']); ?></td>
                            <td><i class="fas fa-calendar" style="color: <?php echo $colors[$i % 5]; ?>; margin-right: 8px;"></i><?php echo date('M d, Y', strtotime($member['join_date'])); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo strtolower($member['status']); ?>">
                                    <?php echo $member['status']; ?>
                                </span>
                            </td>
                        </tr>
                        <?php 
                        $i++;
                        endwhile; 
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="footer">
        <i class="fas fa-copyright"></i> <?php echo date('Y'); ?> @adhistabby. All rights reserved. 
        <i class="fas fa-heart" style="color: #ff6b6b;"></i> TABBY'S GYM
    </div>
</body>
</html>