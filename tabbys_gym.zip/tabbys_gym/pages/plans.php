<?php 
session_start();
require_once('../connection/localhost.php');

// Check if user is logged in
if (!isset($_SESSION['MM_Username'])) {
    header("Location: ../index.php");
    exit;
}

// Handle add/edit/delete plans
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_plan'])) {
        $plan_name = mysqli_real_escape_string($localhost, $_POST['plan_name']);
        $duration = intval($_POST['duration']);
        $price = floatval($_POST['price']);
        $description = mysqli_real_escape_string($localhost, $_POST['description']);
        
        $query = "INSERT INTO plans_tbl (plan_name, duration_months, price, description, status) 
                  VALUES ('$plan_name', $duration, $price, '$description', 'Active')";
        
        if ($localhost->query($query)) {
            $success = "Plan added successfully!";
        } else {
            $error = "Error adding plan: " . $localhost->error;
        }
    }
    
    if (isset($_POST['edit_plan'])) {
        $id = intval($_POST['plan_id']);
        $plan_name = mysqli_real_escape_string($localhost, $_POST['plan_name']);
        $duration = intval($_POST['duration']);
        $price = floatval($_POST['price']);
        $description = mysqli_real_escape_string($localhost, $_POST['description']);
        
        $query = "UPDATE plans_tbl SET 
                  plan_name = '$plan_name',
                  duration_months = $duration,
                  price = $price,
                  description = '$description'
                  WHERE id = $id";
        
        if ($localhost->query($query)) {
            $success = "Plan updated successfully!";
        } else {
            $error = "Error updating plan: " . $localhost->error;
        }
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $query = "DELETE FROM plans_tbl WHERE id = $id";
    if ($localhost->query($query)) {
        $success = "Plan deleted successfully!";
    } else {
        $error = "Error deleting plan: " . $localhost->error;
    }
}

// Handle status toggle
if (isset($_GET['toggle_status'])) {
    $id = intval($_GET['toggle_status']);
    $query = "UPDATE plans_tbl SET status = IF(status='Active', 'Inactive', 'Active') WHERE id = $id";
    $localhost->query($query);
    header("Location: plans.php");
    exit;
}

// Get all plans
$plans_query = "SELECT * FROM plans_tbl ORDER BY price ASC";
$plans_result = $localhost->query($plans_query);

$username = $_SESSION['MM_Username'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>TABBY'S GYM - Membership Plans</title>
    <link href="../css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a0f1e 0%, #1a1f2f 100%);
            min-height: 100vh;
            color: #fff;
        }

        #header {
            background: rgba(10, 15, 30, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 2px solid #ffd700;
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-content h1 {
            font-size: 32px;
            background: linear-gradient(45deg, #ffd700, #ff6b6b, #4facfe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
            background: linear-gradient(135deg, #2a2f3f, #1a1f2f);
            padding: 10px 20px;
            border-radius: 50px;
            border: 1px solid #ffd700;
        }

        .logout-btn {
            background: linear-gradient(45deg, #ff6b6b, #ff4757);
            color: white;
            padding: 8px 25px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: bold;
            border: 1px solid #ffd700;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(255, 107, 107, 0.5);
        }

        #container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 30px;
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 30px;
        }

        #sidebar {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px 15px;
            border: 1px solid #4facfe;
            height: fit-content;
            position: sticky;
            top: 100px;
        }

        #sidebar ul {
            list-style: none;
        }

        #sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: #ccc;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s;
        }

        #sidebar ul li a i {
            width: 24px;
            color: #ffd700;
        }

        #sidebar ul li a:hover,
        #sidebar ul li a.active {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: #fff;
        }

        #main-content {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            border: 1px solid #ffd700;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #4facfe;
        }

        .page-header h2 {
            color: #ffd700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .add-btn {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            padding: 12px 25px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 10px;
            border: 1px solid #ffd700;
            cursor: pointer;
            transition: all 0.3s;
        }

        .add-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(67, 233, 123, 0.4);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.5s ease-out;
        }

        .alert-success {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            border: 1px solid #ffd700;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(5px);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: linear-gradient(135deg, #1a1f2f, #2a2f3f);
            border-radius: 20px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
            border: 2px solid #ffd700;
            box-shadow: 0 10px 40px rgba(255, 215, 0, 0.3);
            animation: modalPop 0.3s ease-out;
        }

        @keyframes modalPop {
            from { transform: scale(0.8); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #4facfe;
        }

        .modal-header h3 {
            color: #ffd700;
            font-size: 24px;
        }

        .close-btn {
            background: none;
            border: none;
            color: #ff6b6b;
            font-size: 24px;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #ffd700;
            font-weight: bold;
        }

        .form-group label i {
            color: #4facfe;
            margin-right: 8px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid #4facfe;
            border-radius: 10px;
            color: #fff;
            font-size: 16px;
        }

        .form-control:focus {
            outline: none;
            border-color: #ffd700;
            box-shadow: 0 0 20px rgba(255, 215, 0, 0.3);
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }

        .submit-btn {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            border: 1px solid #ffd700;
            transition: all 0.3s;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(67, 233, 123, 0.4);
        }

        /* Plans Grid */
        .plans-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }

        .plan-card {
            background: rgba(30, 35, 50, 0.8);
            border-radius: 15px;
            padding: 25px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s;
            border: 2px solid transparent;
        }

        .plan-card:hover {
            transform: translateY(-5px);
            border-color: #ffd700;
            box-shadow: 0 10px 30px rgba(255, 215, 0, 0.3);
        }

        .plan-card.premium {
            background: linear-gradient(135deg, rgba(79, 172, 254, 0.2), rgba(255, 215, 0, 0.2));
            border: 2px solid #ffd700;
        }

        .plan-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .badge-active {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
        }

        .badge-inactive {
            background: linear-gradient(135deg, #ff6b6b 0%, #ff4757 100%);
            color: #fff;
        }

        .plan-icon {
            font-size: 50px;
            color: #4facfe;
            margin-bottom: 20px;
        }

        .plan-card.premium .plan-icon {
            color: #ffd700;
        }

        .plan-name {
            font-size: 24px;
            margin-bottom: 10px;
            color: #fff;
        }

        .plan-price {
            font-size: 36px;
            font-weight: bold;
            background: linear-gradient(135deg, #4facfe, #ffd700);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }

        .plan-price span {
            font-size: 16px;
            color: #ccc;
            -webkit-text-fill-color: #ccc;
        }

        .plan-duration {
            color: #4facfe;
            margin-bottom: 20px;
            font-size: 16px;
        }

        .plan-description {
            color: #ccc;
            margin-bottom: 20px;
            line-height: 1.6;
            min-height: 80px;
        }

        .plan-features {
            list-style: none;
            margin-bottom: 25px;
        }

        .plan-features li {
            margin: 10px 0;
            color: #ccc;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .plan-features li i {
            color: #43e97b;
        }

        .plan-actions {
            display: flex;
            gap: 10px;
        }

        .plan-btn {
            flex: 1;
            padding: 10px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            transition: all 0.3s;
        }

        .edit-btn {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: #1a1f2f;
        }

        .toggle-btn {
            background: linear-gradient(135deg, #ffd700 0%, #ffb347 100%);
            color: #1a1f2f;
        }

        .delete-btn {
            background: linear-gradient(135deg, #ff6b6b 0%, #ff4757 100%);
            color: #fff;
        }

        .plan-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }

        #footer {
            text-align: center;
            padding: 20px;
            background: rgba(10, 15, 30, 0.95);
            color: #888;
            border-top: 2px solid #ffd700;
            margin-top: 50px;
        }

        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
    <div id="header">
        <div class="header-content">
            <h1><i class="fas fa-dumbbell"></i> TABBY'S GYM</h1>
            <div class="user-info">
                <span><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($username); ?></span>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>

    <div id="container">
        <div id="sidebar">
            <ul>
                <li><a href="home.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="members.php"><i class="fas fa-users"></i> Members</a></li>
                <li><a href="add_member.php"><i class="fas fa-user-plus"></i> Add Member</a></li>
                <li><a href="plans.php" class="active"><i class="fas fa-calendar-alt"></i> Membership Plans</a></li>
                <li><a href="payments.php"><i class="fas fa-credit-card"></i> Payments</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
            </ul>
        </div>

        <div id="main-content">
            <?php if(isset($success)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <div class="page-header">
                <h2><i class="fas fa-calendar-alt"></i> Membership Plans</h2>
                <button class="add-btn" onclick="openAddModal()">
                    <i class="fas fa-plus"></i> Add New Plan
                </button>
            </div>

            <div class="plans-grid">
                <?php 
                $plan_icons = ['dumbbell', 'crown', 'bolt', 'fire', 'star', 'gem'];
                $i = 0;
                while($plan = $plans_result->fetch_assoc()): 
                ?>
                <div class="plan-card <?php echo ($plan['price'] >= 2000) ? 'premium' : ''; ?>">
                    <div class="plan-badge <?php echo ($plan['status'] == 'Active') ? 'badge-active' : 'badge-inactive'; ?>">
                        <?php echo $plan['status']; ?>
                    </div>
                    <div class="plan-icon">
                        <i class="fas fa-<?php echo $plan_icons[$i % count($plan_icons)]; ?>"></i>
                    </div>
                    <h3 class="plan-name"><?php echo $plan['plan_name']; ?></h3>
                    <div class="plan-price">
                        KSH <?php echo number_format($plan['price'], 0); ?> 
                        <span>/ <?php echo $plan['duration_months']; ?> month<?php echo ($plan['duration_months'] > 1) ? 's' : ''; ?></span>
                    </div>
                    <div class="plan-duration">
                        <i class="fas fa-clock"></i> <?php echo $plan['duration_months']; ?> Month(s)
                    </div>
                    <div class="plan-description">
                        <?php echo $plan['description']; ?>
                    </div>
                    <ul class="plan-features">
                        <li><i class="fas fa-check"></i> Full Gym Access</li>
                        <li><i class="fas fa-check"></i> Locker Room</li>
                        <?php if($plan['price'] >= 2000): ?>
                        <li><i class="fas fa-check"></i> Personal Trainer</li>
                        <li><i class="fas fa-check"></i> Group Classes</li>
                        <?php endif; ?>
                        <?php if($plan['price'] >= 4000): ?>
                        <li><i class="fas fa-check"></i> Nutrition Plan</li>
                        <li><i class="fas fa-check"></i> 24/7 Access</li>
                        <?php endif; ?>
                    </ul>
                    <div class="plan-actions">
                        <button onclick="openEditModal(<?php echo $plan['id']; ?>, '<?php echo $plan['plan_name']; ?>', <?php echo $plan['duration_months']; ?>, <?php echo $plan['price']; ?>, '<?php echo $plan['description']; ?>')" class="plan-btn edit-btn">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <a href="?toggle_status=<?php echo $plan['id']; ?>" class="plan-btn toggle-btn">
                            <i class="fas fa-<?php echo ($plan['status'] == 'Active') ? 'ban' : 'check'; ?>"></i> 
                            <?php echo ($plan['status'] == 'Active') ? 'Deactivate' : 'Activate'; ?>
                        </a>
                        <a href="?delete=<?php echo $plan['id']; ?>" class="plan-btn delete-btn" onclick="return confirm('Delete this plan?')">
                            <i class="fas fa-trash"></i> Delete
                        </a>
                    </div>
                </div>
                <?php 
                $i++;
                endwhile; 
                ?>
            </div>
        </div>
    </div>

    <!-- Add Plan Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-plus-circle"></i> Add New Plan</h3>
                <button class="close-btn" onclick="closeAddModal()">&times;</button>
            </div>
            <form method="POST">
                <div class="form-group">
                    <label><i class="fas fa-tag"></i> Plan Name</label>
                    <input type="text" name="plan_name" class="form-control" required placeholder="e.g., Basic Plan">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-clock"></i> Duration (Months)</label>
                    <input type="number" name="duration" class="form-control" required min="1" max="24" value="1">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-coins"></i> Price (KSH)</label>
                    <input type="number" name="price" class="form-control" required min="0" step="100" value="500">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-align-left"></i> Description</label>
                    <textarea name="description" class="form-control" required placeholder="Describe the plan features..."></textarea>
                </div>
                <button type="submit" name="add_plan" class="submit-btn">
                    <i class="fas fa-save"></i> Add Plan
                </button>
            </form>
        </div>
    </div>

    <!-- Edit Plan Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit"></i> Edit Plan</h3>
                <button class="close-btn" onclick="closeEditModal()">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="plan_id" id="edit_plan_id">
                <div class="form-group">
                    <label><i class="fas fa-tag"></i> Plan Name</label>
                    <input type="text" name="plan_name" id="edit_plan_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-clock"></i> Duration (Months)</label>
                    <input type="number" name="duration" id="edit_duration" class="form-control" required min="1" max="24">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-coins"></i> Price (KSH)</label>
                    <input type="number" name="price" id="edit_price" class="form-control" required min="0" step="100">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-align-left"></i> Description</label>
                    <textarea name="description" id="edit_description" class="form-control" required></textarea>
                </div>
                <button type="submit" name="edit_plan" class="submit-btn">
                    <i class="fas fa-save"></i> Update Plan
                </button>
            </form>
        </div>
    </div>

    <div id="footer">
        <i class="fas fa-copyright"></i> <?php echo date('Y'); ?> @adhistabby. All rights reserved.
    </div>

    <script>
        function openAddModal() {
            document.getElementById('addModal').classList.add('active');
        }

        function closeAddModal() {
            document.getElementById('addModal').classList.remove('active');
        }

        function openEditModal(id, name, duration, price, description) {
            document.getElementById('edit_plan_id').value = id;
            document.getElementById('edit_plan_name').value = name;
            document.getElementById('edit_duration').value = duration;
            document.getElementById('edit_price').value = price;
            document.getElementById('edit_description').value = description;
            document.getElementById('editModal').classList.add('active');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.remove('active');
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
</body>
</html>