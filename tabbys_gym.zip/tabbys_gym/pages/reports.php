<?php 
session_start();
require_once('../connection/localhost.php');

// Check if user is logged in
if (!isset($_SESSION['MM_Username'])) {
    header("Location: ../index.php");
    exit;
}

// Get date filters
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-t');

// Get report data
$membership_stats = $localhost->query("
    SELECT 
        COUNT(*) as total_members,
        SUM(CASE WHEN status = 'Active' THEN 1 ELSE 0 END) as active_members,
        SUM(CASE WHEN status = 'Inactive' THEN 1 ELSE 0 END) as inactive_members,
        SUM(CASE WHEN MONTH(join_date) = MONTH(CURDATE()) AND YEAR(join_date) = YEAR(CURDATE()) THEN 1 ELSE 0 END) as new_members
    FROM members_tbl
")->fetch_assoc();

$revenue_stats = $localhost->query("
    SELECT 
        COUNT(*) as total_transactions,
        SUM(amount) as total_revenue,
        AVG(amount) as average_transaction,
        SUM(CASE WHEN payment_method = 'M-PESA' THEN amount ELSE 0 END) as mpesa_revenue,
        SUM(CASE WHEN payment_method = 'Airtel Money' THEN amount ELSE 0 END) as airtel_revenue,
        SUM(CASE WHEN payment_method = 'Bank Transfer' THEN amount ELSE 0 END) as bank_revenue
    FROM payments_tbl 
    WHERE status = 'Paid' 
    AND payment_date BETWEEN '$start_date' AND '$end_date'
")->fetch_assoc();

$plan_popularity = $localhost->query("
    SELECT 
        pl.plan_name,
        COUNT(*) as count,
        SUM(p.amount) as revenue
    FROM payments_tbl p
    JOIN plans_tbl pl ON p.plan_id = pl.id
    WHERE p.payment_date BETWEEN '$start_date' AND '$end_date'
    GROUP BY pl.id
    ORDER BY count DESC
");

$daily_revenue = $localhost->query("
    SELECT 
        DATE(payment_date) as date,
        COUNT(*) as transactions,
        SUM(amount) as revenue
    FROM payments_tbl
    WHERE status = 'Paid'
    AND payment_date BETWEEN '$start_date' AND '$end_date'
    GROUP BY DATE(payment_date)
    ORDER BY date DESC
    LIMIT 30
");

$username = $_SESSION['MM_Username'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>TABBY'S GYM - Reports</title>
    <link href="../css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a0f1e 0%, #1a1f2f 100%);
            min-height: 100vh;
            color: #fff;
        }

        #header {
            background: rgba(10, 15, 30, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 2px solid #ffd700;
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-content h1 {
            font-size: 32px;
            background: linear-gradient(45deg, #ffd700, #ff6b6b, #4facfe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
            background: linear-gradient(135deg, #2a2f3f, #1a1f2f);
            padding: 10px 20px;
            border-radius: 50px;
            border: 1px solid #ffd700;
        }

        .logout-btn {
            background: linear-gradient(45deg, #ff6b6b, #ff4757);
            color: white;
            padding: 8px 25px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: bold;
            border: 1px solid #ffd700;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(255, 107, 107, 0.5);
        }

        #container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 30px;
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 30px;
        }

        #sidebar {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px 15px;
            border: 1px solid #4facfe;
            height: fit-content;
            position: sticky;
            top: 100px;
        }

        #sidebar ul {
            list-style: none;
        }

        #sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: #ccc;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s;
        }

        #sidebar ul li a i {
            width: 24px;
            color: #ffd700;
        }

        #sidebar ul li a:hover,
        #sidebar ul li a.active {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: #fff;
        }

        #main-content {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            border: 1px solid #ffd700;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #4facfe;
        }

        .page-header h2 {
            color: #ffd700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .filter-section {
            background: rgba(30, 35, 50, 0.8);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 30px;
            border: 1px solid #4facfe;
        }

        .filter-form {
            display: flex;
            gap: 20px;
            align-items: flex-end;
        }

        .filter-group {
            flex: 1;
        }

        .filter-group label {
            display: block;
            margin-bottom: 8px;
            color: #ffd700;
        }

        .filter-group input {
            width: 100%;
            padding: 10px;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid #4facfe;
            border-radius: 8px;
            color: #fff;
        }

        .filter-btn {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: #1a1f2f;
            padding: 10px 30px;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            border: 1px solid #ffd700;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: rgba(30, 35, 50, 0.8);
            border-radius: 15px;
            padding: 20px;
            border-left: 4px solid;
            transition: all 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(79, 172, 254, 0.3);
        }

        .stat-card.members { border-left-color: #4facfe; }
        .stat-card.revenue { border-left-color: #43e97b; }
        .stat-card.mpesa { border-left-color: #ffd700; }
        .stat-card.avg { border-left-color: #ff6b6b; }

        .stat-title {
            color: #ccc;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .stat-value {
            font-size: 28px;
            font-weight: bold;
            color: #fff;
        }

        .charts-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .chart-card {
            background: rgba(30, 35, 50, 0.8);
            border-radius: 15px;
            padding: 20px;
            border: 1px solid #4facfe;
        }

        .chart-card h3 {
            color: #ffd700;
            margin-bottom: 20px;
        }

        .table-container {
            background: rgba(30, 35, 50, 0.8);
            border-radius: 15px;
            padding: 20px;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            color: #ffd700;
            padding: 15px;
            text-align: left;
            border-bottom: 2px solid #4facfe;
        }

        td {
            padding: 12px 15px;
            color: #fff;
            border-bottom: 1px solid rgba(79, 172, 254, 0.3);
        }

        tr:hover td {
            background: rgba(79, 172, 254, 0.1);
        }

        #footer {
            text-align: center;
            padding: 20px;
            background: rgba(10, 15, 30, 0.95);
            color: #888;
            border-top: 2px solid #ffd700;
            margin-top: 50px;
        }

        @media (max-width: 1024px) {
            #container {
                grid-template-columns: 1fr;
            }
            
            .stats-grid,
            .charts-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .stats-grid,
            .charts-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-form {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div id="header">
        <div class="header-content">
            <h1><i class="fas fa-dumbbell"></i> TABBY'S GYM</h1>
            <div class="user-info">
                <span><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($username); ?></span>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>

    <div id="container">
        <div id="sidebar">
            <ul>
                <li><a href="home.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="members.php"><i class="fas fa-users"></i> Members</a></li>
                <li><a href="add_member.php"><i class="fas fa-user-plus"></i> Add Member</a></li>
                <li><a href="plans.php"><i class="fas fa-calendar-alt"></i> Membership Plans</a></li>
                <li><a href="payments.php"><i class="fas fa-credit-card"></i> Payments</a></li>
                <li><a href="reports.php" class="active"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
            </ul>
        </div>

        <div id="main-content">
            <div class="page-header">
                <h2><i class="fas fa-chart-bar"></i> Reports & Analytics</h2>
            </div>

            <!-- Date Filter -->
            <div class="filter-section">
                <form method="GET" class="filter-form">
                    <div class="filter-group">
                        <label><i class="fas fa-calendar"></i> Start Date</label>
                        <input type="date" name="start_date" value="<?php echo $start_date; ?>">
                    </div>
                    <div class="filter-group">
                        <label><i class="fas fa-calendar"></i> End Date</label>
                        <input type="date" name="end_date" value="<?php echo $end_date; ?>">
                    </div>
                    <button type="submit" class="filter-btn">
                        <i class="fas fa-filter"></i> Apply Filter
                    </button>
                </form>
            </div>

            <!-- Key Statistics -->
            <div class="stats-grid">
                <div class="stat-card members">
                    <div class="stat-title">Total Members</div>
                    <div class="stat-value"><?php echo $membership_stats['total_members']; ?></div>
                    <div style="color: #4facfe;">Active: <?php echo $membership_stats['active_members']; ?></div>
                    <div style="color: #ff6b6b;">Inactive: <?php echo $membership_stats['inactive_members']; ?></div>
                    <div style="color: #43e97b;">New this month: <?php echo $membership_stats['new_members']; ?></div>
                </div>
                <div class="stat-card revenue">
                    <div class="stat-title">Total Revenue</div>
                    <div class="stat-value">KSH <?php echo number_format($revenue_stats['total_revenue'] ?? 0, 2); ?></div>
                    <div>Transactions: <?php echo $revenue_stats['total_transactions'] ?? 0; ?></div>
                </div>
                <div class="stat-card mpesa">
                    <div class="stat-title">Payment Methods</div>
                    <div><i class="fas fa-mobile-alt"></i> M-PESA: KSH <?php echo number_format($revenue_stats['mpesa_revenue'] ?? 0, 2); ?></div>
                    <div><i class="fas fa-mobile"></i> Airtel: KSH <?php echo number_format($revenue_stats['airtel_revenue'] ?? 0, 2); ?></div>
                    <div><i class="fas fa-university"></i> Bank: KSH <?php echo number_format($revenue_stats['bank_revenue'] ?? 0, 2); ?></div>
                </div>
                <div class="stat-card avg">
                    <div class="stat-title">Average Transaction</div>
                    <div class="stat-value">KSH <?php echo number_format($revenue_stats['average_transaction'] ?? 0, 2); ?></div>
                </div>
            </div>

            <!-- Charts -->
            <div class="charts-grid">
                <div class="chart-card">
                    <h3><i class="fas fa-chart-pie"></i> Revenue by Plan</h3>
                    <canvas id="planChart" style="width:100%; height:300px;"></canvas>
                </div>
                <div class="chart-card">
                    <h3><i class="fas fa-chart-line"></i> Daily Revenue</h3>
                    <canvas id="dailyChart" style="width:100%; height:300px;"></canvas>
                </div>
            </div>

            <!-- Plan Popularity Table -->
            <div class="table-container">
                <h3 style="color: #ffd700; margin-bottom: 20px;">
                    <i class="fas fa-crown"></i> Plan Popularity
                </h3>
                <table>
                    <thead>
                        <tr>
                            <th>Plan Name</th>
                            <th>Number of Signups</th>
                            <th>Revenue Generated</th>
                            <th>Percentage</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total_revenue_plans = $revenue_stats['total_revenue'] ?? 1;
                        while($plan = $plan_popularity->fetch_assoc()): 
                        $percentage = ($plan['revenue'] / $total_revenue_plans) * 100;
                        ?>
                        <tr>
                            <td><?php echo $plan['plan_name']; ?></td>
                            <td><?php echo $plan['count']; ?></td>
                            <td>KSH <?php echo number_format($plan['revenue'], 2); ?></td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div style="width: 100px; height: 8px; background: rgba(79,172,254,0.3); border-radius: 4px;">
                                        <div style="width: <?php echo $percentage; ?>%; height: 100%; background: linear-gradient(90deg, #4facfe, #ffd700); border-radius: 4px;"></div>
                                    </div>
                                    <?php echo number_format($percentage, 1); ?>%
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="footer">
        <i class="fas fa-copyright"></i> <?php echo date('Y'); ?> @adhistabby. All rights reserved.
    </div>

    <script>
        // Plan Popularity Chart
        const planCtx = document.getElementById('planChart').getContext('2d');
        new Chart(planCtx, {
            type: 'doughnut',
            data: {
                labels: <?php 
                    $plan_popularity->data_seek(0);
                    $labels = [];
                    $values = [];
                    while($row = $plan_popularity->fetch_assoc()) {
                        $labels[] = $row['plan_name'];
                        $values[] = $row['revenue'];
                    }
                    echo json_encode($labels);
                ?>,
                datasets: [{
                    data: <?php echo json_encode($values); ?>,
                    backgroundColor: ['#4facfe', '#ffd700', '#43e97b', '#ff6b6b', '#667eea'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: { color: '#fff' }
                    }
                }
            }
        });

        // Daily Revenue Chart
        const dailyCtx = document.getElementById('dailyChart').getContext('2d');
        new Chart(dailyCtx, {
            type: 'line',
            data: {
                labels: <?php 
                    $daily_revenue->data_seek(0);
                    $dates = [];
                    $revenues = [];
                    while($row = $daily_revenue->fetch_assoc()) {
                        $dates[] = date('d M', strtotime($row['date']));
                        $revenues[] = $row['revenue'];
                    }
                    echo json_encode(array_reverse($dates));
                ?>,
                datasets: [{
                    label: 'Revenue',
                    data: <?php echo json_encode(array_reverse($revenues)); ?>,
                    borderColor: '#4facfe',
                    backgroundColor: 'rgba(79, 172, 254, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { grid: { color: 'rgba(255,255,255,0.1)' }, ticks: { color: '#fff' } },
                    x: { grid: { display: false }, ticks: { color: '#fff' } }
                }
            }
        });
    </script>
</body>
</html>