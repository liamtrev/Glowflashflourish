<?php 
session_start();
require_once('../connection/localhost.php');

// Check if user is logged in
if (!isset($_SESSION['MM_Username'])) {
    header("Location: ../index.php");
    exit;
}

// Handle member deletion
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    
    // First delete related payments
    $delete_payments = "DELETE FROM payments_tbl WHERE member_id = $delete_id";
    $localhost->query($delete_payments);
    
    // Then delete the member
    $delete_query = "DELETE FROM members_tbl WHERE id = $delete_id";
    
    if ($localhost->query($delete_query)) {
        header("Location: members.php?msg=deleted");
        exit();
    } else {
        header("Location: members.php?msg=error");
        exit();
    }
}

// Handle status update
if (isset($_GET['update_status']) && isset($_GET['id'])) {
    $status = mysqli_real_escape_string($localhost, $_GET['update_status']);
    $id = intval($_GET['id']);
    $update_query = "UPDATE members_tbl SET status = '$status' WHERE id = $id";
    if ($localhost->query($update_query)) {
        header("Location: members.php?msg=updated");
        exit();
    }
}

// Get all members
$members_query = "SELECT * FROM members_tbl ORDER BY join_date DESC";
$members_result = $localhost->query($members_query);

// Separate active and inactive members
$active_members = [];
$inactive_members = [];

while ($member = $members_result->fetch_assoc()) {
    if ($member['status'] == 'Active') {
        $active_members[] = $member;
    } else {
        $inactive_members[] = $member;
    }
}

$username = $_SESSION['MM_Username'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>TABBY'S GYM - Members</title>
    <link href="../css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a0f1e 0%, #1a1f2f 100%);
            min-height: 100vh;
            color: #fff;
        }

        #header {
            background: rgba(10, 15, 30, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 2px solid #ffd700;
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-content h1 {
            font-size: 32px;
            background: linear-gradient(45deg, #ffd700, #ff6b6b, #4facfe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
            background: linear-gradient(135deg, #2a2f3f, #1a1f2f);
            padding: 10px 20px;
            border-radius: 50px;
            border: 1px solid #ffd700;
        }

        .logout-btn {
            background: linear-gradient(45deg, #ff6b6b, #ff4757);
            color: white;
            padding: 8px 25px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s;
            border: 1px solid #ffd700;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        #container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 30px;
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 30px;
        }

        #sidebar {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px 15px;
            border: 1px solid #4facfe;
            height: fit-content;
            position: sticky;
            top: 100px;
        }

        #sidebar ul {
            list-style: none;
        }

        #sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: #ccc;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s;
        }

        #sidebar ul li a i {
            width: 24px;
            color: #ffd700;
        }

        #sidebar ul li a:hover,
        #sidebar ul li a.active {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: #fff;
        }

        #main-content {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            border: 1px solid #ffd700;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #4facfe;
        }

        .page-header h2 {
            color: #ffd700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .add-btn {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            padding: 12px 25px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 10px;
            border: 1px solid #ffd700;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.5s ease-out;
        }

        .alert-success {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            border: 1px solid #ffd700;
        }

        .member-tabs {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }

        .tab-btn {
            flex: 1;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .tab-btn.active {
            background: linear-gradient(135deg, #ffd700 0%, #ffb347 100%);
            color: #1a1f2f;
        }

        .tab-btn:not(.active) {
            background: rgba(255, 255, 255, 0.1);
            color: #ccc;
            border: 1px solid #4facfe;
        }

        .member-grid {
            display: none;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 25px;
        }

        .member-grid.active {
            display: grid;
        }

        .member-card {
            background: rgba(30, 35, 50, 0.8);
            border-radius: 15px;
            padding: 20px;
            border-left: 4px solid #4facfe;
            transition: all 0.3s;
        }

        .member-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(79, 172, 254, 0.3);
        }

        .member-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(255, 215, 0, 0.3);
        }

        .member-id {
            color: #ffd700;
            background: rgba(255, 215, 0, 0.1);
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 14px;
        }

        .member-status {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .member-status.active {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
        }

        .member-status.inactive {
            background: linear-gradient(135deg, #ff6b6b 0%, #ff4757 100%);
            color: #fff;
        }

        .member-info p {
            margin: 10px 0;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #ccc;
        }

        .member-info p i {
            width: 20px;
            color: #4facfe;
        }

        .member-info strong {
            color: #ffd700;
        }

        .member-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .action-btn {
            flex: 1;
            padding: 10px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            transition: all 0.3s;
        }

        .edit-btn {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: #1a1f2f;
        }

        .status-btn {
            background: linear-gradient(135deg, #ffd700 0%, #ffb347 100%);
            color: #1a1f2f;
        }

        .delete-btn {
            background: linear-gradient(135deg, #ff6b6b 0%, #ff4757 100%);
            color: #fff;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }

        #footer {
            text-align: center;
            padding: 20px;
            background: rgba(10, 15, 30, 0.95);
            color: #888;
            border-top: 2px solid #ffd700;
            margin-top: 50px;
        }

        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
    <div id="header">
        <div class="header-content">
            <h1><i class="fas fa-dumbbell"></i> TABBY'S GYM</h1>
            <div class="user-info">
                <span><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($username); ?></span>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>

    <div id="container">
        <div id="sidebar">
            <ul>
                <li><a href="home.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="members.php" class="active"><i class="fas fa-users"></i> Members</a></li>
                <li><a href="add_member.php"><i class="fas fa-user-plus"></i> Add Member</a></li>
                <li><a href="plans.php"><i class="fas fa-calendar-alt"></i> Membership Plans</a></li>
                <li><a href="payments.php"><i class="fas fa-credit-card"></i> Payments</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
            </ul>
        </div>

        <div id="main-content">
            <?php if(isset($_GET['msg'])): ?>
                <?php if($_GET['msg'] == 'deleted'): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> Member deleted successfully!
                </div>
                <?php elseif($_GET['msg'] == 'updated'): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> Member status updated successfully!
                </div>
                <?php elseif($_GET['msg'] == 'error'): ?>
                <div class="alert alert-success" style="background: linear-gradient(135deg, #ff6b6b 0%, #ff4757 100%); color: #fff;">
                    <i class="fas fa-exclamation-circle"></i> Error! Please try again.
                </div>
                <?php endif; ?>
            <?php endif; ?>

            <div class="page-header">
                <h2><i class="fas fa-users"></i> Members Management</h2>
                <a href="add_member.php" class="add-btn"><i class="fas fa-user-plus"></i> Add New Member</a>
            </div>

            <div class="member-tabs">
                <button class="tab-btn active" onclick="showTab('active')">
                    <i class="fas fa-user-check"></i> Active (<?php echo count($active_members); ?>)
                </button>
                <button class="tab-btn" onclick="showTab('inactive')">
                    <i class="fas fa-user-times"></i> Inactive (<?php echo count($inactive_members); ?>)
                </button>
            </div>

            <div id="active-members" class="member-grid active">
                <?php if(empty($active_members)): ?>
                    <div style="grid-column: 1/-1; text-align: center; padding: 50px;">
                        <i class="fas fa-users" style="font-size: 50px; color: #4facfe;"></i>
                        <h3 style="color: #ccc; margin-top: 20px;">No Active Members</h3>
                    </div>
                <?php else: ?>
                    <?php foreach($active_members as $member): ?>
                    <div class="member-card">
                        <div class="member-header">
                            <span class="member-id"><i class="fas fa-id-card"></i> <?php echo $member['member_id']; ?></span>
                            <span class="member-status active">ACTIVE</span>
                        </div>
                        <div class="member-info">
                            <p><i class="fas fa-user"></i> <strong><?php echo $member['fullname']; ?></strong></p>
                            <p><i class="fas fa-phone"></i> <?php echo $member['phone']; ?></p>
                            <p><i class="fas fa-envelope"></i> <?php echo $member['email']; ?></p>
                            <p><i class="fas fa-calendar"></i> Joined: <?php echo date('M d, Y', strtotime($member['join_date'])); ?></p>
                        </div>
                        <div class="member-actions">
                            <a href="edit_member.php?id=<?php echo $member['id']; ?>" class="action-btn edit-btn"><i class="fas fa-edit"></i> Edit</a>
                            <a href="?update_status=Inactive&id=<?php echo $member['id']; ?>" class="action-btn status-btn" onclick="return confirm('Deactivate this member?')"><i class="fas fa-ban"></i> Deactivate</a>
                            <a href="?delete=<?php echo $member['id']; ?>" class="action-btn delete-btn" onclick="return confirm('⚠️ PERMANENT DELETE: This will remove all member data! Continue?')"><i class="fas fa-trash"></i> Delete</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div id="inactive-members" class="member-grid">
                <?php if(empty($inactive_members)): ?>
                    <div style="grid-column: 1/-1; text-align: center; padding: 50px;">
                        <i class="fas fa-user-slash" style="font-size: 50px; color: #ff6b6b;"></i>
                        <h3 style="color: #ccc; margin-top: 20px;">No Inactive Members</h3>
                    </div>
                <?php else: ?>
                    <?php foreach($inactive_members as $member): ?>
                    <div class="member-card">
                        <div class="member-header">
                            <span class="member-id"><i class="fas fa-id-card"></i> <?php echo $member['member_id']; ?></span>
                            <span class="member-status inactive">INACTIVE</span>
                        </div>
                        <div class="member-info">
                            <p><i class="fas fa-user"></i> <strong><?php echo $member['fullname']; ?></strong></p>
                            <p><i class="fas fa-phone"></i> <?php echo $member['phone']; ?></p>
                            <p><i class="fas fa-envelope"></i> <?php echo $member['email']; ?></p>
                            <p><i class="fas fa-calendar"></i> Joined: <?php echo date('M d, Y', strtotime($member['join_date'])); ?></p>
                        </div>
                        <div class="member-actions">
                            <a href="edit_member.php?id=<?php echo $member['id']; ?>" class="action-btn edit-btn"><i class="fas fa-edit"></i> Edit</a>
                            <a href="?update_status=Active&id=<?php echo $member['id']; ?>" class="action-btn status-btn" onclick="return confirm('Activate this member?')"><i class="fas fa-check"></i> Activate</a>
                            <a href="?delete=<?php echo $member['id']; ?>" class="action-btn delete-btn" onclick="return confirm('⚠️ PERMANENT DELETE: This will remove all member data! Continue?')"><i class="fas fa-trash"></i> Delete</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div id="footer">
        <i class="fas fa-copyright"></i> <?php echo date('Y'); ?> @adhistabby. All rights reserved.
    </div>

    <script>
    function showTab(tab) {
        document.getElementById('active-members').classList.remove('active');
        document.getElementById('inactive-members').classList.remove('active');
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        
        if (tab === 'active') {
            document.getElementById('active-members').classList.add('active');
            document.querySelector('.tab-btn:first-child').classList.add('active');
        } else {
            document.getElementById('inactive-members').classList.add('active');
            document.querySelector('.tab-btn:last-child').classList.add('active');
        }
    }
    </script>
</body>
</html>