<?php 
session_start();
require_once('../connection/localhost.php');

// Check if user is logged in
if (!isset($_SESSION['MM_Username'])) {
    header("Location: ../index.php");
    exit;
}

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Generate member ID
    $year = date('Y');
    $query = "SELECT COUNT(*) as count FROM members_tbl WHERE member_id LIKE 'TGM-$year-%'";
    $result = $localhost->query($query);
    $row = $result->fetch_assoc();
    $count = $row['count'] + 1;
    $member_id = "TGM-$year-" . str_pad($count, 4, '0', STR_PAD_LEFT);
    
    // Get form data
    $firstname = mysqli_real_escape_string($localhost, $_POST['firstname']);
    $surname = mysqli_real_escape_string($localhost, $_POST['surname']);
    $fullname = $firstname . ' ' . $surname;
    $email = mysqli_real_escape_string($localhost, $_POST['email']);
    $phone = mysqli_real_escape_string($localhost, $_POST['phone']);
    $age = intval($_POST['age']);
    $plan = mysqli_real_escape_string($localhost, $_POST['plan']);
    $join_date = date('Y-m-d');
    
    // Calculate date of birth from age
    $dob = date('Y-m-d', strtotime("-$age years"));
    
    // Insert member
    $insert_query = "INSERT INTO members_tbl (member_id, fullname, email, phone, date_of_birth, join_date, status) 
                     VALUES ('$member_id', '$fullname', '$email', '$phone', '$dob', '$join_date', 'Active')";
    
    if ($localhost->query($insert_query)) {
        $success_message = "Member added successfully! Member ID: $member_id";
    } else {
        $error_message = "Error adding member: " . $localhost->error;
    }
}

$username = $_SESSION['MM_Username'];
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html>
<head>
    <title>TABBY'S GYM - Add Member</title>
    <link href="../css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a0f1e 0%, #1a1f2f 100%);
            min-height: 100vh;
            color: #fff;
        }

        #header {
            background: rgba(10, 15, 30, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 2px solid #ffd700;
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-content h1 {
            font-size: 32px;
            background: linear-gradient(45deg, #ffd700, #ff6b6b, #4facfe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-transform: uppercase;
            letter-spacing: 3px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
            background: linear-gradient(135deg, #2a2f3f, #1a1f2f);
            padding: 10px 20px;
            border-radius: 50px;
            border: 1px solid #ffd700;
        }

        .user-info span {
            color: #4facfe;
            font-weight: bold;
        }

        .user-info span i {
            color: #ffd700;
            margin-right: 8px;
        }

        .logout-btn {
            background: linear-gradient(45deg, #ff6b6b, #ff4757);
            color: white;
            padding: 8px 25px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: bold;
            border: 1px solid #ffd700;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(255, 107, 107, 0.5);
        }

        #container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 30px;
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 30px;
        }

        #sidebar {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px 15px;
            border: 1px solid #4facfe;
            height: fit-content;
            position: sticky;
            top: 100px;
        }

        #sidebar ul {
            list-style: none;
        }

        #sidebar ul li {
            margin-bottom: 10px;
        }

        #sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: #ccc;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s;
        }

        #sidebar ul li a i {
            width: 24px;
            color: #ffd700;
        }

        #sidebar ul li a:hover {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: #fff;
            transform: translateX(5px);
        }

        #sidebar ul li a.active {
            background: linear-gradient(135deg, #ffd700 0%, #ffb347 100%);
            color: #1a1f2f;
            font-weight: bold;
        }

        #sidebar ul li a.active i {
            color: #1a1f2f;
        }

        #main-content {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            border: 1px solid #ffd700;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #4facfe;
        }

        .page-header h2 {
            color: #ffd700;
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .page-header h2 i {
            color: #4facfe;
        }

        .back-link {
            color: #4facfe;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 15px;
            border-radius: 8px;
            background: rgba(79, 172, 254, 0.1);
            transition: all 0.3s;
        }

        .back-link:hover {
            background: rgba(79, 172, 254, 0.2);
            transform: translateX(-5px);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.5s ease-out;
        }

        .alert-success {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            border: 1px solid #ffd700;
        }

        .member-form {
            max-width: 800px;
            margin: 0 auto;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #ffd700;
            font-weight: bold;
            font-size: 16px;
        }

        .form-group label i {
            color: #4facfe;
            margin-right: 8px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid #4facfe;
            border-radius: 10px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: #ffd700;
            box-shadow: 0 0 20px rgba(255, 215, 0, 0.3);
            background: rgba(255, 255, 255, 0.15);
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }

        .plan-selection {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin: 30px 0;
        }

        .plan-card {
            background: rgba(30, 35, 50, 0.8);
            border: 2px solid #4facfe;
            border-radius: 15px;
            padding: 25px;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }

        .plan-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(79, 172, 254, 0.3);
        }

        .plan-card.selected {
            border-color: #ffd700;
            box-shadow: 0 0 30px rgba(255, 215, 0, 0.3);
            background: linear-gradient(135deg, rgba(79,172,254,0.2) 0%, rgba(255,215,0,0.2) 100%);
        }

        .plan-card input[type="radio"] {
            display: none;
        }

        .plan-card .plan-icon {
            font-size: 40px;
            color: #4facfe;
            margin-bottom: 15px;
        }

        .plan-card.selected .plan-icon {
            color: #ffd700;
        }

        .plan-card h3 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #fff;
        }

        .plan-card .price {
            font-size: 28px;
            font-weight: bold;
            background: linear-gradient(135deg, #4facfe, #ffd700);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }

        .plan-card .price span {
            font-size: 16px;
            color: #ccc;
            -webkit-text-fill-color: #ccc;
        }

        .plan-card .features {
            list-style: none;
            margin-top: 15px;
        }

        .plan-card .features li {
            margin: 8px 0;
            color: #ccc;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .plan-card .features li i {
            color: #43e97b;
        }

        .checkmark {
            position: absolute;
            top: 10px;
            right: 10px;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: #43e97b;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #1a1f2f;
            font-size: 16px;
            opacity: 0;
            transform: scale(0);
            transition: all 0.3s;
        }

        .plan-card.selected .checkmark {
            opacity: 1;
            transform: scale(1);
            animation: popIn 0.5s ease-out;
        }

        @keyframes popIn {
            0% { transform: scale(0); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }

        .submit-btn {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            padding: 15px 40px;
            border: none;
            border-radius: 50px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            margin-top: 30px;
            border: 1px solid #ffd700;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(67, 233, 123, 0.4);
        }

        .success-animation {
            text-align: center;
            padding: 40px;
            animation: fadeInUp 0.5s ease-out;
        }

        .success-animation .checkmark-circle {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: linear-gradient(135deg, #43e97b, #38f9d7);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 30px;
            animation: scaleIn 0.5s ease-out;
        }

        .success-animation .checkmark-circle i {
            font-size: 50px;
            color: #1a1f2f;
        }

        .success-animation h3 {
            color: #ffd700;
            font-size: 28px;
            margin-bottom: 15px;
        }

        .success-animation p {
            color: #4facfe;
            font-size: 18px;
            margin-bottom: 30px;
        }

        .success-animation .member-id {
            background: rgba(255, 215, 0, 0.1);
            border: 2px solid #ffd700;
            padding: 15px 30px;
            border-radius: 50px;
            display: inline-block;
            font-size: 24px;
            font-weight: bold;
            color: #ffd700;
            margin-bottom: 30px;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
        }

        .action-btn {
            padding: 12px 30px;
            border: none;
            border-radius: 50px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .action-btn.primary {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            border: 1px solid #ffd700;
        }

        .action-btn.secondary {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: #1a1f2f;
            border: 1px solid #ffd700;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        }

        #footer {
            text-align: center;
            padding: 20px;
            background: rgba(10, 15, 30, 0.95);
            color: #888;
            font-size: 14px;
            border-top: 2px solid #ffd700;
            margin-top: 50px;
        }

        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes scaleIn {
            from { transform: scale(0); }
            to { transform: scale(1); }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 1024px) {
            #container {
                grid-template-columns: 1fr;
            }
            
            #sidebar {
                position: static;
            }
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .plan-selection {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div id="header">
        <div class="header-content">
            <h1><i class="fas fa-dumbbell"></i> TABBY'S GYM</h1>
            <div class="user-info">
                <span><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($username); ?></span>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>

    <div id="container">
        <div id="sidebar">
            <ul>
                <li><a href="home.php" <?php echo ($current_page == 'home.php') ? 'class="active"' : ''; ?>>
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a></li>
                <li><a href="members.php" <?php echo ($current_page == 'members.php') ? 'class="active"' : ''; ?>>
                    <i class="fas fa-users"></i> Members
                </a></li>
                <li><a href="add_member.php" <?php echo ($current_page == 'add_member.php') ? 'class="active"' : ''; ?>>
                    <i class="fas fa-user-plus"></i> Add Member
                </a></li>
                <li><a href="plans.php" <?php echo ($current_page == 'plans.php') ? 'class="active"' : ''; ?>>
                    <i class="fas fa-calendar-alt"></i> Membership Plans
                </a></li>
                <li><a href="payments.php" <?php echo ($current_page == 'payments.php') ? 'class="active"' : ''; ?>>
                    <i class="fas fa-credit-card"></i> Payments
                </a></li>
                <li><a href="reports.php" <?php echo ($current_page == 'reports.php') ? 'class="active"' : ''; ?>>
                    <i class="fas fa-chart-bar"></i> Reports
                </a></li>
                <li><a href="settings.php" <?php echo ($current_page == 'settings.php') ? 'class="active"' : ''; ?>>
                    <i class="fas fa-cog"></i> Settings
                </a></li>
            </ul>
        </div>

        <div id="main-content">
            <div class="page-header">
                <h2><i class="fas fa-user-plus"></i> Add New Member</h2>
                <a href="members.php" class="back-link">
                    <i class="fas fa-arrow-left"></i> Back to Members
                </a>
            </div>

            <?php if($success_message): ?>
            <div class="success-animation">
                <div class="checkmark-circle">
                    <i class="fas fa-check"></i>
                </div>
                <h3>Welcome to TABBY'S GYM! 🎉</h3>
                <p><?php echo $success_message; ?></p>
                <div class="member-id">
                    <i class="fas fa-id-card"></i> <?php echo explode(': ', $success_message)[1]; ?>
                </div>
                <div class="action-buttons">
                    <a href="add_member.php" class="action-btn primary">
                        <i class="fas fa-plus"></i> Add Another Member
                    </a>
                    <a href="members.php" class="action-btn secondary">
                        <i class="fas fa-users"></i> View All Members
                    </a>
                </div>
            </div>
            <?php else: ?>

            <form method="POST" class="member-form" onsubmit="return validateForm()">
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> First Name *</label>
                        <input type="text" name="firstname" class="form-control" placeholder="Enter first name" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Surname *</label>
                        <input type="text" name="surname" class="form-control" placeholder="Enter surname" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Email Address *</label>
                        <input type="email" name="email" class="form-control" placeholder="Enter email address" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Phone Number *</label>
                        <input type="tel" name="phone" class="form-control" placeholder="+254 700 000 000" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-calendar-alt"></i> Age *</label>
                        <input type="number" name="age" class="form-control" placeholder="Enter age" min="18" max="100" required>
                    </div>
                </div>

                <label style="display: block; margin: 20px 0 10px; color: #ffd700; font-weight: bold;">
                    <i class="fas fa-crown"></i> Select Membership Plan *
                </label>
                
                <div class="plan-selection">
                    <label class="plan-card" id="basic-plan">
                        <input type="radio" name="plan" value="Basic" required>
                        <div class="checkmark"><i class="fas fa-check"></i></div>
                        <div class="plan-icon"><i class="fas fa-dumbbell"></i></div>
                        <h3>Basic Plan</h3>
                        <div class="price">KSH 500 <span>/month</span></div>
                        <ul class="features">
                            <li><i class="fas fa-check"></i> Gym Equipment Access</li>
                            <li><i class="fas fa-check"></i> Locker Room</li>
                            <li><i class="fas fa-check"></i> 6AM - 10PM Access</li>
                            <li><i class="fas fa-check"></i> Free WiFi</li>
                        </ul>
                    </label>

                    <label class="plan-card" id="premium-plan">
                        <input type="radio" name="plan" value="Premium">
                        <div class="checkmark"><i class="fas fa-check"></i></div>
                        <div class="plan-icon"><i class="fas fa-crown"></i></div>
                        <h3>Premium Plan</h3>
                        <div class="price">KSH 2,400 <span>/month</span></div>
                        <ul class="features">
                            <li><i class="fas fa-check"></i> Everything in Basic</li>
                            <li><i class="fas fa-check"></i> Personal Trainer</li>
                            <li><i class="fas fa-check"></i> Group Classes</li>
                            <li><i class="fas fa-check"></i> Nutrition Consultation</li>
                            <li><i class="fas fa-check"></i> 24/7 Access</li>
                        </ul>
                    </label>
                </div>

                <button type="submit" class="submit-btn">
                    <i class="fas fa-user-plus"></i> Register Member
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <div id="footer">
        <i class="fas fa-copyright"></i> <?php echo date('Y'); ?> @adhistabby. All rights reserved. 
        <i class="fas fa-heart" style="color: #ff6b6b;"></i> TABBY'S GYM
    </div>

    <script>
    // Plan selection animation
    const planCards = document.querySelectorAll('.plan-card');
    planCards.forEach(card => {
        card.addEventListener('click', function() {
            planCards.forEach(c => c.classList.remove('selected'));
            this.classList.add('selected');
            this.querySelector('input[type="radio"]').checked = true;
        });
    });

    // Form validation
    function validateForm() {
        const planSelected = document.querySelector('input[name="plan"]:checked');
        if (!planSelected) {
            alert('Please select a membership plan!');
            return false;
        }
        return true;
    }

    // Phone number formatting for +254
    document.querySelector('input[name="phone"]').addEventListener('input', function(e) {
        let x = e.target.value.replace(/\D/g, '');
        if (x.startsWith('254')) {
            x = x.substring(3);
        }
        if (x.startsWith('0')) {
            x = x.substring(1);
        }
        let match = x.match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
        if (match) {
            e.target.value = '+254 ' + (match[1] ? match[1] : '') + 
                             (match[2] ? ' ' + match[2] : '') + 
                             (match[3] ? ' ' + match[3] : '');
        }
    });
    </script>
</body>
</html>