<?php 
session_start();
require_once('../connection/localhost.php');

// Check if user is logged in
if (!isset($_SESSION['MM_Username'])) {
    header("Location: ../index.php");
    exit;
}

// Handle new payment
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_payment'])) {
    $member_id = intval($_POST['member_id']);
    $plan_id = intval($_POST['plan_id']);
    $amount = floatval($_POST['amount']);
    $payment_method = mysqli_real_escape_string($localhost, $_POST['payment_method']);
    $transaction_code = mysqli_real_escape_string($localhost, $_POST['transaction_code']);
    $payment_date = $_POST['payment_date'];
    
    // Calculate expiry date based on plan duration
    $plan_query = "SELECT duration_months FROM plans_tbl WHERE id = $plan_id";
    $plan_result = $localhost->query($plan_query);
    $plan = $plan_result->fetch_assoc();
    $expiry_date = date('Y-m-d', strtotime("+{$plan['duration_months']} months", strtotime($payment_date)));
    
    $query = "INSERT INTO payments_tbl (member_id, plan_id, amount, payment_date, expiry_date, payment_method, transaction_code, status) 
              VALUES ($member_id, $plan_id, $amount, '$payment_date', '$expiry_date', '$payment_method', '$transaction_code', 'Paid')";
    
    if ($localhost->query($query)) {
        $success = "Payment recorded successfully!";
    } else {
        $error = "Error recording payment: " . $localhost->error;
    }
}

// Handle payment status update
if (isset($_GET['update_status'])) {
    $id = intval($_GET['update_status']);
    $status = mysqli_real_escape_string($localhost, $_GET['status']);
    $query = "UPDATE payments_tbl SET status = '$status' WHERE id = $id";
    $localhost->query($query);
    header("Location: payments.php");
    exit;
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $query = "DELETE FROM payments_tbl WHERE id = $id";
    $localhost->query($query);
    header("Location: payments.php?msg=deleted");
    exit;
}

// Get all payments with member and plan details
$payments_query = "SELECT p.*, m.fullname, m.member_id, pl.plan_name 
                   FROM payments_tbl p
                   JOIN members_tbl m ON p.member_id = m.id
                   JOIN plans_tbl pl ON p.plan_id = pl.id
                   ORDER BY p.payment_date DESC";
$payments_result = $localhost->query($payments_query);

// Get members for dropdown
$members_query = "SELECT id, fullname, member_id FROM members_tbl WHERE status = 'Active' ORDER BY fullname";
$members_result = $localhost->query($members_query);

// Get plans for dropdown
$plans_query = "SELECT id, plan_name, price, duration_months FROM plans_tbl WHERE status = 'Active' ORDER BY price";
$plans_result = $localhost->query($plans_query);

// Calculate statistics
$total_revenue = $localhost->query("SELECT SUM(amount) as total FROM payments_tbl WHERE status = 'Paid'")->fetch_assoc()['total'] ?? 0;
$today_revenue = $localhost->query("SELECT SUM(amount) as total FROM payments_tbl WHERE payment_date = CURDATE() AND status = 'Paid'")->fetch_assoc()['total'] ?? 0;
$month_revenue = $localhost->query("SELECT SUM(amount) as total FROM payments_tbl WHERE MONTH(payment_date) = MONTH(CURDATE()) AND YEAR(payment_date) = YEAR(CURDATE()) AND status = 'Paid'")->fetch_assoc()['total'] ?? 0;
$pending_count = $localhost->query("SELECT COUNT(*) as count FROM payments_tbl WHERE status = 'Pending'")->fetch_assoc()['count'] ?? 0;

$username = $_SESSION['MM_Username'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>TABBY'S GYM - Payments</title>
    <link href="../css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a0f1e 0%, #1a1f2f 100%);
            min-height: 100vh;
            color: #fff;
        }

        #header {
            background: rgba(10, 15, 30, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 2px solid #ffd700;
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-content h1 {
            font-size: 32px;
            background: linear-gradient(45deg, #ffd700, #ff6b6b, #4facfe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
            background: linear-gradient(135deg, #2a2f3f, #1a1f2f);
            padding: 10px 20px;
            border-radius: 50px;
            border: 1px solid #ffd700;
        }

        .logout-btn {
            background: linear-gradient(45deg, #ff6b6b, #ff4757);
            color: white;
            padding: 8px 25px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: bold;
            border: 1px solid #ffd700;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(255, 107, 107, 0.5);
        }

        #container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 30px;
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 30px;
        }

        #sidebar {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px 15px;
            border: 1px solid #4facfe;
            height: fit-content;
            position: sticky;
            top: 100px;
        }

        #sidebar ul {
            list-style: none;
        }

        #sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: #ccc;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s;
        }

        #sidebar ul li a i {
            width: 24px;
            color: #ffd700;
        }

        #sidebar ul li a:hover,
        #sidebar ul li a.active {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: #fff;
        }

        #main-content {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            border: 1px solid #ffd700;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #4facfe;
        }

        .page-header h2 {
            color: #ffd700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .add-btn {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            padding: 12px 25px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 10px;
            border: 1px solid #ffd700;
            cursor: pointer;
            transition: all 0.3s;
        }

        .add-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(67, 233, 123, 0.4);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.5s ease-out;
        }

        .alert-success {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            border: 1px solid #ffd700;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: rgba(30, 35, 50, 0.8);
            border-radius: 15px;
            padding: 20px;
            border-left: 4px solid #4facfe;
            transition: all 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(79, 172, 254, 0.3);
        }

        .stat-card:nth-child(1) { border-left-color: #4facfe; }
        .stat-card:nth-child(2) { border-left-color: #43e97b; }
        .stat-card:nth-child(3) { border-left-color: #ffd700; }
        .stat-card:nth-child(4) { border-left-color: #ff6b6b; }

        .stat-title {
            color: #ccc;
            font-size: 14px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .stat-title i {
            color: #4facfe;
        }

        .stat-value {
            font-size: 28px;
            font-weight: bold;
            color: #fff;
        }

        .stat-label {
            font-size: 12px;
            color: #888;
            margin-top: 5px;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(5px);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: linear-gradient(135deg, #1a1f2f, #2a2f3f);
            border-radius: 20px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
            border: 2px solid #ffd700;
            box-shadow: 0 10px 40px rgba(255, 215, 0, 0.3);
            animation: modalPop 0.3s ease-out;
        }

        @keyframes modalPop {
            from { transform: scale(0.8); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #4facfe;
        }

        .modal-header h3 {
            color: #ffd700;
            font-size: 24px;
        }

        .close-btn {
            background: none;
            border: none;
            color: #ff6b6b;
            font-size: 24px;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #ffd700;
            font-weight: bold;
        }

        .form-group label i {
            color: #4facfe;
            margin-right: 8px;
        }

        .form-control, .form-select {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid #4facfe;
            border-radius: 10px;
            color: #fff;
            font-size: 16px;
        }

        .form-select option {
            background: #1a1f2f;
            color: #fff;
        }

        .form-control:focus, .form-select:focus {
            outline: none;
            border-color: #ffd700;
            box-shadow: 0 0 20px rgba(255, 215, 0, 0.3);
        }

        .submit-btn {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            border: 1px solid #ffd700;
            transition: all 0.3s;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(67, 233, 123, 0.4);
        }

        /* Payment Methods Icons */
        .payment-methods {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 20px;
        }

        .payment-method {
            background: rgba(30, 35, 50, 0.8);
            border: 2px solid #4facfe;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }

        .payment-method.selected {
            border-color: #ffd700;
            background: linear-gradient(135deg, rgba(79,172,254,0.2), rgba(255,215,0,0.2));
            transform: scale(1.05);
        }

        .payment-method i {
            font-size: 24px;
            color: #4facfe;
            margin-bottom: 5px;
        }

        .payment-method.selected i {
            color: #ffd700;
        }

        .payment-method span {
            display: block;
            font-size: 14px;
            color: #ccc;
        }

        /* Transactions Table */
        .transactions-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 10px;
            margin-top: 30px;
        }

        .transactions-table th {
            padding: 15px;
            text-align: left;
            color: #ffd700;
            font-weight: bold;
            border-bottom: 2px solid #4facfe;
        }

        .transactions-table td {
            padding: 15px;
            background: rgba(30, 35, 50, 0.8);
            border-radius: 10px;
            color: #fff;
        }

        .transactions-table tbody tr:hover td {
            background: rgba(40, 45, 60, 0.9);
            transform: scale(1.01);
            transition: all 0.3s;
        }

        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            display: inline-block;
        }

        .status-paid {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
        }

        .status-pending {
            background: linear-gradient(135deg, #ffd700 0%, #ffb347 100%);
            color: #1a1f2f;
        }

        .status-cancelled {
            background: linear-gradient(135deg, #ff6b6b 0%, #ff4757 100%);
            color: #fff;
        }

        .payment-method-badge {
            display: flex;
            align-items: center;
            gap: 5px;
            padding: 5px 10px;
            border-radius: 20px;
            background: rgba(79, 172, 254, 0.2);
            color: #4facfe;
            font-size: 12px;
        }

        .payment-method-badge i {
            font-size: 14px;
        }

        .action-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            color: #fff;
            font-size: 12px;
            margin: 0 2px;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }

        .action-btn i {
            font-size: 12px;
        }

        .btn-edit {
            background: #4facfe;
        }

        .btn-delete {
            background: #ff6b6b;
        }

        .btn-status {
            background: #ffd700;
            color: #1a1f2f;
        }

        #footer {
            text-align: center;
            padding: 20px;
            background: rgba(10, 15, 30, 0.95);
            color: #888;
            border-top: 2px solid #ffd700;
            margin-top: 50px;
        }

        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @media (max-width: 1024px) {
            #container {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .transactions-table {
                display: block;
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
    <div id="header">
        <div class="header-content">
            <h1><i class="fas fa-dumbbell"></i> TABBY'S GYM</h1>
            <div class="user-info">
                <span><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($username); ?></span>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>

    <div id="container">
        <div id="sidebar">
            <ul>
                <li><a href="home.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="members.php"><i class="fas fa-users"></i> Members</a></li>
                <li><a href="add_member.php"><i class="fas fa-user-plus"></i> Add Member</a></li>
                <li><a href="plans.php"><i class="fas fa-calendar-alt"></i> Membership Plans</a></li>
                <li><a href="payments.php" class="active"><i class="fas fa-credit-card"></i> Payments</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
            </ul>
        </div>

        <div id="main-content">
            <?php if(isset($success)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <div class="page-header">
                <h2><i class="fas fa-credit-card"></i> Payments & Transactions</h2>
                <button class="add-btn" onclick="openAddModal()">
                    <i class="fas fa-plus"></i> Record Payment
                </button>
            </div>

            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-title">
                        <i class="fas fa-coins"></i> Total Revenue
                    </div>
                    <div class="stat-value">KSH <?php echo number_format($total_revenue, 2); ?></div>
                    <div class="stat-label">All time</div>
                </div>
                <div class="stat-card">
                    <div class="stat-title">
                        <i class="fas fa-calendar-day"></i> Today
                    </div>
                    <div class="stat-value">KSH <?php echo number_format($today_revenue, 2); ?></div>
                    <div class="stat-label"><?php echo date('M d, Y'); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-title">
                        <i class="fas fa-calendar-month"></i> This Month
                    </div>
                    <div class="stat-value">KSH <?php echo number_format($month_revenue, 2); ?></div>
                    <div class="stat-label"><?php echo date('F Y'); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-title">
                        <i class="fas fa-clock"></i> Pending
                    </div>
                    <div class="stat-value"><?php echo $pending_count; ?></div>
                    <div class="stat-label">Awaiting confirmation</div>
                </div>
            </div>

            <!-- Transactions Table -->
            <table class="transactions-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Member</th>
                        <th>Plan</th>
                        <th>Amount</th>
                        <th>Payment Method</th>
                        <th>Transaction Code</th>
                        <th>Expiry Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($payments_result->num_rows == 0): ?>
                        <tr>
                            <td colspan="9" style="text-align: center; padding: 50px;">
                                <i class="fas fa-credit-card" style="font-size: 50px; color: #4facfe; margin-bottom: 20px;"></i>
                                <h3 style="color: #ccc;">No payments recorded yet</h3>
                                <p style="color: #888;">Click "Record Payment" to add your first transaction</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php while($payment = $payments_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo date('d/m/Y', strtotime($payment['payment_date'])); ?></td>
                            <td>
                                <strong><?php echo $payment['fullname']; ?></strong><br>
                                <small style="color: #888;"><?php echo $payment['member_id']; ?></small>
                            </td>
                            <td><?php echo $payment['plan_name']; ?></td>
                            <td><strong>KSH <?php echo number_format($payment['amount'], 2); ?></strong></td>
                            <td>
                                <span class="payment-method-badge">
                                    <?php 
                                    $method = $payment['payment_method'];
                                    $icon = 'credit-card';
                                    if ($method == 'M-PESA') $icon = 'mobile-alt';
                                    if ($method == 'Airtel Money') $icon = 'mobile';
                                    if ($method == 'Bank Transfer') $icon = 'university';
                                    ?>
                                    <i class="fas fa-<?php echo $icon; ?>"></i>
                                    <?php echo $method; ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($payment['transaction_code']): ?>
                                    <span style="color: #ffd700;"><?php echo $payment['transaction_code']; ?></span>
                                <?php else: ?>
                                    <span style="color: #888;">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php 
                                $expiry = strtotime($payment['expiry_date']);
                                $now = time();
                                $days_left = ceil(($expiry - $now) / (60 * 60 * 24));
                                
                                if ($days_left < 0) {
                                    echo '<span style="color: #ff6b6b;">Expired</span>';
                                } elseif ($days_left < 7) {
                                    echo '<span style="color: #ffd700;">' . $days_left . ' days</span>';
                                } else {
                                    echo date('d/m/Y', $expiry);
                                }
                                ?>
                            </td>
                            <td>
                                <span class="status-badge status-<?php echo strtolower($payment['status']); ?>">
                                    <?php echo $payment['status']; ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($payment['status'] == 'Pending'): ?>
                                    <a href="?update_status=<?php echo $payment['id']; ?>&status=Paid" class="action-btn btn-status" onclick="return confirm('Mark as paid?')">
                                        <i class="fas fa-check"></i>
                                    </a>
                                <?php endif; ?>
                                <a href="?delete=<?php echo $payment['id']; ?>" class="action-btn btn-delete" onclick="return confirm('Delete this payment?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Payment Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-plus-circle"></i> Record Payment</h3>
                <button class="close-btn" onclick="closeAddModal()">&times;</button>
            </div>
            <form method="POST" onsubmit="return validatePayment()">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Member</label>
                    <select name="member_id" class="form-select" required>
                        <option value="">Select Member</option>
                        <?php while($member = $members_result->fetch_assoc()): ?>
                        <option value="<?php echo $member['id']; ?>">
                            <?php echo $member['fullname']; ?> (<?php echo $member['member_id']; ?>)
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-tag"></i> Membership Plan</label>
                    <select name="plan_id" class="form-select" id="planSelect" onchange="updateAmount()" required>
                        <option value="">Select Plan</option>
                        <?php while($plan = $plans_result->fetch_assoc()): ?>
                        <option value="<?php echo $plan['id']; ?>" data-price="<?php echo $plan['price']; ?>">
                            <?php echo $plan['plan_name']; ?> - KSH <?php echo number_format($plan['price'], 0); ?> 
                            (<?php echo $plan['duration_months']; ?> months)
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-coins"></i> Amount (KSH)</label>
                    <input type="number" name="amount" id="amount" class="form-control" required min="0" step="100">
                </div>

                <div class="form-group">
                    <label><i class="fas fa-calendar"></i> Payment Date</label>
                    <input type="date" name="payment_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-credit-card"></i> Payment Method</label>
                    <div class="payment-methods">
                        <div class="payment-method" onclick="selectMethod('M-PESA')">
                            <i class="fas fa-mobile-alt"></i>
                            <span>M-PESA</span>
                        </div>
                        <div class="payment-method" onclick="selectMethod('Airtel Money')">
                            <i class="fas fa-mobile"></i>
                            <span>Airtel Money</span>
                        </div>
                        <div class="payment-method" onclick="selectMethod('Bank Transfer')">
                            <i class="fas fa-university"></i>
                            <span>Bank Transfer</span>
                        </div>
                    </div>
                    <input type="hidden" name="payment_method" id="payment_method" required>
                </div>

                <div class="form-group" id="transaction_code_group">
                    <label><i class="fas fa-code"></i> Transaction Code</label>
                    <input type="text" name="transaction_code" class="form-control" placeholder="Enter transaction code">
                </div>

                <button type="submit" name="add_payment" class="submit-btn">
                    <i class="fas fa-save"></i> Record Payment
                </button>
            </form>
        </div>
    </div>

    <div id="footer">
        <i class="fas fa-copyright"></i> <?php echo date('Y'); ?> @adhistabby. All rights reserved.
    </div>

    <script>
        function openAddModal() {
            document.getElementById('addModal').classList.add('active');
        }

        function closeAddModal() {
            document.getElementById('addModal').classList.remove('active');
        }

        function selectMethod(method) {
            document.querySelectorAll('.payment-method').forEach(el => {
                el.classList.remove('selected');
            });
            event.currentTarget.classList.add('selected');
            document.getElementById('payment_method').value = method;
        }

        function updateAmount() {
            const select = document.getElementById('planSelect');
            const selected = select.options[select.selectedIndex];
            if (selected && selected.dataset.price) {
                document.getElementById('amount').value = selected.dataset.price;
            }
        }

        function validatePayment() {
            const method = document.getElementById('payment_method').value;
            if (!method) {
                alert('Please select a payment method!');
                return false;
            }
            return true;
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
</body>
</html>