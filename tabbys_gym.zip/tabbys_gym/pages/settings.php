<?php 
session_start();
require_once('../connection/localhost.php');

// Check if user is logged in
if (!isset($_SESSION['MM_Username'])) {
    header("Location: ../index.php");
    exit;
}

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_gym'])) {
        $gym_name = mysqli_real_escape_string($localhost, $_POST['gym_name']);
        $gym_email = mysqli_real_escape_string($localhost, $_POST['gym_email']);
        $gym_phone = mysqli_real_escape_string($localhost, $_POST['gym_phone']);
        $gym_address = mysqli_real_escape_string($localhost, $_POST['gym_address']);
        $currency = mysqli_real_escape_string($localhost, $_POST['currency']);
        
        // Save to session or database - for now just show success
        $_SESSION['gym_name'] = $gym_name;
        $success = "Gym settings updated successfully!";
    }
    
    if (isset($_POST['change_password'])) {
        $current = $_POST['current_password'];
        $new = $_POST['new_password'];
        $confirm = $_POST['confirm_password'];
        
        $username = $_SESSION['MM_Username'];
        $check = $localhost->query("SELECT * FROM admin_tbl WHERE username='$username' AND password=MD5('$current')");
        
        if ($check->num_rows > 0) {
            if ($new == $confirm) {
                $localhost->query("UPDATE admin_tbl SET password=MD5('$new') WHERE username='$username'");
                $success = "Password changed successfully!";
            } else {
                $error = "New passwords do not match!";
            }
        } else {
            $error = "Current password is incorrect!";
        }
    }
    
    if (isset($_POST['update_notifications'])) {
        $email_notify = isset($_POST['email_notify']) ? 1 : 0;
        $sms_notify = isset($_POST['sms_notify']) ? 1 : 0;
        $payment_alert = isset($_POST['payment_alert']) ? 1 : 0;
        $expiry_alert = isset($_POST['expiry_alert']) ? 1 : 0;
        
        // Save settings
        $success = "Notification settings updated!";
    }
}

$username = $_SESSION['MM_Username'];
$gym_name = isset($_SESSION['gym_name']) ? $_SESSION['gym_name'] : 'TABBY\'S GYM';
?>

<!DOCTYPE html>
<html>
<head>
    <title>TABBY'S GYM - Settings</title>
    <link href="../css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a0f1e 0%, #1a1f2f 100%);
            min-height: 100vh;
            color: #fff;
        }

        #header {
            background: rgba(10, 15, 30, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 2px solid #ffd700;
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-content h1 {
            font-size: 32px;
            background: linear-gradient(45deg, #ffd700, #ff6b6b, #4facfe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
            background: linear-gradient(135deg, #2a2f3f, #1a1f2f);
            padding: 10px 20px;
            border-radius: 50px;
            border: 1px solid #ffd700;
        }

        .logout-btn {
            background: linear-gradient(45deg, #ff6b6b, #ff4757);
            color: white;
            padding: 8px 25px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: bold;
            border: 1px solid #ffd700;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(255, 107, 107, 0.5);
        }

        #container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 30px;
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 30px;
        }

        #sidebar {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px 15px;
            border: 1px solid #4facfe;
            height: fit-content;
            position: sticky;
            top: 100px;
        }

        #sidebar ul {
            list-style: none;
        }

        #sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: #ccc;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s;
        }

        #sidebar ul li a i {
            width: 24px;
            color: #ffd700;
        }

        #sidebar ul li a:hover,
        #sidebar ul li a.active {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: #fff;
        }

        #main-content {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            border: 1px solid #ffd700;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #4facfe;
        }

        .page-header h2 {
            color: #ffd700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.5s ease-out;
        }

        .alert-success {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            border: 1px solid #ffd700;
        }

        .alert-error {
            background: linear-gradient(135deg, #ff6b6b 0%, #ff4757 100%);
            color: #fff;
            border: 1px solid #ffd700;
        }

        .settings-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 30px;
        }

        .settings-card {
            background: rgba(30, 35, 50, 0.8);
            border-radius: 15px;
            padding: 25px;
            border: 1px solid #4facfe;
            transition: all 0.3s;
        }

        .settings-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(79, 172, 254, 0.3);
        }

        .card-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #ffd700;
        }

        .card-header i {
            font-size: 30px;
            color: #4facfe;
        }

        .card-header h3 {
            color: #ffd700;
            font-size: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #ffd700;
        }

        .form-group label i {
            color: #4facfe;
            margin-right: 8px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid #4facfe;
            border-radius: 8px;
            color: #fff;
            font-size: 16px;
        }

        .form-control:focus {
            outline: none;
            border-color: #ffd700;
        }

        .checkbox-group {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .checkbox-item input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        .checkbox-item label {
            color: #fff;
            cursor: pointer;
        }

        .btn-save {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            border: 1px solid #ffd700;
            width: 100%;
            font-size: 16px;
            transition: all 0.3s;
        }

        .btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(67, 233, 123, 0.4);
        }

        #footer {
            text-align: center;
            padding: 20px;
            background: rgba(10, 15, 30, 0.95);
            color: #888;
            border-top: 2px solid #ffd700;
            margin-top: 50px;
        }

        @media (max-width: 1024px) {
            #container {
                grid-template-columns: 1fr;
            }
            
            .settings-grid {
                grid-template-columns: 1fr;
            }
        }

        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
    <div id="header">
        <div class="header-content">
            <h1><i class="fas fa-dumbbell"></i> <?php echo $gym_name; ?></h1>
            <div class="user-info">
                <span><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($username); ?></span>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>

    <div id="container">
        <div id="sidebar">
            <ul>
                <li><a href="home.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="members.php"><i class="fas fa-users"></i> Members</a></li>
                <li><a href="add_member.php"><i class="fas fa-user-plus"></i> Add Member</a></li>
                <li><a href="plans.php"><i class="fas fa-calendar-alt"></i> Membership Plans</a></li>
                <li><a href="payments.php"><i class="fas fa-credit-card"></i> Payments</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="settings.php" class="active"><i class="fas fa-cog"></i> Settings</a></li>
            </ul>
        </div>

        <div id="main-content">
            <div class="page-header">
                <h2><i class="fas fa-cog"></i> System Settings</h2>
            </div>

            <?php if(isset($success)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <?php if(isset($error)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <div class="settings-grid">
                <!-- Gym Information -->
                <div class="settings-card">
                    <div class="card-header">
                        <i class="fas fa-dumbbell"></i>
                        <h3>Gym Information</h3>
                    </div>
                    <form method="POST">
                        <div class="form-group">
                            <label><i class="fas fa-store"></i> Gym Name</label>
                            <input type="text" name="gym_name" class="form-control" value="<?php echo $gym_name; ?>" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-envelope"></i> Email Address</label>
                            <input type="email" name="gym_email" class="form-control" value="info@tabbysgym.com">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-phone"></i> Phone Number</label>
                            <input type="text" name="gym_phone" class="form-control" value="+254 700 000 000" placeholder="+254 700 000 000">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-map-marker-alt"></i> Address</label>
                            <input type="text" name="gym_address" class="form-control" value="Nairobi, Kenya">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-coins"></i> Currency</label>
                            <select name="currency" class="form-control">
                                <option value="KSH" selected>KSH - Kenyan Shilling</option>
                                <option value="USD">USD - US Dollar</option>
                            </select>
                        </div>
                        <button type="submit" name="update_gym" class="btn-save">
                            <i class="fas fa-save"></i> Save Gym Settings
                        </button>
                    </form>
                </div>

                <!-- Change Password -->
                <div class="settings-card">
                    <div class="card-header">
                        <i class="fas fa-lock"></i>
                        <h3>Change Password</h3>
                    </div>
                    <form method="POST">
                        <div class="form-group">
                            <label><i class="fas fa-key"></i> Current Password</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-lock"></i> New Password</label>
                            <input type="password" name="new_password" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-check-circle"></i> Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        <button type="submit" name="change_password" class="btn-save">
                            <i class="fas fa-sync"></i> Update Password
                        </button>
                    </form>
                </div>

                <!-- Notification Settings -->
                <div class="settings-card">
                    <div class="card-header">
                        <i class="fas fa-bell"></i>
                        <h3>Notifications</h3>
                    </div>
                    <form method="POST">
                        <div class="checkbox-group">
                            <div class="checkbox-item">
                                <input type="checkbox" name="email_notify" id="email_notify" checked>
                                <label for="email_notify">Email Notifications</label>
                            </div>
                            <div class="checkbox-item">
                                <input type="checkbox" name="sms_notify" id="sms_notify">
                                <label for="sms_notify">SMS Notifications</label>
                            </div>
                            <div class="checkbox-item">
                                <input type="checkbox" name="payment_alert" id="payment_alert" checked>
                                <label for="payment_alert">Payment Alerts</label>
                            </div>
                            <div class="checkbox-item">
                                <input type="checkbox" name="expiry_alert" id="expiry_alert" checked>
                                <label for="expiry_alert">Membership Expiry Alerts</label>
                            </div>
                            <div class="checkbox-item">
                                <input type="checkbox" name="birthday_alert" id="birthday_alert">
                                <label for="birthday_alert">Birthday Wishes</label>
                            </div>
                        </div>
                        <button type="submit" name="update_notifications" class="btn-save" style="margin-top: 20px;">
                            <i class="fas fa-bell"></i> Save Notification Settings
                        </button>
                    </form>
                </div>

                <!-- System Preferences -->
                <div class="settings-card">
                    <div class="card-header">
                        <i class="fas fa-sliders-h"></i>
                        <h3>System Preferences</h3>
                    </div>
                    <form>
                        <div class="form-group">
                            <label><i class="fas fa-globe"></i> Language</label>
                            <select class="form-control">
                                <option>English</option>
                                <option>Swahili</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-clock"></i> Timezone</label>
                            <select class="form-control">
                                <option>Africa/Nairobi (UTC+3)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-calendar"></i> Date Format</label>
                            <select class="form-control">
                                <option>DD/MM/YYYY</option>
                                <option>MM/DD/YYYY</option>
                            </select>
                        </div>
                        <div class="checkbox-item" style="margin: 15px 0;">
                            <input type="checkbox" id="auto_backup" checked>
                            <label for="auto_backup">Automatic daily backup</label>
                        </div>
                        <button type="button" class="btn-save" onclick="alert('Preferences saved!')">
                            <i class="fas fa-save"></i> Save Preferences
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div id="footer">
        <i class="fas fa-copyright"></i> <?php echo date('Y'); ?> @adhistabby. All rights reserved.
    </div>

    <script>
    // Phone number formatting for +254
    document.querySelectorAll('input[type="tel"]').forEach(input => {
        input.addEventListener('input', function(e) {
            let x = e.target.value.replace(/\D/g, '');
            if (x.startsWith('254')) {
                x = x.substring(3);
            }
            if (x.startsWith('0')) {
                x = x.substring(1);
            }
            let match = x.match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
            if (match) {
                e.target.value = '+254 ' + (match[1] ? match[1] : '') + 
                                 (match[2] ? ' ' + match[2] : '') + 
                                 (match[3] ? ' ' + match[3] : '');
            }
        });
    });
    </script>
</body>
</html>