<?php 
session_start();
require_once('../connection/localhost.php');

// Check if user is logged in
if (!isset($_SESSION['MM_Username'])) {
    header("Location: ../index.php");
    exit;
}

$success_message = '';
$error_message = '';
$member = null;

// Get member ID from URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $member_id = intval($_GET['id']);
    
    // Fetch member details
    $query = "SELECT * FROM members_tbl WHERE id = $member_id";
    $result = $localhost->query($query);
    
    if ($result->num_rows > 0) {
        $member = $result->fetch_assoc();
        
        // Calculate age from date of birth
        $dob = new DateTime($member['date_of_birth']);
        $now = new DateTime();
        $age = $now->diff($dob)->y;
        
        // Split fullname into firstname and surname
        $name_parts = explode(' ', $member['fullname']);
        $firstname = $name_parts[0];
        $surname = isset($name_parts[1]) ? $name_parts[1] : '';
    } else {
        header("Location: members.php?error=notfound");
        exit;
    }
} else {
    header("Location: members.php");
    exit;
}

// Handle form submission for editing member
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_member'])) {
    $firstname = mysqli_real_escape_string($localhost, $_POST['firstname']);
    $surname = mysqli_real_escape_string($localhost, $_POST['surname']);
    $fullname = $firstname . ' ' . $surname;
    $email = mysqli_real_escape_string($localhost, $_POST['email']);
    $phone = mysqli_real_escape_string($localhost, $_POST['phone']);
    $age = intval($_POST['age']);
    
    // Calculate date of birth from age
    $dob = date('Y-m-d', strtotime("-$age years"));
    
    // Update member details ONLY (keeping existing plan and status)
    $update_query = "UPDATE members_tbl SET 
                     fullname = '$fullname',
                     email = '$email',
                     phone = '$phone',
                     date_of_birth = '$dob'
                     WHERE id = $member_id";
    
    if ($localhost->query($update_query)) {
        $success_message = "Member details updated successfully!";
        
        // Refresh member data
        $query = "SELECT * FROM members_tbl WHERE id = $member_id";
        $result = $localhost->query($query);
        $member = $result->fetch_assoc();
        
        // Recalculate age
        $dob = new DateTime($member['date_of_birth']);
        $now = new DateTime();
        $age = $now->diff($dob)->y;
        
        // Re-split name
        $name_parts = explode(' ', $member['fullname']);
        $firstname = $name_parts[0];
        $surname = isset($name_parts[1]) ? $name_parts[1] : '';
    } else {
        $error_message = "Error updating member: " . $localhost->error;
    }
}

$username = $_SESSION['MM_Username'];
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html>
<head>
    <title>TABBY'S GYM - Edit Member</title>
    <link href="../css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a0f1e 0%, #1a1f2f 100%);
            min-height: 100vh;
            color: #fff;
        }

        #header {
            background: rgba(10, 15, 30, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 2px solid #ffd700;
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-content h1 {
            font-size: 32px;
            background: linear-gradient(45deg, #ffd700, #ff6b6b, #4facfe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-transform: uppercase;
            letter-spacing: 3px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
            background: linear-gradient(135deg, #2a2f3f, #1a1f2f);
            padding: 10px 20px;
            border-radius: 50px;
            border: 1px solid #ffd700;
        }

        .user-info span {
            color: #4facfe;
            font-weight: bold;
        }

        .user-info span i {
            color: #ffd700;
            margin-right: 8px;
        }

        .logout-btn {
            background: linear-gradient(45deg, #ff6b6b, #ff4757);
            color: white;
            padding: 8px 25px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: bold;
            border: 1px solid #ffd700;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(255, 107, 107, 0.5);
        }

        #container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 30px;
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 30px;
        }

        #sidebar {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px 15px;
            border: 1px solid #4facfe;
            height: fit-content;
            position: sticky;
            top: 100px;
        }

        #sidebar ul {
            list-style: none;
        }

        #sidebar ul li {
            margin-bottom: 10px;
        }

        #sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: #ccc;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s;
        }

        #sidebar ul li a i {
            width: 24px;
            color: #ffd700;
        }

        #sidebar ul li a:hover {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: #fff;
            transform: translateX(5px);
        }

        #sidebar ul li a.active {
            background: linear-gradient(135deg, #ffd700 0%, #ffb347 100%);
            color: #1a1f2f;
            font-weight: bold;
        }

        #sidebar ul li a.active i {
            color: #1a1f2f;
        }

        #main-content {
            background: rgba(20, 25, 40, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            border: 1px solid #ffd700;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #4facfe;
        }

        .page-header h2 {
            color: #ffd700;
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .page-header h2 i {
            color: #4facfe;
        }

        .member-id-badge {
            background: rgba(255, 215, 0, 0.1);
            border: 1px solid #ffd700;
            padding: 8px 20px;
            border-radius: 50px;
            color: #ffd700;
            font-weight: bold;
        }

        .member-id-badge i {
            margin-right: 8px;
            color: #4facfe;
        }

        .back-link {
            color: #4facfe;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 15px;
            border-radius: 8px;
            background: rgba(79, 172, 254, 0.1);
            transition: all 0.3s;
        }

        .back-link:hover {
            background: rgba(79, 172, 254, 0.2);
            transform: translateX(-5px);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.5s ease-out;
        }

        .alert-success {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
            border: 1px solid #ffd700;
        }

        .alert-error {
            background: linear-gradient(135deg, #ff6b6b 0%, #ff4757 100%);
            color: #fff;
            border: 1px solid #ffd700;
        }

        .edit-form {
            max-width: 800px;
            margin: 0 auto;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #ffd700;
            font-weight: bold;
            font-size: 16px;
        }

        .form-group label i {
            color: #4facfe;
            margin-right: 8px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid #4facfe;
            border-radius: 10px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: #ffd700;
            box-shadow: 0 0 20px rgba(255, 215, 0, 0.3);
            background: rgba(255, 255, 255, 0.15);
        }

        .form-control[readonly] {
            background: rgba(255, 255, 255, 0.05);
            border-color: #666;
            cursor: not-allowed;
        }

        .info-box {
            background: rgba(79, 172, 254, 0.1);
            border: 1px solid #4facfe;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .info-box i {
            font-size: 40px;
            color: #ffd700;
        }

        .info-box p {
            color: #ccc;
            line-height: 1.6;
        }

        .info-box strong {
            color: #ffd700;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            text-decoration: none;
            border: 1px solid #ffd700;
        }

        .btn-primary {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #1a1f2f;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(67, 233, 123, 0.4);
        }

        .btn-secondary {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: #1a1f2f;
        }

        .btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(79, 172, 254, 0.4);
        }

        #footer {
            text-align: center;
            padding: 20px;
            background: rgba(10, 15, 30, 0.95);
            color: #888;
            border-top: 2px solid #ffd700;
            margin-top: 50px;
        }

        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @media (max-width: 1024px) {
            #container {
                grid-template-columns: 1fr;
            }
            
            #sidebar {
                position: static;
            }
            
            #sidebar ul {
                display: flex;
                flex-wrap: wrap;
            }
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div id="header">
        <div class="header-content">
            <h1><i class="fas fa-dumbbell"></i> TABBY'S GYM</h1>
            <div class="user-info">
                <span><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($username); ?></span>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>

    <div id="container">
        <div id="sidebar">
            <ul>
                <li><a href="home.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="members.php"><i class="fas fa-users"></i> Members</a></li>
                <li><a href="add_member.php"><i class="fas fa-user-plus"></i> Add Member</a></li>
                <li><a href="plans.php"><i class="fas fa-calendar-alt"></i> Membership Plans</a></li>
                <li><a href="payments.php"><i class="fas fa-credit-card"></i> Payments</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
            </ul>
        </div>

        <div id="main-content">
            <div class="page-header">
                <h2><i class="fas fa-edit"></i> Edit Member Details</h2>
                <div style="display: flex; gap: 15px;">
                    <span class="member-id-badge">
                        <i class="fas fa-id-card"></i> <?php echo $member['member_id']; ?>
                    </span>
                    <a href="members.php" class="back-link">
                        <i class="fas fa-arrow-left"></i> Back to Members
                    </a>
                </div>
            </div>

            <?php if($success_message): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
                </div>
            <?php endif; ?>

            <?php if($error_message): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <!-- Info Box - Shows what can be edited -->
            <div class="info-box">
                <i class="fas fa-info-circle"></i>
                <p>
                    <strong>You can edit:</strong> First Name, Surname, Email Address, Phone Number, and Age.<br>
                    <strong>Member ID, Join Date, and Status</strong> cannot be edited here (use Activate/Deactivate on members page).
                </p>
            </div>

            <form method="POST" class="edit-form">
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> First Name *</label>
                        <input type="text" name="firstname" class="form-control" 
                               value="<?php echo htmlspecialchars($firstname); ?>" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Surname *</label>
                        <input type="text" name="surname" class="form-control" 
                               value="<?php echo htmlspecialchars($surname); ?>" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Email Address *</label>
                        <input type="email" name="email" class="form-control" 
                               value="<?php echo htmlspecialchars($member['email']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Phone Number *</label>
                        <input type="tel" name="phone" class="form-control" 
                               value="<?php echo htmlspecialchars($member['phone']); ?>" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-calendar-alt"></i> Age *</label>
                        <input type="number" name="age" class="form-control" 
                               value="<?php echo $age; ?>" min="18" max="100" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-calendar"></i> Join Date</label>
                        <input type="text" class="form-control" 
                               value="<?php echo date('d M Y', strtotime($member['join_date'])); ?>" readonly>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-tag"></i> Current Status</label>
                        <input type="text" class="form-control" 
                               value="<?php echo $member['status']; ?>" readonly>
                    </div>
                </div>

                <div class="action-buttons">
                    <button type="submit" name="update_member" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                    <a href="members.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>

    <div id="footer">
        <i class="fas fa-copyright"></i> <?php echo date('Y'); ?> @adhistabby. All rights reserved.
    </div>

    <script>
    // Phone number formatting for +254
    document.querySelector('input[name="phone"]').addEventListener('input', function(e) {
        let x = e.target.value.replace(/\D/g, '');
        if (x.startsWith('254')) {
            x = x.substring(3);
        }
        if (x.startsWith('0')) {
            x = x.substring(1);
        }
        let match = x.match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
        if (match) {
            e.target.value = '+254 ' + (match[1] ? match[1] : '') + 
                             (match[2] ? ' ' + match[2] : '') + 
                             (match[3] ? ' ' + match[3] : '');
        }
    });

    // Format phone on page load
    window.addEventListener('load', function() {
        const phoneInput = document.querySelector('input[name="phone"]');
        if (phoneInput) {
            let event = new Event('input');
            phoneInput.dispatchEvent(event);
        }
    });
    </script>
</body>
</html>