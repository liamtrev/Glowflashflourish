<?php
echo "Current directory: " . __DIR__ . "<br>";
echo "Checking if files exist:<br><br>";

$files_to_check = [
    'connection/localhost.php',
    'connections/localhost.php',
    'Connections/localhost.php',
    'connection/test.php'
];

foreach ($files_to_check as $file) {
    if (file_exists($file)) {
        echo "✅ FOUND: " . $file . "<br>";
    } else {
        echo "❌ NOT FOUND: " . $file . "<br>";
    }
}
?>