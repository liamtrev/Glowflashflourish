-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2024-01-15
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gym_management`
--
CREATE DATABASE IF NOT EXISTS `gym_management` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `gym_management`;

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`id`, `username`, `password`, `fullname`, `email`, `created_at`) VALUES
(1, 'admin', MD5('admin123'), 'Tabby Adhi', 'admin@tabbysgym.com', '2024-01-15 00:00:00'),
(2, 'tabby', MD5('tabby123'), 'Tabby Administrator', 'tabby@tabbysgym.com', '2024-01-15 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `members_tbl`
--

CREATE TABLE `members_tbl` (
  `id` int(11) NOT NULL,
  `member_id` varchar(20) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text DEFAULT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `join_date` date NOT NULL,
  `status` enum('Active','Inactive','Suspended') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members_tbl`
--

INSERT INTO `members_tbl` (`id`, `member_id`, `fullname`, `email`, `phone`, `address`, `gender`, `date_of_birth`, `join_date`, `status`, `created_at`) VALUES
(1, 'TGM-2024-0001', 'John Smith', 'john.smith@email.com', '09123456789', '123 Main St, Manila', 'Male', '1990-05-15', '2024-01-15', 'Active', '2024-01-15 00:00:00'),
(2, 'TGM-2024-0002', 'Maria Garcia', 'maria.garcia@email.com', '09234567890', '456 Oak Ave, Quezon City', 'Female', '1988-08-22', '2024-01-16', 'Active', '2024-01-16 00:00:00'),
(3, 'TGM-2024-0003', 'James Wilson', 'james.w@email.com', '09345678901', '789 Pine St, Makati', 'Male', '1995-03-10', '2024-01-17', 'Active', '2024-01-17 00:00:00'),
(4, 'TGM-2024-0004', 'Sarah Brown', 'sarah.b@email.com', '09456789012', '321 Elm St, BGC', 'Female', '1992-11-30', '2024-01-18', 'Inactive', '2024-01-18 00:00:00'),
(5, 'TGM-2024-0005', 'Mike Johnson', 'mike.j@email.com', '09567890123', '654 Cedar Rd, Pasig', 'Male', '1987-07-25', '2024-01-19', 'Active', '2024-01-19 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `plans_tbl`
--

CREATE TABLE `plans_tbl` (
  `id` int(11) NOT NULL,
  `plan_name` varchar(100) NOT NULL,
  `duration_months` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `plans_tbl`
--

INSERT INTO `plans_tbl` (`id`, `plan_name`, `duration_months`, `price`, `description`, `status`) VALUES
(1, 'Basic Plan', 1, 500.00, 'Access to gym equipment and locker room. Perfect for beginners.', 'Active'),
(2, 'Standard Plan', 3, 1350.00, 'Includes group classes (yoga, zumba) plus gym access.', 'Active'),
(3, 'Premium Plan', 6, 2400.00, 'Personal trainer sessions (2x/month) + all Standard features.', 'Active'),
(4, 'Annual Plan', 12, 4500.00, 'Best value! All Premium features + nutrition consultation.', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `payments_tbl`
--

CREATE TABLE `payments_tbl` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `payment_method` enum('Cash','Card','Bank Transfer') NOT NULL,
  `status` enum('Paid','Pending','Cancelled') DEFAULT 'Paid',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments_tbl`
--

INSERT INTO `payments_tbl` (`id`, `member_id`, `plan_id`, `amount`, `payment_date`, `expiry_date`, `payment_method`, `status`, `created_at`) VALUES
(1, 1, 3, 2400.00, '2024-01-15', '2024-07-15', 'Card', 'Paid', '2024-01-15 00:00:00'),
(2, 2, 2, 1350.00, '2024-01-16', '2024-04-16', 'Cash', 'Paid', '2024-01-16 00:00:00'),
(3, 3, 1, 500.00, '2024-01-17', '2024-02-17', 'Bank Transfer', 'Paid', '2024-01-17 00:00:00'),
(4, 4, 4, 4500.00, '2024-01-18', '2025-01-18', 'Card', 'Paid', '2024-01-18 00:00:00'),
(5, 5, 2, 1350.00, '2024-01-19', '2024-04-19', 'Cash', 'Paid', '2024-01-19 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `members_tbl`
--
ALTER TABLE `members_tbl`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `member_id` (`member_id`);

--
-- Indexes for table `plans_tbl`
--
ALTER TABLE `plans_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments_tbl`
--
ALTER TABLE `payments_tbl`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `plan_id` (`plan_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `members_tbl`
--
ALTER TABLE `members_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `plans_tbl`
--
ALTER TABLE `plans_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `payments_tbl`
--
ALTER TABLE `payments_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payments_tbl`
--
ALTER TABLE `payments_tbl`
  ADD CONSTRAINT `payments_tbl_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members_tbl` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payments_tbl_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `plans_tbl` (`id`) ON DELETE CASCADE;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;