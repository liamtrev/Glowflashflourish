<?php @session_start(); ?>
<?php require_once('connection/localhost.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
    function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
    {
        global $localhost;
        
        if (PHP_VERSION < 6) {
            $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
        }

        // Updated to use mysqli real_escape_string
        $theValue = $localhost->real_escape_string($theValue);

        switch ($theType) {
            case "text":
                $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
                break;    
            case "long":
            case "int":
                $theValue = ($theValue != "") ? intval($theValue) : "NULL";
                break;
            case "double":
                $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
                break;
            case "date":
                $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
                break;
            case "defined":
                $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
                break;
        }
        return $theValue;
    }
}

// Check if user is already logged in
if (!isset($_SESSION)) {
    session_start();
}

$colname_Recordset1 = "-1";
if (isset($_SESSION['MM_Username'])) {
    $colname_Recordset1 = $_SESSION['MM_Username'];
}

// Updated to use mysqli
$query_Recordset1 = sprintf("SELECT username FROM admin_tbl WHERE username = %s", GetSQLValueString($colname_Recordset1, "text"));
$Recordset1 = $localhost->query($query_Recordset1) or die($localhost->error);
$row_Recordset1 = $Recordset1->fetch_assoc();
$totalRows_Recordset1 = $Recordset1->num_rows;

// *** Validate request to login to this site.
$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
    $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['username'])) {
    $loginUsername = $_POST['username'];
    $password = $_POST['password'];
    $MM_fldUserAuthorization = "";
    $MM_redirectLoginSuccess = "pages/home.php";
    $MM_redirectLoginFailed = "index.php?login=failed";
    $MM_redirecttoReferrer = false;
    
    // Updated to use mysqli with MD5 (keeping original password hash method)
    $LoginRS__query = sprintf("SELECT username, password FROM admin_tbl WHERE username=%s AND password=MD5(%s)",
        GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
    
    $LoginRS = $localhost->query($LoginRS__query) or die($localhost->error);
    $loginFoundUser = $LoginRS->num_rows;
    
    if ($loginFoundUser) {
        $loginStrGroup = "";
        
        if (PHP_VERSION >= 5.1) {
            session_regenerate_id(true);
        } else {
            session_regenerate_id();
        }
        
        $_SESSION['MM_Username'] = $loginUsername;
        $_SESSION['MM_UserGroup'] = $loginStrGroup;
        $_SESSION['login_time'] = time();

        if (isset($_SESSION['PrevUrl']) && false) {
            $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];    
        }
        
        header("Location: " . $MM_redirectLoginSuccess);
        exit;
    } else {
        header("Location: ". $MM_redirectLoginFailed);
        exit;
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TABBY'S GYM - Admin Login</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

#head {
    text-align: center;
    margin-bottom: 30px;
}

#logo {
    background: #fff;
    padding: 20px;
    border-radius: 10px 10px 0 0;
    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
}

#inside label {
    font-size: 32px;
    font-weight: bold;
    color: #333;
    text-transform: uppercase;
    letter-spacing: 2px;
}

#content {
    text-align: center;
    margin-bottom: 20px;
}

#contentr {
    font-size: 24px;
    color: #fff;
    text-transform: uppercase;
    letter-spacing: 1px;
}

#content2 {
    background: #fff;
    border-radius: 10px;
    padding: 40px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    max-width: 500px;
    width: 100%;
}

#content2l {
    text-align: center;
    margin-bottom: 20px;
}

#content2l img {
    max-width: 150px;
    height: auto;
    border-radius: 50%;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

#content2r form table {
    width: 100%;
    border-collapse: collapse;
}

#content2r form table td {
    padding: 10px;
}

#content2r form table td:first-child {
    font-weight: bold;
    color: #555;
    width: 30%;
}

#content2r form input[type="text"],
#content2r form input[type="password"] {
    width: 100%;
    padding: 12px;
    border: 2px solid #e0e0e0;
    border-radius: 5px;
    font-size: 16px;
    transition: border-color 0.3s;
}

#content2r form input[type="text"]:focus,
#content2r form input[type="password"]:focus {
    outline: none;
    border-color: #667eea;
}

#submit {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    border: none;
    padding: 12px 30px;
    border-radius: 5px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    transition: transform 0.3s, box-shadow 0.3s;
    text-transform: uppercase;
    letter-spacing: 1px;
}

#submit:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
}

#footer {
    text-align: center;
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid #eee;
    color: #888;
    font-size: 14px;
}

.error-message {
    background: #ffebee;
    color: #c62828;
    padding: 15px;
    border-radius: 5px;
    margin-bottom: 20px;
    text-align: center;
    border: 1px solid #ffcdd2;
    font-weight: bold;
}

.welcome-message {
    background: #e8f5e8;
    color: #2e7d32;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 20px;
    text-align: center;
}

@media (max-width: 600px) {
    #content2 {
        padding: 20px;
        margin: 20px;
    }
    
    #inside label {
        font-size: 24px;
    }
    
    #contentr {
        font-size: 20px;
    }
    
    #content2r form table td {
        display: block;
        width: 100%;
    }
    
    #content2r form table td:first-child {
        text-align: left;
        padding-bottom: 0;
    }
}
</style>
</head>

<body>
    <div style="width: 100%; max-width: 600px; padding: 20px;">
        <div id="head">
            <div id="logo">
                <div id="inside">
                    <label>TABBY'S GYM</label>
                </div>
            </div>
        </div>
        
        <div id="content">
            <div id="contentr">ADMIN LOGIN</div>
        </div>

        <div id="content2">
            <?php if(isset($_GET['login']) && $_GET['login'] == 'failed'): ?>
                <div class="error-message">
                    <strong>❌ Invalid username or password!</strong><br>
                    Please try again.
                </div>
            <?php endif; ?>
            
            <?php if(isset($_GET['logout']) && $_GET['logout'] == 'success'): ?>
                <div class="welcome-message">
                    <strong>✅ You have been logged out successfully!</strong>
                </div>
            <?php endif; ?>
            
            <div id="content2l">
                <img src="image/gym-icon.png" alt="TABBY'S GYM" width="167" height="167" />
            </div>
            
            <div id="content2r">
                <form action="<?php echo $loginFormAction; ?>" method="POST">
                    <table border="0">
                        <tr>
                            <td><label for="username">Username:</label></td>
                            <td>
                                <input type="text" name="username" id="username" autofocus required 
                                       placeholder="Enter username" />
                            </td>
                        </tr>
                        <tr>
                            <td><label for="password">Password:</label></td>
                            <td>
                                <input type="password" name="password" id="password" required 
                                       placeholder="Enter password" />
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td>
                                <input type="submit" name="submit" id="submit" value="LOGIN" />
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
            
            <div id="footer">
                &copy; <?php echo date('Y'); ?> @adhistabby. All rights reserved.<br>
                <small>Version 2.0 - Updated for PHP 8</small>
            </div>
        </div>
    </div>
</body>
</html>
<?php
// Free the result set
if (isset($Recordset1)) {
    $Recordset1->free();
}
?>