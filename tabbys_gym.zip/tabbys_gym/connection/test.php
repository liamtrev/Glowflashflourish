<?php
require_once('localhost.php');

echo "✅ Connected successfully to database: " . $database_localhost . "<br>";
echo "PHP Version: " . phpversion() . "<br>";
echo "MySQLi Client Version: " . $localhost->server_info . "<br>";

// Test a simple query
$result = $localhost->query("SELECT COUNT(*) as total FROM admin_tbl");
$row = $result->fetch_assoc();
echo "Total admins in database: " . $row['total'];
?>