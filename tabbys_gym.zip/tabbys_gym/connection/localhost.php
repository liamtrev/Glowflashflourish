<?php
// Database configuration for TABBY'S GYM - UPDATED for PHP 8
$hostname_localhost = "localhost";
$database_localhost = "gym_management";
$username_localhost = "root";
$password_localhost = ""; // Leave empty for XAMPP default

// Create connection using MySQLi (object-oriented style)
$localhost = new mysqli($hostname_localhost, $username_localhost, $password_localhost, $database_localhost);

// Check connection
if ($localhost->connect_error) {
    die("Connection failed: " . $localhost->connect_error);
}

// Set charset to utf8
$localhost->set_charset("utf8");

// For backward compatibility with your existing code, we'll also set this global
// but note: your code will need more updates to use mysqli properly
?>