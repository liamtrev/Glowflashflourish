<?php
// =========================================================
// M-PESA (SAFARICOM DARAJA API) CONFIGURATION
// =========================================================
// 1. Register at https://developer.safaricom.co.ke
// 2. Create an app to get your Consumer Key + Consumer Secret (sandbox first)
// 3. For sandbox testing, Safaricom provides a test Shortcode (174379) and
//    Passkey on their docs - use those below until you go live.
// 4. For production, you'll need your own Paybill/Till shortcode approved
//    by Safaricom, plus your live Consumer Key/Secret/Passkey.
// =========================================================

define('MPESA_ENV', 'sandbox'); // 'sandbox' or 'production'

define('MPESA_CONSUMER_KEY', 'YOUR_CONSUMER_KEY_HERE');
define('MPESA_CONSUMER_SECRET', 'YOUR_CONSUMER_SECRET_HERE');
define('MPESA_SHORTCODE', '174379'); // sandbox test shortcode - replace with yours for production
define('MPESA_PASSKEY', 'YOUR_PASSKEY_HERE');

// Safaricom needs a PUBLIC URL to send payment confirmations to.
// localhost won't work for this - you'll need a real domain, or a tunnel
// tool like ngrok while testing (e.g. https://your-ngrok-id.ngrok.io/glowflashflourish/customer/mpesa_callback.php)
define('MPESA_CALLBACK_URL', 'https://yourdomain.com/glowflashflourish/customer/mpesa_callback.php');

define('MPESA_BASE_URL', MPESA_ENV === 'production'
    ? 'https://api.safaricom.co.ke'
    : 'https://sandbox.safaricom.co.ke'
);
