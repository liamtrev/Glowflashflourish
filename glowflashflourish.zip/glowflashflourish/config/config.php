<?php
// Starts the session for every page that includes this file.
session_start();

// Set to 'production' before deploying to a live server - this hides PHP
// errors from visitors (they'd otherwise see file paths and query details).
define('ENVIRONMENT', 'development'); // 'development' or 'production'

if (ENVIRONMENT === 'production') {
    error_reporting(0);
    ini_set('display_errors', '0');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
}

define('SITE_NAME', 'Glow Flash Flourish and Smile');
define('ORDER_PREFIX', 'GFF');

// Base URL - update if your folder name in htdocs is different
define('BASE_URL', 'http://localhost/glowflashflourish/');
