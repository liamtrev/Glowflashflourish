<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['admin', 'staff']);
verify_csrf();

$success = '';
$error = '';
$uploadDir = '../assets/images/products/';
$publicPath = 'assets/images/products/';

function handle_image_upload($error) {
    global $uploadDir, $publicPath;
    if (empty($_FILES['image']['name'])) {
        return [null, $error];
    }
    $allowed = ['jpg', 'jpeg', 'png', 'webp'];
    $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) {
        return [null, "Image must be JPG, PNG, or WEBP."];
    }
    if ($_FILES['image']['size'] > 2 * 1024 * 1024) {
        return [null, "Image must be under 2MB."];
    }
    $filename = uniqid('prod_') . '.' . $ext;
    if (compress_and_save_image($_FILES['image']['tmp_name'], $uploadDir . $filename)) {
        return [$publicPath . $filename, $error];
    }
    return [null, "Failed to upload image."];
}

// ---------- CREATE ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create') {
    $category_id = (int) $_POST['category_id'];
    $name = clean($_POST['name']);
    $buying_price = (float) $_POST['buying_price'];
    $selling_price = (float) $_POST['selling_price'];
    $discount_amount = (float) ($_POST['discount_amount'] ?? 0);
    $is_clearance = isset($_POST['is_clearance']) ? 1 : 0;
    $stock_quantity = (float) $_POST['stock_quantity']; // now float
    $low_stock_threshold = (int) $_POST['low_stock_threshold'];
    $unit_type = $_POST['unit_type'] ?? 'unit';
    $unit_label = ($unit_type == 'meter') ? 'meters' : 'units';

    [$imagePath, $uploadError] = handle_image_upload(null);

    if (empty($name) || $category_id <= 0) {
        $error = "Please fill in the product name and choose a category.";
    } elseif ($uploadError) {
        $error = $uploadError;
    } elseif ($selling_price < $buying_price) {
        $error = "Selling price is lower than buying price - that would be a loss. Product not saved.";
    } elseif ($discount_amount >= $selling_price) {
        $error = "Discount amount cannot be equal to or greater than the selling price.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO products (category_id, name, buying_price, selling_price, discount_amount, is_clearance, stock_quantity, low_stock_threshold, image, created_by, unit_type, unit_label) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$category_id, $name, $buying_price, $selling_price, $discount_amount, $is_clearance, $stock_quantity, $low_stock_threshold, $imagePath, $_SESSION['user_id'], $unit_type, $unit_label]);
        $success = "Product added successfully.";
    }
}

// ---------- UPDATE ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    $id = (int) $_POST['id'];
    $category_id = (int) $_POST['category_id'];
    $name = clean($_POST['name']);
    $buying_price = (float) $_POST['buying_price'];
    $selling_price = (float) $_POST['selling_price'];
    $discount_amount = (float) ($_POST['discount_amount'] ?? 0);
    $is_clearance = isset($_POST['is_clearance']) ? 1 : 0;
    $stock_quantity = (float) $_POST['stock_quantity'];
    $low_stock_threshold = (int) $_POST['low_stock_threshold'];
    $unit_type = $_POST['unit_type'] ?? 'unit';
    $unit_label = ($unit_type == 'meter') ? 'meters' : 'units';

    [$imagePath, $uploadError] = handle_image_upload(null);

    if ($uploadError) {
        $error = $uploadError;
    } elseif ($selling_price < $buying_price) {
        $error = "Selling price is lower than buying price. Update not saved.";
    } elseif ($discount_amount >= $selling_price) {
        $error = "Discount amount cannot be equal to or greater than the selling price.";
    } else {
        if ($imagePath) {
            $stmt = $pdo->prepare("UPDATE products SET category_id=?, name=?, buying_price=?, selling_price=?, discount_amount=?, is_clearance=?, stock_quantity=?, low_stock_threshold=?, image=?, unit_type=?, unit_label=? WHERE id=?");
            $stmt->execute([$category_id, $name, $buying_price, $selling_price, $discount_amount, $is_clearance, $stock_quantity, $low_stock_threshold, $imagePath, $unit_type, $unit_label, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE products SET category_id=?, name=?, buying_price=?, selling_price=?, discount_amount=?, is_clearance=?, stock_quantity=?, low_stock_threshold=?, unit_type=?, unit_label=? WHERE id=?");
            $stmt->execute([$category_id, $name, $buying_price, $selling_price, $discount_amount, $is_clearance, $stock_quantity, $low_stock_threshold, $unit_type, $unit_label, $id]);
        }
        $success = "Product updated successfully.";
    }
}

// ---------- DELETE (smart: hard-delete if safe, otherwise hide) ----------
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];

    $orderCheck = $pdo->prepare("SELECT COUNT(*) as cnt FROM order_items WHERE product_id = ?");
    $orderCheck->execute([$id]);
    $hasOrders = $orderCheck->fetch()['cnt'] > 0;

    if ($hasOrders) {
        $pdo->prepare("UPDATE products SET is_active = 0 WHERE id = ?")->execute([$id]);
        header("Location: products.php?hidden=1");
    } else {
        $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);
        header("Location: products.php?deleted=1");
    }
    exit;
}
if (isset($_GET['deleted'])) {
    $success = "Product deleted successfully.";
}
if (isset($_GET['hidden'])) {
    $success = "This product has order history, so it was hidden from the shop instead of deleted (keeps past receipts accurate). You can restore it anytime.";
}
if (isset($_GET['restored'])) {
    $success = "Product restored and visible in the shop again.";
}

// ---------- RESTORE ----------
if (isset($_GET['restore'])) {
    $id = (int) $_GET['restore'];
    $pdo->prepare("UPDATE products SET is_active = 1 WHERE id = ?")->execute([$id]);
    header("Location: products.php?restored=1");
    exit;
}

// ---------- FETCH FOR EDIT ----------
$editProduct = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([(int) $_GET['edit']]);
    $editProduct = $stmt->fetch();
}
$editProductHasVariants = false;
if ($editProduct) {
    $editProductHasVariants = count(get_product_variants($pdo, $editProduct['id'])) > 0;
}

// ---------- FILTERS ----------
$filterCategory = isset($_GET['category']) ? (int) $_GET['category'] : 0;
$searchTerm = isset($_GET['q']) ? clean($_GET['q']) : '';
$lowStockOnly = isset($_GET['lowstock']) && $_GET['lowstock'] == '1';

// ---------- CATEGORIES ----------
$allCategories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();

// ---------- BUILD PRODUCT QUERY ----------
$sql = "SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE 1=1";
$params = [];
if ($filterCategory > 0) {
    $categoryIds = get_category_descendant_ids($pdo, $filterCategory);
    $placeholders = implode(',', array_fill(0, count($categoryIds), '?'));
    $sql .= " AND p.category_id IN ($placeholders)";
    $params = array_merge($params, $categoryIds);
}
if ($searchTerm !== '') {
    $sql .= " AND p.name LIKE ?";
    $params[] = "%$searchTerm%";
}
$sql .= " ORDER BY p.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

// Low-stock filtering
if ($lowStockOnly) {
    $products = array_filter($products, function ($p) use ($pdo) {
        return get_product_total_stock($pdo, $p) <= $p['low_stock_threshold'];
    });
}
$products = array_values($products);

// ---------- PAGINATION ----------
$perPage = 20;
$currentPage = max(1, (int) ($_GET['page'] ?? 1));
$totalProductsFound = count($products);
$totalPages = max(1, ceil($totalProductsFound / $perPage));
$currentPage = min($currentPage, $totalPages);
$products = array_slice($products, ($currentPage - 1) * $perPage, $perPage);

$pageTitle = "Products";
$activeNav = "products";
include '../includes/admin_header.php';
?>

<?php if ($success): ?><script>document.addEventListener('DOMContentLoaded', () => showToast(<?php echo json_encode($success); ?>, 'success'));</script><?php endif; ?>
<?php if ($error): ?><script>document.addEventListener('DOMContentLoaded', () => showToast(<?php echo json_encode($error); ?>, 'error'));</script><?php endif; ?>

<div class="gff-section">
    <h2><?php echo $editProduct ? 'Edit Product' : 'Add New Product'; ?></h2>
    <?php if (empty($allCategories)): ?>
        <p style="color:var(--text-muted);">You need to <a href="categories.php" style="color:var(--accent-teal);">add a category</a> first.</p>
    <?php else: ?>
    <form method="POST" enctype="multipart/form-data" class="gff-form-inline">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="<?php echo $editProduct ? 'update' : 'create'; ?>">
        <?php if ($editProduct): ?>
            <input type="hidden" name="id" value="<?php echo $editProduct['id']; ?>">
        <?php endif; ?>

        <div class="field">
            <label>Category</label>
            <select name="category_id" required>
                <?php echo render_category_options($allCategories, null, 0, [], $editProduct ? $editProduct['category_id'] : null); ?>
            </select>
        </div>
        <div class="field">
            <label>Product Name</label>
            <input type="text" name="name" value="<?php echo $editProduct ? clean($editProduct['name']) : ''; ?>" required>
        </div>
        <div class="field">
            <label>Buying Price (KSh)</label>
            <input type="number" step="0.01" min="0" name="buying_price" value="<?php echo $editProduct ? $editProduct['buying_price'] : ''; ?>" required>
        </div>
        <div class="field">
            <label>Selling Price (KSh)</label>
            <input type="number" step="0.01" min="0" name="selling_price" value="<?php echo $editProduct ? $editProduct['selling_price'] : ''; ?>" required>
        </div>
        <div class="field">
            <label>Discount Amount (KSh, optional)</label>
            <input type="number" step="0.01" min="0" name="discount_amount" value="<?php echo $editProduct ? $editProduct['discount_amount'] : '0'; ?>">
        </div>
        
        <!-- NEW: Unit Type Dropdown -->
        <div class="field">
            <label>Unit Type</label>
            <select name="unit_type">
                <option value="unit" <?php echo ($editProduct && $editProduct['unit_type'] == 'unit') ? 'selected' : ''; ?>>Per Unit (items, pieces)</option>
                <option value="meter" <?php echo ($editProduct && $editProduct['unit_type'] == 'meter') ? 'selected' : ''; ?>>Per Meter (length)</option>
            </select>
        </div>

        <div class="field">
            <label>&nbsp;</label>
            <label style="display:flex; align-items:center; gap:8px; color:var(--text-main); cursor:pointer;">
                <input type="checkbox" name="is_clearance" value="1" <?php echo ($editProduct && $editProduct['is_clearance']) ? 'checked' : ''; ?> style="width:auto;">
                Mark as Clearance Sale
            </label>
        </div>
        <div class="field">
            <label>Stock Quantity <?php echo $editProductHasVariants ? '(ignored - see Variants)' : ''; ?></label>
            <input type="number" step="0.5" min="0" name="stock_quantity" value="<?php echo $editProduct ? $editProduct['stock_quantity'] : '0'; ?>" <?php echo $editProductHasVariants ? 'disabled' : 'required'; ?>>
            <?php if ($editProductHasVariants): ?>
                <input type="hidden" name="stock_quantity" value="<?php echo $editProduct['stock_quantity']; ?>">
            <?php endif; ?>
        </div>
        <?php if ($editProductHasVariants): ?>
        <div class="field">
            <p style="font-size:11px; color:var(--accent-gold); max-width:220px;">
                This product has variants - stock is tracked per variant instead. <a href="product_variants.php?product_id=<?php echo $editProduct['id']; ?>" style="color:var(--accent-teal);">Manage variant stock here</a>.
            </p>
        </div>
        <?php endif; ?>
        <div class="field">
            <label>Low Stock Alert Below</label>
            <input type="number" min="0" name="low_stock_threshold" value="<?php echo $editProduct ? $editProduct['low_stock_threshold'] : '5'; ?>" required>
        </div>
        <div class="field">
            <label>Product Image <?php echo $editProduct ? '(optional - keeps old if empty)' : ''; ?></label>
            <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp">
        </div>
        <button type="submit" class="gff-btn"><?php echo $editProduct ? 'Save Changes' : 'Add Product'; ?></button>
        <?php if ($editProduct): ?>
            <a href="products.php" class="gff-btn gff-btn-outline">Cancel</a>
        <?php endif; ?>
    </form>
    <p style="font-size:11px; color:var(--text-muted); margin-top:8px;">
        Discount Amount is a flat KSh amount taken off the selling price for customers (e.g. selling price KSh 1000, discount KSh 150 &rarr; customer pays KSh 850). Leave as 0 for no discount.
    </p>
    <?php if ($editProduct && !empty($editProduct['image'])): ?>
        <p style="margin-top:10px;"><img src="<?php echo BASE_URL . $editProduct['image']; ?>" class="gff-thumb gff-viewable-img" style="width:80px;height:80px;"></p>
    <?php endif; ?>
    <?php if ($editProduct): ?>
        <p style="margin-top:10px;"><a href="product_variants.php?product_id=<?php echo $editProduct['id']; ?>" class="gff-btn gff-btn-small">Manage Variants</a></p>
    <?php endif; ?>
    <?php endif; ?>
</div>

<div class="gff-section">
    <h2>
        All Products
        <?php if ($lowStockOnly): ?><span style="font-size:12px; color:var(--status-cancelled);">(showing low stock only)</span><?php endif; ?>
        <?php if ($searchTerm !== ''): ?><span style="font-size:12px; color:var(--text-muted);">(search: "<?php echo clean($searchTerm); ?>")</span><?php endif; ?>
    </h2>

    <form method="GET" class="gff-form-inline" style="margin-bottom:16px;">
        <?php if ($searchTerm !== ''): ?><input type="hidden" name="q" value="<?php echo clean($searchTerm); ?>"><?php endif; ?>
        <?php if ($lowStockOnly): ?><input type="hidden" name="lowstock" value="1"><?php endif; ?>
        <div class="field">
            <label>Filter by Category</label>
            <select name="category" onchange="this.form.submit()">
                <option value="0">All Categories</option>
                <?php echo render_category_options($allCategories, null, 0, [], $filterCategory ?: null); ?>
            </select>
        </div>
    </form>

    <table class="gff-table">
        <tr>
            <th>Image</th>
            <th>Product</th>
            <th>Category</th>
            <th>Unit</th>
            <th>Buying Price</th>
            <th>Selling Price</th>
            <th>Discount</th>
            <th>Customer Pays</th>
            <th>Profit / Unit</th>
            <th>Stock</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($products as $p):
            $effectivePrice = get_effective_price($p);
            $profit = $effectivePrice - $p['buying_price'];
            $totalStock = get_product_total_stock($pdo, $p);
            $isLowStock = $totalStock <= $p['low_stock_threshold'];
            $variantCount = count(get_product_variants($pdo, $p['id']));
            $unitLabel = $p['unit_label'] ?? ($p['unit_type'] == 'meter' ? 'meters' : 'units');
        ?>
        <tr <?php echo !$p['is_active'] ? 'style="opacity:0.5;"' : ''; ?>>
            <td>
                <?php if (!empty($p['image'])): ?>
                    <img src="<?php echo BASE_URL . $p['image']; ?>" class="gff-thumb gff-viewable-img" alt="">
                <?php else: ?>
                    <div class="gff-thumb-placeholder">No Image</div>
                <?php endif; ?>
            </td>
            <td>
                <?php echo clean($p['name']); ?>
                <?php if ($p['is_clearance']): ?><br><span class="gff-clearance-badge">CLEARANCE</span><?php endif; ?>
                <?php if (!$p['is_active']): ?><br><span class="badge badge-cancelled">Hidden</span><?php endif; ?>
            </td>
            <td><?php echo clean($p['category_name']); ?></td>
            <td><?php echo $unitLabel; ?></td>
            <td>KSh <?php echo number_format($p['buying_price'], 2); ?></td>
            <td>KSh <?php echo number_format($p['selling_price'], 2); ?></td>
            <td>
                <?php if ($p['discount_amount'] > 0): ?>
                    <span style="color:var(--accent-pink); font-weight:bold;">- KSh <?php echo number_format($p['discount_amount'], 2); ?></span>
                <?php else: ?>
                    <span style="color:var(--text-muted);">None</span>
                <?php endif; ?>
            </td>
            <td style="font-weight:bold;">KSh <?php echo number_format($effectivePrice, 2); ?></td>
            <td style="color:var(--status-confirmed); font-weight:bold;">KSh <?php echo number_format($profit, 2); ?></td>
            <td>
                <?php echo number_format($totalStock, 2); ?><?php echo $variantCount > 0 ? ' (' . $variantCount . ' variants)' : ''; ?>
                <?php if ($isLowStock): ?>
                    <span class="badge badge-cancelled" style="margin-left:6px;">Low Stock</span>
                <?php endif; ?>
            </td>
            <td>
                <a href="?edit=<?php echo $p['id']; ?>" class="gff-btn gff-btn-small gff-btn-outline">Edit</a>
                <a href="product_variants.php?product_id=<?php echo $p['id']; ?>" class="gff-btn gff-btn-small gff-btn-outline">Variants</a>
                <?php if ($p['is_active']): ?>
                    <a href="?delete=<?php echo $p['id']; ?>" class="gff-btn gff-btn-small gff-btn-danger gff-confirm-action"
                       data-confirm="Delete this product? If it has past orders it will be hidden instead of permanently deleted.">Delete</a>
                <?php else: ?>
                    <a href="?restore=<?php echo $p['id']; ?>" class="gff-btn gff-btn-small gff-btn-success gff-confirm-action"
                       data-confirm="Restore this product so it's visible in the shop again?">Restore</a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($products)): ?>
        <tr><td colspan="11" style="color:var(--text-muted);">No products match this view.</td></tr>
        <?php endif; ?>
    </table>

    <?php if ($totalPages > 1):
        $baseParams = $_GET;
        unset($baseParams['page']);
    ?>
    <div style="display:flex; gap:8px; margin-top:16px; flex-wrap:wrap; align-items:center;">
        <span style="color:var(--text-muted); font-size:13px;">
            Page <?php echo $currentPage; ?> of <?php echo $totalPages; ?> (<?php echo $totalProductsFound; ?> products)
        </span>
        <?php for ($i = 1; $i <= $totalPages; $i++):
            $pageParams = array_merge($baseParams, ['page' => $i]);
            $url = '?' . http_build_query($pageParams);
        ?>
            <a href="<?php echo $url; ?>" class="gff-btn gff-btn-small <?php echo $i === $currentPage ? '' : 'gff-btn-outline'; ?>"><?php echo $i; ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

<?php include '../includes/admin_footer.php'; ?>