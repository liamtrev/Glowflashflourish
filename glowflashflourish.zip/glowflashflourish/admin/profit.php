<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['admin', 'staff']);

$period = $_GET['period'] ?? 'all';
$dateCondition = "";
switch ($period) {
    case 'today': $dateCondition = "AND DATE(o.created_at) = CURDATE()"; break;
    case 'week': $dateCondition = "AND o.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"; break;
    case 'month': $dateCondition = "AND o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)"; break;
    default: $dateCondition = "";
}

// Only COMPLETED orders count as real, realized sales for profit purposes
$categoryProfit = $pdo->query("
    SELECT
        COALESCE(parent.name, cat.name) as category_name,
        SUM(oi.line_total) as revenue,
        SUM(oi.buying_price_at_sale * oi.quantity) as cost,
        SUM(oi.line_total - (oi.buying_price_at_sale * oi.quantity)) as profit,
        SUM(oi.quantity) as units_sold
    FROM order_items oi
    JOIN orders o ON o.id = oi.order_id
    JOIN products p ON p.id = oi.product_id
    JOIN categories cat ON cat.id = p.category_id
    LEFT JOIN categories parent ON cat.parent_id = parent.id
    WHERE o.status = 'completed' $dateCondition
    GROUP BY category_name
    ORDER BY profit DESC
")->fetchAll();

$totals = $pdo->query("
    SELECT
        COALESCE(SUM(oi.line_total),0) as revenue,
        COALESCE(SUM(oi.buying_price_at_sale * oi.quantity),0) as cost,
        COALESCE(SUM(oi.line_total - (oi.buying_price_at_sale * oi.quantity)),0) as profit
    FROM order_items oi
    JOIN orders o ON o.id = oi.order_id
    WHERE o.status = 'completed' $dateCondition
")->fetch();

$pageTitle = "Profit Report";
$activeNav = "profit";
include '../includes/admin_header.php';
?>

<div class="gff-nav" style="margin-bottom:20px;">
    <a href="?period=today" style="<?php echo $period === 'today' ? 'font-weight:bold;' : ''; ?>">Today</a>
    <a href="?period=week" style="<?php echo $period === 'week' ? 'font-weight:bold;' : ''; ?>">Last 7 Days</a>
    <a href="?period=month" style="<?php echo $period === 'month' ? 'font-weight:bold;' : ''; ?>">Last 30 Days</a>
    <a href="?period=all" style="<?php echo $period === 'all' ? 'font-weight:bold;' : ''; ?>">All Time</a>
</div>

<div class="gff-overview">
    <div class="gff-overview-card">
        <div class="gff-overview-icon" style="color:var(--accent-blue);">&#128176;</div>
        <div class="gff-overview-text">
            <div class="label">Total Revenue</div>
            <div class="value">KSh <?php echo number_format($totals['revenue'], 2); ?></div>
        </div>
    </div>
    <div class="gff-overview-card">
        <div class="gff-overview-icon" style="color:var(--accent-gold);">&#128181;</div>
        <div class="gff-overview-text">
            <div class="label">Total Cost</div>
            <div class="value">KSh <?php echo number_format($totals['cost'], 2); ?></div>
        </div>
    </div>
    <div class="gff-overview-card">
        <div class="gff-overview-icon" style="color:var(--accent-teal);">&#128200;</div>
        <div class="gff-overview-text">
            <div class="label">Total Profit</div>
            <div class="value">KSh <?php echo number_format($totals['profit'], 2); ?></div>
        </div>
    </div>
</div>

<div class="gff-section" style="margin-top:20px;">
    <h2>Profit by Category (Completed Orders Only)</h2>
    <table class="gff-table">
        <tr><th>Category</th><th>Units Sold</th><th>Revenue</th><th>Cost</th><th>Profit</th><th>Margin</th></tr>
        <?php foreach ($categoryProfit as $c):
            $margin = $c['revenue'] > 0 ? ($c['profit'] / $c['revenue']) * 100 : 0;
        ?>
        <tr>
            <td><?php echo clean($c['category_name']); ?></td>
            <td><?php echo $c['units_sold']; ?></td>
            <td>KSh <?php echo number_format($c['revenue'], 2); ?></td>
            <td>KSh <?php echo number_format($c['cost'], 2); ?></td>
            <td style="color:var(--status-confirmed); font-weight:bold;">KSh <?php echo number_format($c['profit'], 2); ?></td>
            <td><?php echo number_format($margin, 1); ?>%</td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($categoryProfit)): ?>
        <tr><td colspan="6" style="color:var(--text-muted);">No completed sales in this period yet.</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php include '../includes/admin_footer.php'; ?>
