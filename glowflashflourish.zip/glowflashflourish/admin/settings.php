<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['admin']);
verify_csrf();

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $shopName = clean($_POST['shop_name']);
    $contactEmail = clean($_POST['contact_email']);
    $contactPhone = clean($_POST['contact_phone']);
    $orderPrefix = strtoupper(clean($_POST['order_prefix']));

    $logoPath = null;
    if (!empty($_FILES['logo']['name'])) {
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];
        $ext = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed)) {
            $error = "Logo must be JPG, PNG, or WEBP.";
        } else {
            $filename = 'logo_' . uniqid() . '.' . $ext;
            if (compress_and_save_image($_FILES['logo']['tmp_name'], '../assets/images/' . $filename, 400, 400)) {
                $logoPath = 'assets/images/' . $filename;
            }
        }
    }

    if (empty($error)) {
        if ($logoPath) {
            $pdo->prepare("UPDATE settings SET shop_name=?, contact_email=?, contact_phone=?, order_prefix=?, logo=? WHERE id = (SELECT id FROM (SELECT id FROM settings LIMIT 1) t)")
                ->execute([$shopName, $contactEmail, $contactPhone, $orderPrefix, $logoPath]);
        } else {
            $pdo->prepare("UPDATE settings SET shop_name=?, contact_email=?, contact_phone=?, order_prefix=? WHERE id = (SELECT id FROM (SELECT id FROM settings LIMIT 1) t)")
                ->execute([$shopName, $contactEmail, $contactPhone, $orderPrefix]);
        }
        $success = "Settings updated successfully.";
    }
}

$settings = $pdo->query("SELECT * FROM settings LIMIT 1")->fetch();

$pageTitle = "Settings";
$activeNav = "settings";
include '../includes/admin_header.php';
?>

<?php if ($success): ?><div class="gff-success-msg"><?php echo $success; ?></div><?php endif; ?>
<?php if ($error): ?><div class="gff-error"><?php echo $error; ?></div><?php endif; ?>

<div class="gff-section" style="max-width:600px;">
    <h2>Shop Settings</h2>
    <form method="POST" enctype="multipart/form-data" style="display:flex; flex-direction:column; gap:14px; margin-top:16px;">
        <?php echo csrf_field(); ?>
        <div>
            <label style="display:block; margin-bottom:6px; color:var(--text-muted); font-size:13px;">Shop Name</label>
            <input type="text" name="shop_name" value="<?php echo clean($settings['shop_name'] ?? ''); ?>" required style="width:100%; padding:10px; border-radius:6px; border:none; background:#2A3140; color:var(--text-main);">
        </div>
        <div>
            <label style="display:block; margin-bottom:6px; color:var(--text-muted); font-size:13px;">Contact Email</label>
            <input type="email" name="contact_email" value="<?php echo clean($settings['contact_email'] ?? ''); ?>" style="width:100%; padding:10px; border-radius:6px; border:none; background:#2A3140; color:var(--text-main);">
        </div>
        <div>
            <label style="display:block; margin-bottom:6px; color:var(--text-muted); font-size:13px;">Contact Phone</label>
            <input type="text" name="contact_phone" value="<?php echo clean($settings['contact_phone'] ?? ''); ?>" style="width:100%; padding:10px; border-radius:6px; border:none; background:#2A3140; color:var(--text-main);">
        </div>
        <div>
            <label style="display:block; margin-bottom:6px; color:var(--text-muted); font-size:13px;">Order Number Prefix (e.g. GFF)</label>
            <input type="text" name="order_prefix" value="<?php echo clean($settings['order_prefix'] ?? 'GFF'); ?>" maxlength="10" required style="width:100%; padding:10px; border-radius:6px; border:none; background:#2A3140; color:var(--text-main);">
            <p style="font-size:11px; color:var(--text-muted); margin-top:4px;">New order numbers will look like: <?php echo clean($settings['order_prefix'] ?? 'GFF'); ?>/<?php echo date('dmY'); ?>/001</p>
        </div>
        <div>
            <label style="display:block; margin-bottom:6px; color:var(--text-muted); font-size:13px;">Shop Logo</label>
            <?php if (!empty($settings['logo'])): ?>
                <img src="<?php echo BASE_URL . $settings['logo']; ?>" style="width:60px; height:60px; border-radius:8px; object-fit:cover; margin-bottom:8px; display:block;">
            <?php endif; ?>
            <input type="file" name="logo" accept=".jpg,.jpeg,.png,.webp">
        </div>
        <button type="submit" class="gff-btn" style="width:fit-content;">Save Settings</button>
    </form>
</div>

<div class="gff-section" style="max-width:600px;">
    <h2>Note</h2>
    <p style="color:var(--text-muted); font-size:13px;">
        The shop name shown in page headers/titles across the site currently comes from <code>config/config.php</code> (SITE_NAME constant).
        The name you set here is used on printed receipts and will be used as the site-wide name in a future update.
        The Order Prefix above <strong>is</strong> fully active - it controls new order numbers immediately.
    </p>
</div>

<?php include '../includes/admin_footer.php'; ?>
