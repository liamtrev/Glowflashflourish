<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['admin', 'staff']);

$orderId = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT o.*, u.full_name as customer_name, u.email as customer_email FROM orders o JOIN users u ON u.id = o.customer_id WHERE o.id = ?");
$stmt->execute([$orderId]);
$order = $stmt->fetch();
if (!$order) die("Order not found.");

$itemsStmt = $pdo->prepare("SELECT oi.*, p.name FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ?");
$itemsStmt->execute([$orderId]);
$items = $itemsStmt->fetchAll();

$settings = $pdo->query("SELECT * FROM settings LIMIT 1")->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Receipt <?php echo clean($order['order_number']); ?></title>
<style>
    body { font-family: Arial, sans-serif; background: white; color: #111; padding: 30px; max-width: 600px; margin: 0 auto; }
    h1 { font-size: 20px; margin-bottom: 4px; }
    .muted { color: #666; font-size: 13px; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { text-align: left; padding: 8px; border-bottom: 1px solid #ddd; font-size: 13px; }
    .totals { margin-top: 16px; text-align: right; font-size: 14px; }
    .totals .grand { font-size: 18px; font-weight: bold; margin-top: 6px; }
    .print-btn { margin-top: 20px; padding: 10px 20px; background: #2E6BFF; color: white; border: none; border-radius: 6px; cursor: pointer; }
    @media print { .print-btn { display: none; } }
</style>
</head>
<body>
    <h1><?php echo clean($settings['shop_name'] ?? SITE_NAME); ?></h1>
    <p class="muted">
        <?php if (!empty($settings['contact_phone'])): ?>Tel: <?php echo clean($settings['contact_phone']); ?><br><?php endif; ?>
        <?php if (!empty($settings['contact_email'])): ?><?php echo clean($settings['contact_email']); ?><?php endif; ?>
    </p>
    <hr>
    <p><strong>Receipt for Order:</strong> <?php echo clean($order['order_number']); ?></p>
    <p class="muted">Date: <?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?></p>
    <p class="muted">Customer: <?php echo clean($order['customer_name']); ?> (<?php echo clean($order['customer_email']); ?>)</p>
    <p class="muted">Payment Status: <?php echo ucfirst($order['payment_status']); ?> | Order Status: <?php echo ucfirst($order['status']); ?></p>

    <table>
        <tr><th>Item</th><th>Qty</th><th>Unit Price</th><th>Discount</th><th>Total</th></tr>
        <?php foreach ($items as $it): ?>
        <tr>
            <td><?php echo clean($it['name']); ?><?php if (!empty($it['variant_label'])): ?><br><small><?php echo clean($it['variant_label']); ?></small><?php endif; ?></td>
            <td><?php echo $it['quantity']; ?></td>
            <td>KSh <?php echo number_format($it['unit_price'], 2); ?></td>
            <td><?php echo number_format($it['item_discount'], 1); ?>%</td>
            <td>KSh <?php echo number_format($it['line_total'], 2); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <div class="totals">
        <div>Subtotal: KSh <?php echo number_format($order['subtotal'], 2); ?></div>
        <div>Discount: -KSh <?php echo number_format($order['discount_amount'], 2); ?></div>
        <div class="grand">Grand Total: KSh <?php echo number_format($order['grand_total'], 2); ?></div>
    </div>

    <p class="muted" style="margin-top:30px;">Thank you for shopping with <?php echo clean($settings['shop_name'] ?? SITE_NAME); ?>!</p>

    <button class="print-btn" onclick="window.print()">Print Receipt</button>
</body>
</html>
