<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['admin', 'staff']);

$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'pending';
$validStatuses = ['pending', 'completed', 'cancelled', 'refunded', 'all'];
if (!in_array($statusFilter, $validStatuses)) $statusFilter = 'pending';

$sql = "
    SELECT o.*, u.full_name as customer_name, u.phone as customer_phone,
           (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) as item_count
    FROM orders o
    JOIN users u ON u.id = o.customer_id
";
$params = [];
if ($statusFilter !== 'all') {
    $sql .= " WHERE o.status = ?";
    $params[] = $statusFilter;
}
$sql .= " ORDER BY o.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Counts for each tab badge
$counts = $pdo->query("SELECT status, COUNT(*) as cnt FROM orders GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);

$pageTitle = "Orders";
$activeNav = "orders";
include '../includes/admin_header.php';
?>

<div class="gff-nav" style="margin-bottom:20px;">
    <a href="?status=pending" style="<?php echo $statusFilter === 'pending' ? 'font-weight:bold;' : ''; ?>">Pending (<?php echo $counts['pending'] ?? 0; ?>)</a>
    <a href="?status=completed" style="<?php echo $statusFilter === 'completed' ? 'font-weight:bold;' : ''; ?>">Completed (<?php echo $counts['completed'] ?? 0; ?>)</a>
    <a href="?status=cancelled" style="<?php echo $statusFilter === 'cancelled' ? 'font-weight:bold;' : ''; ?>">Cancelled (<?php echo $counts['cancelled'] ?? 0; ?>)</a>
    <a href="?status=refunded" style="<?php echo $statusFilter === 'refunded' ? 'font-weight:bold;' : ''; ?>">Refunded (<?php echo $counts['refunded'] ?? 0; ?>)</a>
    <a href="?status=all" style="<?php echo $statusFilter === 'all' ? 'font-weight:bold;' : ''; ?>">All Orders (Archive)</a>
</div>

<div class="gff-section">
    <table class="gff-table">
        <tr>
            <th>Order #</th>
            <th>Customer</th>
            <th>Items</th>
            <th>Grand Total</th>
            <th>Payment</th>
            <th>Status</th>
            <th>Date</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($orders as $o): ?>
        <tr>
            <td><?php echo clean($o['order_number']); ?></td>
            <td><?php echo clean($o['customer_name']); ?></td>
            <td><?php echo $o['item_count']; ?></td>
            <td>KSh <?php echo number_format($o['grand_total'], 2); ?></td>
            <td>
                <span class="badge <?php echo $o['payment_status'] === 'paid' ? 'badge-confirmed' : 'badge-pending'; ?>">
                    <?php echo ucfirst($o['payment_status']); ?>
                </span>
            </td>
            <td>
                <?php
                $badgeClass = ['pending' => 'badge-pending', 'completed' => 'badge-completed', 'cancelled' => 'badge-cancelled', 'refunded' => 'badge-refund'][$o['status']];
                ?>
                <span class="badge <?php echo $badgeClass; ?>"><?php echo ucfirst($o['status']); ?></span>
            </td>
            <td><?php echo date('d M Y, h:i A', strtotime($o['created_at'])); ?></td>
            <td>
                <a href="order_view.php?id=<?php echo $o['id']; ?>" class="gff-btn gff-btn-small gff-btn-outline">View</a>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($orders)): ?>
        <tr><td colspan="8" style="color:var(--text-muted);">No orders in this view.</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php include '../includes/admin_footer.php'; ?>
