<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['admin', 'staff']);
verify_csrf();

$success = '';
$error = '';

// ---------- CREATE ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create') {
    $name = clean($_POST['name']);
    $parent_id = !empty($_POST['parent_id']) ? (int) $_POST['parent_id'] : null;

    if (empty($name)) {
        $error = "Category name is required.";
    } else {
        $check = $pdo->prepare("SELECT id FROM categories WHERE name = ? AND (parent_id <=> ?)");
        $check->execute([$name, $parent_id]);
        if ($check->fetch()) {
            $error = "That category/subcategory already exists in this location.";
        } else {
            $pdo->prepare("INSERT INTO categories (name, parent_id) VALUES (?, ?)")->execute([$name, $parent_id]);
            $success = $parent_id ? "Subcategory added successfully." : "Category added successfully.";
        }
    }
}

// ---------- UPDATE ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    $id = (int) $_POST['id'];
    $name = clean($_POST['name']);
    $parent_id = !empty($_POST['parent_id']) ? (int) $_POST['parent_id'] : null;

    $descendantIds = get_category_descendant_ids($pdo, $id); // includes $id itself
    if ($parent_id !== null && in_array($parent_id, $descendantIds)) {
        $error = "Can't set that as the parent - it would create a circular reference (it's this category itself or one of its own subcategories).";
    } elseif (!empty($name)) {
        $pdo->prepare("UPDATE categories SET name = ?, parent_id = ? WHERE id = ?")->execute([$name, $parent_id, $id]);
        $success = "Category updated successfully.";
    }
}

// ---------- DELETE ----------
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $checkProducts = $pdo->prepare("SELECT COUNT(*) as cnt FROM products WHERE category_id = ?");
    $checkProducts->execute([$id]);
    $checkChildren = $pdo->prepare("SELECT COUNT(*) as cnt FROM categories WHERE parent_id = ?");
    $checkChildren->execute([$id]);

    if ($checkProducts->fetch()['cnt'] > 0) {
        $error = "Cannot delete - this category still has products assigned to it.";
    } elseif ($checkChildren->fetch()['cnt'] > 0) {
        $error = "Cannot delete - this category still has subcategories. Delete or reassign those first.";
    } else {
        $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
        header("Location: categories.php?deleted=1");
        exit;
    }
}
if (isset($_GET['deleted'])) {
    $success = "Category deleted successfully.";
}

// ---------- FETCH FOR EDIT ----------
$editCategory = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->execute([(int) $_GET['edit']]);
    $editCategory = $stmt->fetch();
}

// ---------- FETCH ALL (with product counts) ----------
$allCategories = $pdo->query("
    SELECT c.*, COUNT(p.id) as product_count
    FROM categories c
    LEFT JOIN products p ON p.category_id = c.id
    GROUP BY c.id
    ORDER BY c.name ASC
")->fetchAll();

$excludeIds = $editCategory ? get_category_descendant_ids($pdo, $editCategory['id']) : [];
$prefillParentId = (!$editCategory && isset($_GET['add_child'])) ? (int) $_GET['add_child'] : null;

$pageTitle = "Categories";
$activeNav = "categories";
include '../includes/admin_header.php';
?>

<?php if ($success): ?><script>document.addEventListener('DOMContentLoaded', () => showToast(<?php echo json_encode($success); ?>, 'success'));</script><?php endif; ?>
<?php if ($error): ?><script>document.addEventListener('DOMContentLoaded', () => showToast(<?php echo json_encode($error); ?>, 'error'));</script><?php endif; ?>

<div class="gff-section">
    <h2><?php echo $editCategory ? 'Edit Category' : 'Add New Category or Subcategory'; ?></h2>
    <form method="POST" class="gff-form-inline">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="<?php echo $editCategory ? 'update' : 'create'; ?>">
        <?php if ($editCategory): ?>
            <input type="hidden" name="id" value="<?php echo $editCategory['id']; ?>">
        <?php endif; ?>
        <div class="field">
            <label>Name</label>
            <input type="text" name="name" value="<?php echo $editCategory ? clean($editCategory['name']) : ''; ?>" required>
        </div>
        <div class="field">
            <label>Parent (leave as "None" for a top-level category)</label>
            <select name="parent_id">
                <option value="">None (Top-Level Category)</option>
                <?php echo render_category_options($allCategories, null, 0, $excludeIds, $editCategory ? $editCategory['parent_id'] : $prefillParentId); ?>
            </select>
        </div>
        <p style="font-size:11px; color:var(--text-muted); margin-top:6px;">
            You can nest as deep as you like - e.g. Clothes &rarr; Men &rarr; Casual, or Clothes &rarr; Kids. Just pick the right parent each time.
        </p>
        <button type="submit" class="gff-btn"><?php echo $editCategory ? 'Save Changes' : 'Add'; ?></button>
        <?php if ($editCategory): ?>
            <a href="categories.php" class="gff-btn gff-btn-outline">Cancel</a>
        <?php endif; ?>
    </form>
</div>

<div class="gff-section">
    <h2>All Categories</h2>
    <table class="gff-table">
        <tr>
            <th>Name</th>
            <th># of Products</th>
            <th>Actions</th>
        </tr>
        <?php
        function render_category_rows($categories, $parentId = null, $depth = 0) {
            foreach ($categories as $c) {
                if ($c['parent_id'] !== $parentId) continue;
                $indent = $depth * 24;
                $prefix = $depth > 0 ? '&mdash; ' : '';
                echo '<tr>';
                echo '<td style="padding-left:' . (12 + $indent) . 'px;">' . ($depth === 0 ? '<strong>' : '') . $prefix . htmlspecialchars($c['name']) . ($depth === 0 ? '</strong>' : '') . '</td>';
                echo '<td>' . $c['product_count'] . '</td>';
                echo '<td>';
                echo '<a href="?edit=' . $c['id'] . '" class="gff-btn gff-btn-small gff-btn-outline">Edit</a> ';
                echo '<a href="?delete=' . $c['id'] . '" class="gff-btn gff-btn-small gff-btn-danger gff-confirm-action" data-confirm="Delete this category? Only works if it has no products or subcategories.">Delete</a> ';
                echo '<a href="categories.php?add_child=' . $c['id'] . '" class="gff-btn gff-btn-small gff-btn-outline">+ Add Sub-category</a>';
                echo '</td>';
                echo '</tr>';
                render_category_rows($categories, $c['id'], $depth + 1);
            }
        }
        render_category_rows($allCategories);
        ?>
        <?php if (empty($allCategories)): ?>
        <tr><td colspan="3" style="color:var(--text-muted);">No categories yet.</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php include '../includes/admin_footer.php'; ?>
