-- =========================================================
-- MIGRATION: Adds checkout + discount + profit-tracking fields
-- Run this in phpMyAdmin > SQL tab (gff_db selected)
-- =========================================================

USE gff_db;

ALTER TABLE orders ADD COLUMN delivery_address VARCHAR(255) DEFAULT NULL AFTER customer_id;
ALTER TABLE orders ADD COLUMN discount_mode ENUM('percentage','fixed') DEFAULT 'fixed' AFTER discount_type;

-- Stores the product's buying price AT THE TIME OF SALE, so profit reports
-- stay accurate even if you change a product's buying price later.
ALTER TABLE order_items ADD COLUMN buying_price_at_sale DECIMAL(10,2) DEFAULT 0 AFTER unit_price;
