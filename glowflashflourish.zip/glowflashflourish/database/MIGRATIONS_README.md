# Database Migrations — Run Order

If this is a **fresh install**, skip all of these — just import `gff_schema.sql` and you're done.

If you already have a working `gff_db`, run these **in this order** (each is a separate file in this folder). If any single line in a migration errors with "Duplicate column" or "already exists," it just means you already applied that specific piece — delete that one line and re-run the rest.

| # | File | What it adds |
|---|---|---|
| 1 | `migration_subcategories.sql` | Category → Subcategory support (e.g. Clothing → Men/Women/Kids/Uniforms) |
| 2 | `migration_cart.sql` | Shopping cart table |
| 3 | `migration_checkout.sql` | Checkout, delivery address, discount tracking on orders |
| 4 | `migration_product_discount.sql` | Flat KSh discount amount per product |
| 5 | `migration_variants_clearance.sql` | Product variants (Color/Litres/Dimensions with own stock) + Clearance Sale flag |
| 6 | `migration_soft_delete.sql` | Safe product deletion (hides instead of crashing if it has past orders) |
| 7 | `migration_password_reset.sql` | Forgot Password / Reset Password support |
| 8 | `migration_mpesa.sql` | M-Pesa payment method + transaction tracking on orders |

Based on this conversation, you should already have #1-5 applied. If you're not sure about any of them, the safest approach is:
1. Open your `products`, `orders`, and `categories` tables in phpMyAdmin → **Structure** tab
2. Compare the column names you see against what each migration above adds
3. Run only the ones whose columns are missing

Or just run all 8 in order — any already-applied ones will simply error harmlessly on their own lines (delete those lines, keep going).
