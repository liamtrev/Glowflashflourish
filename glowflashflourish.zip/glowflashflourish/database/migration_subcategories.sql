-- =========================================================
-- MIGRATION: Run this in phpMyAdmin > SQL tab (gff_db selected)
-- ONLY if you already imported the database before.
-- If this is a fresh install, skip this - just import gff_schema.sql instead.
-- =========================================================

USE gff_db;

-- 1. Add the parent_id column (safe to run once)
ALTER TABLE categories ADD COLUMN parent_id INT NULL AFTER name;

-- 2. Remove the old UNIQUE constraint on name (subcategories can share
--    names across different parents, e.g. "Men" under both Clothing and Shoes)
ALTER TABLE categories DROP INDEX name;

-- 3. Add the foreign key link
ALTER TABLE categories ADD CONSTRAINT fk_category_parent
    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE CASCADE;

-- 4. Seed subcategories under Clothing (only runs if Clothing exists and has no subcategories yet)
INSERT INTO categories (name, parent_id)
SELECT 'Men', id FROM categories WHERE name = 'Clothing'
UNION ALL SELECT 'Women', id FROM categories WHERE name = 'Clothing'
UNION ALL SELECT 'Kids', id FROM categories WHERE name = 'Clothing'
UNION ALL SELECT 'Uniforms', id FROM categories WHERE name = 'Clothing';

-- 5. Seed subcategories under Shoes
INSERT INTO categories (name, parent_id)
SELECT 'Men', id FROM categories WHERE name = 'Shoes'
UNION ALL SELECT 'Women', id FROM categories WHERE name = 'Shoes'
UNION ALL SELECT 'Kids', id FROM categories WHERE name = 'Shoes';
