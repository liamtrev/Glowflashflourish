-- =========================================================
-- MIGRATION: Adds M-Pesa payment tracking to orders
-- Run this in phpMyAdmin > SQL tab (gff_db selected)
-- =========================================================

USE gff_db;

ALTER TABLE orders ADD COLUMN payment_method ENUM('cash','mpesa') NOT NULL DEFAULT 'cash';
ALTER TABLE orders ADD COLUMN mpesa_checkout_request_id VARCHAR(100) DEFAULT NULL;
ALTER TABLE orders ADD COLUMN mpesa_receipt_number VARCHAR(50) DEFAULT NULL;
