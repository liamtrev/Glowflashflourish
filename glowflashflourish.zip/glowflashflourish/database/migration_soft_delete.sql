-- =========================================================
-- MIGRATION: Adds soft-delete support for products
-- Run this in phpMyAdmin > SQL tab (gff_db selected)
-- =========================================================

USE gff_db;

ALTER TABLE products ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1;
