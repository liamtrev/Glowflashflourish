-- =========================================================
-- MIGRATION: Adds a flat KSh discount amount to products
-- Run this in phpMyAdmin > SQL tab (gff_db selected)
-- =========================================================

USE gff_db;

ALTER TABLE products ADD COLUMN discount_amount DECIMAL(10,2) DEFAULT 0 AFTER selling_price;
