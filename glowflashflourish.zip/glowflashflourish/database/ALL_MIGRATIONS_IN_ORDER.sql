-- =========================================================
-- RUN THIS FILE if you already have an existing gff_db database.
-- Combines all migrations in the correct order.
-- If any single ALTER/CREATE line errors with "Duplicate column"
-- or "already exists", that piece was already applied - just
-- delete that one line and click Go again.
--
-- If this is a FRESH install instead, just import gff_schema.sql
-- and skip this file entirely.
-- =========================================================

USE gff_db;

-- ===== 1. SUBCATEGORIES =====
USE gff_db;

-- 1. Add the parent_id column (safe to run once)
ALTER TABLE categories ADD COLUMN parent_id INT NULL AFTER name;

-- 2. Remove the old UNIQUE constraint on name (subcategories can share
--    names across different parents, e.g. "Men" under both Clothing and Shoes)
ALTER TABLE categories DROP INDEX name;

-- 3. Add the foreign key link
ALTER TABLE categories ADD CONSTRAINT fk_category_parent
    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE CASCADE;

-- 4. Seed subcategories under Clothing (only runs if Clothing exists and has no subcategories yet)
INSERT INTO categories (name, parent_id)
SELECT 'Men', id FROM categories WHERE name = 'Clothing'
UNION ALL SELECT 'Women', id FROM categories WHERE name = 'Clothing'
UNION ALL SELECT 'Kids', id FROM categories WHERE name = 'Clothing'
UNION ALL SELECT 'Uniforms', id FROM categories WHERE name = 'Clothing';

-- 5. Seed subcategories under Shoes
INSERT INTO categories (name, parent_id)
SELECT 'Men', id FROM categories WHERE name = 'Shoes'
UNION ALL SELECT 'Women', id FROM categories WHERE name = 'Shoes'
UNION ALL SELECT 'Kids', id FROM categories WHERE name = 'Shoes';

-- ===== 2. CART =====

CREATE TABLE IF NOT EXISTS cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_cart_item (customer_id, product_id),
    FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- ===== 3. CHECKOUT + DISCOUNTS + PROFIT TRACKING =====

ALTER TABLE orders ADD COLUMN delivery_address VARCHAR(255) DEFAULT NULL AFTER customer_id;
ALTER TABLE orders ADD COLUMN discount_mode ENUM('percentage','fixed') DEFAULT 'fixed' AFTER discount_type;

-- Stores the product's buying price AT THE TIME OF SALE, so profit reports
-- stay accurate even if you change a product's buying price later.
ALTER TABLE order_items ADD COLUMN buying_price_at_sale DECIMAL(10,2) DEFAULT 0 AFTER unit_price;

-- ===== 4. PRODUCT DISCOUNT AMOUNT =====

ALTER TABLE products ADD COLUMN discount_amount DECIMAL(10,2) DEFAULT 0 AFTER selling_price;

-- ===== 5. VARIANTS + CLEARANCE SALE =====

USE gff_db;

-- 1. Clearance sale flag on products
ALTER TABLE products ADD COLUMN is_clearance TINYINT(1) NOT NULL DEFAULT 0 AFTER discount_amount;

-- 2. Product variants: each row is one attribute+value option with its own stock
--    e.g. (Color, Red, stock 5), (Color, Blue, stock 3), (Litres, 5L, stock 10)
CREATE TABLE product_variants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    attribute_name VARCHAR(50) NOT NULL,
    attribute_value VARCHAR(100) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    price_adjustment DECIMAL(10,2) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- 3. Cart needs to track which variant was picked, and allow the same
--    product to appear multiple times in cart (once per variant)
ALTER TABLE cart_items DROP INDEX unique_cart_item;
ALTER TABLE cart_items ADD COLUMN variant_id INT NULL AFTER product_id;
ALTER TABLE cart_items ADD CONSTRAINT fk_cart_variant FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE CASCADE;
ALTER TABLE cart_items ADD UNIQUE KEY unique_cart_item (customer_id, product_id, variant_id);

-- 4. Orders need to remember which variant was bought (label snapshot for receipts)
ALTER TABLE order_items ADD COLUMN variant_id INT NULL AFTER product_id;
ALTER TABLE order_items ADD COLUMN variant_label VARCHAR(150) NULL AFTER variant_id;
