-- =========================================================
-- Run this instead - skips the subcategories migration
-- since you already applied that one.
-- =========================================================

USE gff_db;

-- ===== CART =====

CREATE TABLE IF NOT EXISTS cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_cart_item (customer_id, product_id),
    FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- ===== CHECKOUT + DISCOUNTS + PROFIT TRACKING =====

ALTER TABLE orders ADD COLUMN delivery_address VARCHAR(255) DEFAULT NULL AFTER customer_id;
ALTER TABLE orders ADD COLUMN discount_mode ENUM('percentage','fixed') DEFAULT 'fixed' AFTER discount_type;

-- Stores the product's buying price AT THE TIME OF SALE, so profit reports
-- stay accurate even if you change a product's buying price later.
ALTER TABLE order_items ADD COLUMN buying_price_at_sale DECIMAL(10,2) DEFAULT 0 AFTER unit_price;
