-- =========================================================
-- MIGRATION: Adds product variants (color/type/litres/dimensions
-- with their own stock), a clearance sale flag, and variant
-- support in cart + orders.
-- Run this in phpMyAdmin > SQL tab (gff_db selected)
-- =========================================================

USE gff_db;

-- 1. Clearance sale flag on products
ALTER TABLE products ADD COLUMN is_clearance TINYINT(1) NOT NULL DEFAULT 0 AFTER discount_amount;

-- 2. Product variants: each row is one attribute+value option with its own stock
--    e.g. (Color, Red, stock 5), (Color, Blue, stock 3), (Litres, 5L, stock 10)
CREATE TABLE product_variants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    attribute_name VARCHAR(50) NOT NULL,
    attribute_value VARCHAR(100) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    price_adjustment DECIMAL(10,2) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- 3. Cart needs to track which variant was picked, and allow the same
--    product to appear multiple times in cart (once per variant)
ALTER TABLE cart_items DROP INDEX unique_cart_item;
ALTER TABLE cart_items ADD COLUMN variant_id INT NULL AFTER product_id;
ALTER TABLE cart_items ADD CONSTRAINT fk_cart_variant FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE CASCADE;
ALTER TABLE cart_items ADD UNIQUE KEY unique_cart_item (customer_id, product_id, variant_id);

-- 4. Orders need to remember which variant was bought (label snapshot for receipts)
ALTER TABLE order_items ADD COLUMN variant_id INT NULL AFTER product_id;
ALTER TABLE order_items ADD COLUMN variant_label VARCHAR(150) NULL AFTER variant_id;
