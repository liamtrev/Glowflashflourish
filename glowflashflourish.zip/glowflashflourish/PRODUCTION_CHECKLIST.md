# GFF Boutique — Before You Go Live (Production Checklist)

Run through this before pointing a real domain at this site or accepting real customers/payments.

## 1. Database
- [ ] Change the MySQL root password (or create a dedicated non-root DB user) — don't use the blank XAMPP default password in production.
- [ ] Update `config/db.php` with the new production DB credentials.
- [ ] Log in as Super Admin and **change the default password** (`Admin@123`) immediately — this is publicly known since it's in this project's history.
- [ ] Take a full database export/backup before going live, and set up a recurring backup (daily is reasonable for a small shop).

## 2. Environment & Errors
- [ ] In `config/config.php`, change `ENVIRONMENT` from `'development'` to `'production'`. This hides PHP errors from visitors (they'd otherwise see file paths and query details on any bug).

## 3. URLs & Domain
- [ ] Update `BASE_URL` in `config/config.php` to your real domain (e.g. `https://glowflashflourish.co.ke/`).
- [ ] Update `MPESA_CALLBACK_URL` in `config/mpesa_config.php` to that same real domain — M-Pesa cannot send payment confirmations to `localhost`.
- [ ] Get an SSL certificate (HTTPS) — most hosts include free SSL (Let's Encrypt) automatically. M-Pesa's Daraja API requires HTTPS for callback URLs in production.

## 4. M-Pesa
- [ ] Register a production app at developer.safaricom.co.ke (separate from the sandbox one).
- [ ] Apply for and get your own Paybill/Till shortcode approved by Safaricom.
- [ ] Update `config/mpesa_config.php`: set `MPESA_ENV` to `'production'`, and fill in your live Consumer Key, Consumer Secret, Shortcode, and Passkey.
- [ ] Test with a small real payment before announcing the feature to customers.

## 5. File Uploads
- [ ] Confirm `assets/images/products/` is writable by the web server on your host (permissions like 755 or 775, not 777).
- [ ] Consider a periodic cleanup/backup of uploaded images too, not just the database.

## 6. Security Housekeeping
- [ ] `.htaccess` files are already included to block direct access to `database/`, `config/`, hidden files, and log files — confirm your host actually supports `.htaccess` (Apache/LiteSpeed do; if you're on Nginx you'll need equivalent server-block rules instead, and I can help with that).
- [ ] Remove or restrict `customer/mpesa_callback.php`'s log file (`mpesa_callback_log.txt`) periodically, or disable the logging line in that file once you've confirmed M-Pesa integration works — it's just for initial debugging.
- [ ] Review who has Admin/Staff accounts and disable any test accounts you created while building.

## 7. Performance (optional but recommended once traffic grows)
- [ ] Enable PHP OPcache on the server if not already on (most hosts have this by default).
- [ ] Consider a CDN for `assets/` if you get significant traffic.

---

Everything above is a one-time setup task, not something to redo per update — once done, ongoing deployments just mean uploading changed files.
