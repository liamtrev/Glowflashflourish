<?php
// Redirects a user if they are not logged in.
function require_login() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: " . BASE_URL . "auth/login.php");
        exit;
    }
}

// Redirects a user if they don't have one of the allowed roles.
function require_role($allowed_roles = []) {
    require_login();
    if (!in_array($_SESSION['role'], $allowed_roles)) {
        die("Access denied: you don't have permission to view this page.");
    }
}

// Basic input cleanup.
function clean($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Returns the IDs of the given category plus every descendant at any depth
// (used so filtering/deleting a parent correctly includes all its children's children, etc).
function get_category_descendant_ids($pdo, $categoryId) {
    $all = $pdo->query("SELECT id, parent_id FROM categories")->fetchAll();
    $childrenByParent = [];
    foreach ($all as $c) {
        if ($c['parent_id'] !== null) {
            $childrenByParent[$c['parent_id']][] = $c['id'];
        }
    }

    $ids = [(int) $categoryId];
    $queue = [(int) $categoryId];
    while (!empty($queue)) {
        $current = array_shift($queue);
        if (!empty($childrenByParent[$current])) {
            foreach ($childrenByParent[$current] as $childId) {
                $ids[] = $childId;
                $queue[] = $childId;
            }
        }
    }
    return $ids;
}

// Renders a flat list of categories as an indented <option> list of unlimited depth,
// for use inside a <select>. Excludes $excludeIds (typically the category being edited
// plus all its descendants, to prevent circular parent references).
function render_category_options($categories, $parentId = null, $depth = 0, $excludeIds = [], $selectedId = null) {
    $html = '';
    foreach ($categories as $c) {
        if ($c['parent_id'] !== $parentId) continue;
        if (in_array($c['id'], $excludeIds)) continue;

        $prefix = str_repeat('&nbsp;&nbsp;&nbsp;', $depth) . ($depth > 0 ? '&mdash; ' : '');
        $selected = ($selectedId !== null && (int) $selectedId === (int) $c['id']) ? 'selected' : '';
        $html .= '<option value="' . $c['id'] . '" ' . $selected . '>' . $prefix . htmlspecialchars($c['name']) . '</option>';
        $html .= render_category_options($categories, $c['id'], $depth + 1, $excludeIds, $selectedId);
    }
    return $html;
}

// Resizes an uploaded image (if larger than max dimensions) and compresses it,
// saving the result to $destPath. Falls back to a plain copy if GD isn't available.
// Returns true on success, false on failure.
function compress_and_save_image($sourceTmpPath, $destPath, $maxWidth = 1000, $maxHeight = 1000, $quality = 80) {
    if (!function_exists('gd_info')) {
        return move_uploaded_file($sourceTmpPath, $destPath);
    }

    $info = @getimagesize($sourceTmpPath);
    if (!$info) {
        return move_uploaded_file($sourceTmpPath, $destPath);
    }

    [$origWidth, $origHeight, $type] = $info;

    switch ($type) {
        case IMAGETYPE_JPEG:
            $srcImage = @imagecreatefromjpeg($sourceTmpPath);
            break;
        case IMAGETYPE_PNG:
            $srcImage = @imagecreatefrompng($sourceTmpPath);
            break;
        case IMAGETYPE_WEBP:
            $srcImage = function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($sourceTmpPath) : false;
            break;
        default:
            $srcImage = false;
    }

    if (!$srcImage) {
        return move_uploaded_file($sourceTmpPath, $destPath);
    }

    // Only shrink if the image is actually bigger than the max dimensions
    $ratio = min($maxWidth / $origWidth, $maxHeight / $origHeight, 1);
    $newWidth = (int) round($origWidth * $ratio);
    $newHeight = (int) round($origHeight * $ratio);

    $newImage = imagecreatetruecolor($newWidth, $newHeight);

    // Preserve transparency for PNG
    if ($type === IMAGETYPE_PNG) {
        imagealphablending($newImage, false);
        imagesavealpha($newImage, true);
    }

    imagecopyresampled($newImage, $srcImage, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);

    $saved = false;
    switch ($type) {
        case IMAGETYPE_JPEG:
            $saved = imagejpeg($newImage, $destPath, $quality);
            break;
        case IMAGETYPE_PNG:
            // PNG quality is 0 (best) to 9 (most compressed) - map our 0-100 scale roughly
            $saved = imagepng($newImage, $destPath, (int) round((100 - $quality) / 11));
            break;
        case IMAGETYPE_WEBP:
            $saved = function_exists('imagewebp') ? imagewebp($newImage, $destPath, $quality) : false;
            break;
    }

    imagedestroy($srcImage);
    imagedestroy($newImage);

    return $saved;
}

// ---------- CSRF PROTECTION ----------
// Call this to get a hidden input to embed in every POST form.
function csrf_field() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return '<input type="hidden" name="csrf_token" value="' . $_SESSION['csrf_token'] . '">';
}

// Call this at the top of any POST handler, before processing the form.
function verify_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf_token'] ?? '';
        if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
            die("Security check failed (invalid or expired form). Please go back and try again.");
        }
    }
}

// Returns the price a customer actually pays after any flat discount_amount is subtracted.
function get_effective_price($product) {
    $discount = isset($product['discount_amount']) ? (float) $product['discount_amount'] : 0;
    $price = (float) $product['selling_price'] - $discount;
    return $price > 0 ? $price : 0;
}

// Fetches all variant rows for a product (Color/Type/Litres/Dimensions etc.)
function get_product_variants($pdo, $productId) {
    $stmt = $pdo->prepare("SELECT * FROM product_variants WHERE product_id = ? ORDER BY attribute_name ASC, attribute_value ASC");
    $stmt->execute([$productId]);
    return $stmt->fetchAll();
}

// Total available stock for a product: sums variant stock if any exist, else the product's own stock_quantity.
function get_product_total_stock($pdo, $product) {
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(stock_quantity),0) as total FROM product_variants WHERE product_id = ?");
    $stmt->execute([$product['id']]);
    $variantStock = (int) $stmt->fetch()['total'];

    $hasVariants = $pdo->prepare("SELECT COUNT(*) as cnt FROM product_variants WHERE product_id = ?");
    $hasVariants->execute([$product['id']]);
    if ($hasVariants->fetch()['cnt'] > 0) {
        return $variantStock;
    }
    return (int) $product['stock_quantity'];
}

// Counts products at or below their low-stock threshold, correctly checking variant stock where relevant.
function get_low_stock_count($pdo) {
    $products = $pdo->query("SELECT id, stock_quantity, low_stock_threshold FROM products WHERE is_active = 1")->fetchAll();
    $count = 0;
    foreach ($products as $p) {
        if (get_product_total_stock($pdo, $p) <= $p['low_stock_threshold']) {
            $count++;
        }
    }
    return $count;
}

// Effective price for one specific variant (base effective price + that variant's adjustment)
function get_variant_price($product, $variant) {
    $base = get_effective_price($product);
    $adjustment = $variant ? (float) $variant['price_adjustment'] : 0;
    $price = $base + $adjustment;
    return $price > 0 ? $price : 0;
}

// Generates the next order number in the format GFF/DDMMYYYY/001,
// resetting the counter to 001 automatically at midnight (new date row).
function generate_order_number($pdo) {
    $today = date('Y-m-d');       // used internally as the unique key
    $displayDate = date('dmY');   // used in the visible order number

    $prefixRow = $pdo->query("SELECT order_prefix FROM settings LIMIT 1")->fetch();
    $prefix = $prefixRow && !empty($prefixRow['order_prefix']) ? $prefixRow['order_prefix'] : ORDER_PREFIX;

    $pdo->beginTransaction();

    $stmt = $pdo->prepare("SELECT * FROM order_number_sequence WHERE sequence_date = ? FOR UPDATE");
    $stmt->execute([$today]);
    $row = $stmt->fetch();

    if ($row) {
        $nextNumber = $row['last_number'] + 1;
        $update = $pdo->prepare("UPDATE order_number_sequence SET last_number = ? WHERE sequence_date = ?");
        $update->execute([$nextNumber, $today]);
    } else {
        $nextNumber = 1;
        $insert = $pdo->prepare("INSERT INTO order_number_sequence (sequence_date, last_number) VALUES (?, ?)");
        $insert->execute([$today, $nextNumber]);
    }

    $pdo->commit();

    $paddedNumber = str_pad($nextNumber, 3, '0', STR_PAD_LEFT); // 001-999
    return $prefix . '/' . $displayDate . '/' . $paddedNumber;
}
