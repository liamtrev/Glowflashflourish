<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    echo json_encode(['success' => false, 'message' => 'Please log in as a customer to use the cart.']);
    exit;
}

$customerId = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';
$productId = (int) ($_POST['product_id'] ?? 0);

function get_cart_count($pdo, $customerId) {
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(quantity),0) as cnt FROM cart_items WHERE customer_id = ?");
    $stmt->execute([$customerId]);
    return (int) $stmt->fetch()['cnt'];
}

if ($action === 'add') {
    $quantity = max(1, (int) ($_POST['quantity'] ?? 1));

    $stmt = $pdo->prepare("SELECT stock_quantity FROM products WHERE id = ?");
    $stmt->execute([$productId]);
    $product = $stmt->fetch();

    if (!$product) {
        echo json_encode(['success' => false, 'message' => 'Product not found.']);
        exit;
    }
    if ($product['stock_quantity'] < $quantity) {
        echo json_encode(['success' => false, 'message' => 'Not enough stock available.']);
        exit;
    }

    $existing = $pdo->prepare("SELECT * FROM cart_items WHERE customer_id = ? AND product_id = ?");
    $existing->execute([$customerId, $productId]);
    $row = $existing->fetch();

    if ($row) {
        $pdo->prepare("UPDATE cart_items SET quantity = quantity + ? WHERE id = ?")->execute([$quantity, $row['id']]);
    } else {
        $pdo->prepare("INSERT INTO cart_items (customer_id, product_id, quantity) VALUES (?, ?, ?)")->execute([$customerId, $productId, $quantity]);
    }

    echo json_encode(['success' => true, 'message' => 'Added to cart!', 'cartCount' => get_cart_count($pdo, $customerId)]);
    exit;
}

if ($action === 'update') {
    $quantity = max(1, (int) ($_POST['quantity'] ?? 1));
    $pdo->prepare("UPDATE cart_items SET quantity = ? WHERE customer_id = ? AND product_id = ?")
        ->execute([$quantity, $customerId, $productId]);

    // Recalculate this line's total + cart totals for the UI to update live
    $stmt = $pdo->prepare("SELECT p.selling_price, ci.quantity FROM cart_items ci JOIN products p ON p.id = ci.product_id WHERE ci.customer_id = ? AND ci.product_id = ?");
    $stmt->execute([$customerId, $productId]);
    $line = $stmt->fetch();
    $lineTotal = $line ? $line['selling_price'] * $line['quantity'] : 0;

    $cartTotal = $pdo->prepare("SELECT COALESCE(SUM(p.selling_price * ci.quantity),0) as total FROM cart_items ci JOIN products p ON p.id = ci.product_id WHERE ci.customer_id = ?");
    $cartTotal->execute([$customerId]);

    echo json_encode([
        'success' => true,
        'cartCount' => get_cart_count($pdo, $customerId),
        'lineTotal' => number_format($lineTotal, 2),
        'cartTotal' => number_format($cartTotal->fetch()['total'], 2)
    ]);
    exit;
}

if ($action === 'remove') {
    $pdo->prepare("DELETE FROM cart_items WHERE customer_id = ? AND product_id = ?")->execute([$customerId, $productId]);

    $cartTotal = $pdo->prepare("SELECT COALESCE(SUM(p.selling_price * ci.quantity),0) as total FROM cart_items ci JOIN products p ON p.id = ci.product_id WHERE ci.customer_id = ?");
    $cartTotal->execute([$customerId]);

    echo json_encode([
        'success' => true,
        'message' => 'Item removed.',
        'cartCount' => get_cart_count($pdo, $customerId),
        'cartTotal' => number_format($cartTotal->fetch()['total'], 2)
    ]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Unknown action.']);