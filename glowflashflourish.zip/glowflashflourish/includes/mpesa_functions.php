<?php
require_once __DIR__ . '/../config/mpesa_config.php';

// Gets a short-lived OAuth access token from Safaricom, needed for every other M-Pesa call.
function mpesa_get_access_token() {
    $credentials = base64_encode(MPESA_CONSUMER_KEY . ':' . MPESA_CONSUMER_SECRET);

    $ch = curl_init(MPESA_BASE_URL . '/oauth/v1/generate?grant_type=client_credentials');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Basic ' . $credentials]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return ['success' => false, 'message' => 'Connection error: ' . $error];
    }

    $data = json_decode($response, true);
    if (!isset($data['access_token'])) {
        return ['success' => false, 'message' => 'Could not get M-Pesa access token. Check your Consumer Key/Secret in config/mpesa_config.php.'];
    }

    return ['success' => true, 'token' => $data['access_token']];
}

// Normalizes a Kenyan phone number to the 2547XXXXXXXX format M-Pesa requires.
function mpesa_normalize_phone($phone) {
    $phone = preg_replace('/\D/', '', $phone); // strip non-digits
    if (substr($phone, 0, 1) === '0') {
        $phone = '254' . substr($phone, 1);
    } elseif (substr($phone, 0, 1) === '7' || substr($phone, 0, 1) === '1') {
        $phone = '254' . $phone;
    }
    return $phone;
}

// Sends an STK Push prompt to the customer's phone asking them to enter their M-Pesa PIN.
function mpesa_stk_push($phone, $amount, $orderNumber) {
    $tokenResult = mpesa_get_access_token();
    if (!$tokenResult['success']) {
        return $tokenResult;
    }

    $phone = mpesa_normalize_phone($phone);
    $timestamp = date('YmdHis');
    $password = base64_encode(MPESA_SHORTCODE . MPESA_PASSKEY . $timestamp);

    $payload = [
        'BusinessShortCode' => MPESA_SHORTCODE,
        'Password' => $password,
        'Timestamp' => $timestamp,
        'TransactionType' => 'CustomerPayBillOnline',
        'Amount' => (int) ceil($amount), // M-Pesa doesn't accept decimals
        'PartyA' => $phone,
        'PartyB' => MPESA_SHORTCODE,
        'PhoneNumber' => $phone,
        'CallBackURL' => MPESA_CALLBACK_URL,
        'AccountReference' => $orderNumber,
        'TransactionDesc' => 'Payment for order ' . $orderNumber,
    ];

    $ch = curl_init(MPESA_BASE_URL . '/mpesa/stkpush/v1/processrequest');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $tokenResult['token'],
        'Content-Type: application/json',
    ]);

    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return ['success' => false, 'message' => 'Connection error: ' . $error];
    }

    $data = json_decode($response, true);

    if (isset($data['ResponseCode']) && $data['ResponseCode'] === '0') {
        return [
            'success' => true,
            'checkout_request_id' => $data['CheckoutRequestID'],
            'message' => 'STK push sent - check your phone to enter your M-Pesa PIN.'
        ];
    }

    return [
        'success' => false,
        'message' => $data['errorMessage'] ?? 'M-Pesa request failed. Please try again or pay cash on delivery.'
    ];
}
