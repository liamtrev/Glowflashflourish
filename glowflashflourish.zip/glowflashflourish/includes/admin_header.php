<?php
// Requires: $pdo, active session, $pageTitle and $activeNav set by the including page.
$lowStockCount = get_low_stock_count($pdo);
$initials = strtoupper(substr($_SESSION['full_name'], 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $pageTitle . ' - ' . SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
</head>
<body>
<div class="gff-toast-container" id="toastContainer"></div>
<div class="gff-layout">

    <aside class="gff-sidebar">
        <div class="gff-sidebar-profile">
            <div class="gff-avatar"><?php echo $initials; ?></div>
            <div class="gff-sidebar-name"><?php echo clean($_SESSION['full_name']); ?></div>
            <div class="gff-sidebar-role"><?php echo ucfirst($_SESSION['role']); ?></div>
        </div>
        <nav>
            <a href="<?php echo BASE_URL; ?>admin/dashboard.php" class="<?php echo $activeNav === 'dashboard' ? 'active' : ''; ?>">Dashboard</a>
            <a href="<?php echo BASE_URL; ?>admin/products.php" class="<?php echo $activeNav === 'products' ? 'active' : ''; ?>">Products</a>
            <a href="<?php echo BASE_URL; ?>admin/categories.php" class="<?php echo $activeNav === 'categories' ? 'active' : ''; ?>">Categories</a>
            <?php if ($_SESSION['role'] === 'admin'): ?>
            <a href="<?php echo BASE_URL; ?>admin/users.php" class="<?php echo $activeNav === 'users' ? 'active' : ''; ?>">Staff & Customers</a>
            <?php endif; ?>
            <a href="<?php echo BASE_URL; ?>admin/orders.php" class="<?php echo $activeNav === 'orders' ? 'active' : ''; ?>">Orders</a>
            <a href="<?php echo BASE_URL; ?>admin/profit.php" class="<?php echo $activeNav === 'profit' ? 'active' : ''; ?>">Profit Report</a>
            <?php if ($_SESSION['role'] === 'admin'): ?>
            <a href="<?php echo BASE_URL; ?>admin/settings.php" class="<?php echo $activeNav === 'settings' ? 'active' : ''; ?>">Settings</a>
            <?php endif; ?>
        </nav>
        <div style="padding-top:20px;">
            <a href="<?php echo BASE_URL; ?>auth/logout.php" class="gff-btn-logout" style="display:block;text-align:center;">Logout</a>
        </div>
    </aside>

    <div class="gff-content">
        <div class="gff-topbar">
            <h2><?php echo clean($pageTitle); ?></h2>
            <form class="gff-search" method="GET" action="<?php echo BASE_URL; ?>admin/products.php">
                <input type="text" name="q" placeholder="Search products...">
            </form>
            <div class="gff-topbar-icons">
                <a href="<?php echo BASE_URL; ?>admin/products.php?lowstock=1" class="gff-icon-btn" title="Low stock alerts">
                    &#128276;
                    <?php if ($lowStockCount > 0): ?><span class="gff-icon-badge"><?php echo $lowStockCount; ?></span><?php endif; ?>
                </a>
            </div>
        </div>
        <main class="gff-main">
