// ===== Toast Notifications =====
function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = 'gff-toast gff-toast-' + type;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.classList.add('gff-toast-show'), 10);
    setTimeout(() => {
        toast.classList.remove('gff-toast-show');
        setTimeout(() => toast.remove(), 300);
    }, 2500);
}

// ===== Quantity Steppers (on shop grid + cart page) =====
document.addEventListener('click', function (e) {
    if (e.target.classList.contains('gff-qty-plus')) {
        const input = e.target.parentElement.querySelector('.gff-qty-input');
        input.value = parseInt(input.value || 1) + 1;
    }
    if (e.target.classList.contains('gff-qty-minus')) {
        const input = e.target.parentElement.querySelector('.gff-qty-input');
        input.value = Math.max(1, parseInt(input.value || 1) - 1);
    }
});

// ===== Variant Selector: update displayed price live =====
document.addEventListener('change', function (e) {
    if (e.target.classList.contains('gff-variant-select')) {
        const select = e.target;
        const card = select.closest('.gff-product-card');
        const priceEl = card ? card.querySelector('.gff-current-price') : null;
        if (!priceEl) return;

        const basePrice = parseFloat(select.dataset.basePrice || 0);
        const selectedOption = select.options[select.selectedIndex];
        const adjustment = parseFloat(selectedOption.dataset.adjustment || 0);
        const finalPrice = Math.max(basePrice + adjustment, 0);
        priceEl.textContent = 'KSh ' + finalPrice.toFixed(2);
    }
});

// ===== Add to Cart (AJAX) =====
document.addEventListener('click', function (e) {
    if (e.target.classList.contains('gff-add-to-cart')) {
        const btn = e.target;
        const productId = btn.dataset.productId;
        const card = btn.closest('.gff-product-card');
        const qtyInput = card ? card.querySelector('.gff-qty-input') : null;
        const variantSelect = card ? card.querySelector('.gff-variant-select') : null;
        const quantity = qtyInput ? qtyInput.value : 1;
        const variantId = variantSelect ? variantSelect.value : '';

        if (variantSelect && !variantId) {
            showToast('Please select an option first.', 'error');
            return;
        }

        btn.disabled = true;
        const originalText = btn.textContent;
        btn.textContent = 'Adding...';

        const formData = new FormData();
        formData.append('action', 'add');
        formData.append('product_id', productId);
        formData.append('quantity', quantity);
        if (variantId) formData.append('variant_id', variantId);

        fetch('cart_action.php', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                btn.disabled = false;
                if (data.success) {
                    btn.textContent = 'Added \u2713';
                    btn.classList.add('gff-added-pulse');
                    showToast(data.message, 'success');
                    updateCartBadge(data.cartCount);
                    setTimeout(() => {
                        btn.textContent = originalText;
                        btn.classList.remove('gff-added-pulse');
                    }, 1200);
                } else {
                    btn.textContent = originalText;
                    showToast(data.message, 'error');
                }
            })
            .catch(() => {
                btn.disabled = false;
                btn.textContent = originalText;
                showToast('Something went wrong. Please try again.', 'error');
            });
    }
});

function updateCartBadge(count) {
    let badge = document.getElementById('cartBadge');
    const cartIcon = document.querySelector('.gff-shop-icons a[title="Cart"]');
    if (count > 0) {
        if (!badge && cartIcon) {
            badge = document.createElement('span');
            badge.className = 'gff-icon-badge';
            badge.id = 'cartBadge';
            cartIcon.appendChild(badge);
        }
        if (badge) badge.textContent = count;
    } else if (badge) {
        badge.remove();
    }
}

// ===== Cart Page: update quantity / remove (AJAX) =====
document.addEventListener('click', function (e) {
    if (e.target.classList.contains('gff-cart-update')) {
        const row = e.target.closest('.gff-cart-row');
        const productId = row.dataset.productId;
        const variantId = row.dataset.variantId || '';
        const quantity = row.querySelector('.gff-qty-input').value;

        const formData = new FormData();
        formData.append('action', 'update');
        formData.append('product_id', productId);
        if (variantId) formData.append('variant_id', variantId);
        formData.append('quantity', quantity);

        fetch('cart_action.php', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    row.querySelector('.gff-line-total').textContent = 'KSh ' + data.lineTotal;
                    document.getElementById('cartGrandTotal').textContent = 'KSh ' + data.cartTotal;
                    updateCartBadge(data.cartCount);
                    showToast('Cart updated.', 'success');
                }
            });
    }

    if (e.target.classList.contains('gff-cart-remove')) {
        const row = e.target.closest('.gff-cart-row');
        const productId = row.dataset.productId;
        const variantId = row.dataset.variantId || '';

        const formData = new FormData();
        formData.append('action', 'remove');
        formData.append('product_id', productId);
        if (variantId) formData.append('variant_id', variantId);

        fetch('cart_action.php', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    row.style.opacity = '0';
                    setTimeout(() => {
                        row.remove();
                        const cartTotalEl = document.getElementById('cartGrandTotal');
                        if (cartTotalEl) cartTotalEl.textContent = 'KSh ' + data.cartTotal;
                        updateCartBadge(data.cartCount);
                        if (data.cartCount == 0) location.reload();
                    }, 250);
                    showToast(data.message, 'success');
                }
            });
    }
});
