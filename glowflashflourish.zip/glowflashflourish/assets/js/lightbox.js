// Click any element with class "gff-viewable-img" to open it full-size in a lightbox overlay.
document.addEventListener('click', function (e) {
    const img = e.target.closest('.gff-viewable-img');
    if (!img || img.tagName !== 'IMG') return;

    const overlay = document.createElement('div');
    overlay.className = 'gff-lightbox-overlay';
    overlay.innerHTML = `
        <div class="gff-lightbox-content">
            <img src="${img.src}" alt="${img.alt || ''}">
            <button type="button" class="gff-lightbox-close" aria-label="Close">&times;</button>
        </div>
    `;
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('gff-lightbox-show'));

    function closeLightbox() {
        overlay.classList.remove('gff-lightbox-show');
        setTimeout(() => overlay.remove(), 200);
    }

    overlay.querySelector('.gff-lightbox-close').addEventListener('click', closeLightbox);
    overlay.addEventListener('click', function (ev) {
        if (ev.target === overlay) closeLightbox();
    });
});
