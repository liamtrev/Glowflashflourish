// ===== Toast Notifications =====
function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = 'gff-toast gff-toast-' + type;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.classList.add('gff-toast-show'), 10);
    const duration = type === 'error' ? 4000 : 2500;
    setTimeout(() => {
        toast.classList.remove('gff-toast-show');
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// ===== Custom Confirm Modal (replaces browser confirm()) =====
function showConfirmModal(message, onConfirm) {
    const overlay = document.createElement('div');
    overlay.className = 'gff-modal-overlay';
    overlay.innerHTML = `
        <div class="gff-modal-box">
            <p>${message}</p>
            <div class="gff-modal-actions">
                <button type="button" class="gff-btn gff-btn-outline gff-modal-cancel">Cancel</button>
                <button type="button" class="gff-btn gff-btn-danger gff-modal-confirm">Yes, proceed</button>
            </div>
        </div>
    `;
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('gff-modal-show'));

    function closeModal() {
        overlay.classList.remove('gff-modal-show');
        setTimeout(() => overlay.remove(), 200);
    }

    overlay.querySelector('.gff-modal-cancel').addEventListener('click', closeModal);
    overlay.querySelector('.gff-modal-confirm').addEventListener('click', () => {
        closeModal();
        onConfirm();
    });
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) closeModal();
    });
}

// Intercept any link/button with class "gff-confirm-action" and show the modal instead of confirm()
document.addEventListener('click', function (e) {
    const el = e.target.closest('.gff-confirm-action');
    if (el) {
        e.preventDefault();
        const msg = el.dataset.confirm || 'Are you sure?';
        showConfirmModal(msg, function () {
            window.location.href = el.getAttribute('href');
        });
    }
});
