<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['customer']);

$stmt = $pdo->prepare("
    SELECT ci.*, p.name, p.selling_price, p.discount_amount, p.image, p.stock_quantity,
           pv.attribute_name, pv.attribute_value, pv.price_adjustment, pv.stock_quantity as variant_stock
    FROM cart_items ci
    JOIN products p ON p.id = ci.product_id
    LEFT JOIN product_variants pv ON pv.id = ci.variant_id
    WHERE ci.customer_id = ?
    ORDER BY ci.added_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$cartItems = $stmt->fetchAll();

$cartTotal = 0;
foreach ($cartItems as $item) {
    $base = max($item['selling_price'] - $item['discount_amount'], 0);
    $unitPrice = max($base + (float) ($item['price_adjustment'] ?? 0), 0);
    $cartTotal += $unitPrice * $item['quantity'];
}

$pageTitle = "My Cart";
include '../includes/customer_header.php';
?>

<h1 style="margin-bottom:20px;">My Cart</h1>

<?php if (empty($cartItems)): ?>
    <div class="gff-empty-state">
        <h3>Your cart is empty</h3>
        <p>Browse the shop and add something you like.</p>
        <a href="shop.php" class="gff-btn" style="margin-top:16px; display:inline-block;">Continue Shopping</a>
    </div>
<?php else: ?>

<div class="gff-shop-layout">
    <div class="gff-product-grid-area">
        <div class="gff-section">
            <?php foreach ($cartItems as $item):
                $base = max($item['selling_price'] - $item['discount_amount'], 0);
                $unitPrice = max($base + (float) ($item['price_adjustment'] ?? 0), 0);
            ?>
            <div class="gff-cart-row" data-product-id="<?php echo $item['product_id']; ?>" data-variant-id="<?php echo $item['variant_id'] ?? ''; ?>">
                <?php if (!empty($item['image'])): ?>
                    <img src="<?php echo BASE_URL . $item['image']; ?>" alt="" class="gff-viewable-img">
                <?php else: ?>
                    <div class="gff-thumb-placeholder">No Image</div>
                <?php endif; ?>
                <div class="gff-cart-row-info">
                    <div class="name">
                        <?php echo clean($item['name']); ?>
                        <?php if (!empty($item['attribute_name'])): ?>
                            <span style="color:var(--text-muted); font-weight:normal; font-size:12px;"> - <?php echo clean($item['attribute_name']); ?>: <?php echo clean($item['attribute_value']); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="price">KSh <?php echo number_format($unitPrice, 2); ?> each</div>
                </div>
                <div class="gff-qty-stepper">
                    <button type="button" class="gff-qty-minus">-</button>
                    <input type="text" class="gff-qty-input" value="<?php echo $item['quantity']; ?>" readonly>
                    <button type="button" class="gff-qty-plus">+</button>
                </div>
                <button class="gff-btn gff-btn-small gff-btn-outline gff-cart-update">Update</button>
                <div class="gff-line-total">KSh <?php echo number_format($unitPrice * $item['quantity'], 2); ?></div>
                <button class="gff-btn gff-btn-small gff-btn-danger gff-cart-remove">Remove</button>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div style="width:300px; flex-shrink:0;">
        <div class="gff-order-summary">
            <h3 style="margin-bottom:16px;">Order Summary</h3>
            <div class="row">
                <span>Subtotal</span>
                <span id="cartGrandTotal">KSh <?php echo number_format($cartTotal, 2); ?></span>
            </div>
            <div class="row">
                <span>Delivery</span>
                <span>Calculated at checkout</span>
            </div>
            <div class="row total">
                <span>Total</span>
                <span>KSh <?php echo number_format($cartTotal, 2); ?></span>
            </div>
            <a href="checkout.php" class="gff-btn" style="width:100%; text-align:center; margin-top:10px; display:block;">Proceed to Checkout</a>
        </div>
    </div>
</div>

<?php endif; ?>

<?php include '../includes/customer_footer.php'; ?>
