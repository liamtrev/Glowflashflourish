<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['customer']);
verify_csrf();

$success = '';
$error = '';

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_profile') {
    $fullName = clean($_POST['full_name']);
    $email = clean($_POST['email']);
    $phone = clean($_POST['phone']);

    if (empty($fullName) || empty($email)) {
        $error = "Name and email are required.";
    } else {
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $check->execute([$email, $user['id']]);
        if ($check->fetch()) {
            $error = "That email is already used by another account.";
        } else {
            $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ? WHERE id = ?")
                ->execute([$fullName, $email, $phone, $user['id']]);
            $_SESSION['full_name'] = $fullName;
            $success = "Profile updated successfully.";
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$user['id']]);
            $user = $stmt->fetch();
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'change_password') {
    $current = $_POST['current_password'] ?? '';
    $newPass = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!password_verify($current, $user['password'])) {
        $error = "Current password is incorrect.";
    } elseif (strlen($newPass) < 6) {
        $error = "New password must be at least 6 characters.";
    } elseif ($newPass !== $confirm) {
        $error = "New passwords do not match.";
    } else {
        $hashed = password_hash($newPass, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hashed, $user['id']]);
        $success = "Password changed successfully.";
    }
}

$pageTitle = "My Profile";
include '../includes/customer_header.php';
?>

<?php if ($success): ?><script>document.addEventListener('DOMContentLoaded', () => showToast(<?php echo json_encode($success); ?>, 'success'));</script><?php endif; ?>
<?php if ($error): ?><script>document.addEventListener('DOMContentLoaded', () => showToast(<?php echo json_encode($error); ?>, 'error'));</script><?php endif; ?>

<h1>My Profile</h1>

<div class="gff-section" style="max-width:500px; margin-top:20px;">
    <h2>Profile Details</h2>
    <form method="POST" style="display:flex; flex-direction:column; gap:14px; margin-top:14px;">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="update_profile">
        <div>
            <label style="display:block; margin-bottom:6px; color:var(--text-muted); font-size:13px;">Full Name</label>
            <input type="text" name="full_name" value="<?php echo clean($user['full_name']); ?>" required style="width:100%; padding:10px; border-radius:6px; border:none; background:#2A3140; color:var(--text-main);">
        </div>
        <div>
            <label style="display:block; margin-bottom:6px; color:var(--text-muted); font-size:13px;">Email</label>
            <input type="email" name="email" value="<?php echo clean($user['email']); ?>" required style="width:100%; padding:10px; border-radius:6px; border:none; background:#2A3140; color:var(--text-main);">
        </div>
        <div>
            <label style="display:block; margin-bottom:6px; color:var(--text-muted); font-size:13px;">Phone</label>
            <input type="text" name="phone" value="<?php echo clean($user['phone'] ?? ''); ?>" style="width:100%; padding:10px; border-radius:6px; border:none; background:#2A3140; color:var(--text-main);">
        </div>
        <button type="submit" class="gff-btn" style="width:fit-content;">Save Profile</button>
    </form>
</div>

<div class="gff-section" style="max-width:500px;">
    <h2>Change Password</h2>
    <form method="POST" style="display:flex; flex-direction:column; gap:14px; margin-top:14px;">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="change_password">
        <div>
            <label style="display:block; margin-bottom:6px; color:var(--text-muted); font-size:13px;">Current Password</label>
            <input type="password" name="current_password" required style="width:100%; padding:10px; border-radius:6px; border:none; background:#2A3140; color:var(--text-main);">
        </div>
        <div>
            <label style="display:block; margin-bottom:6px; color:var(--text-muted); font-size:13px;">New Password</label>
            <input type="password" name="new_password" required minlength="6" style="width:100%; padding:10px; border-radius:6px; border:none; background:#2A3140; color:var(--text-main);">
        </div>
        <div>
            <label style="display:block; margin-bottom:6px; color:var(--text-muted); font-size:13px;">Confirm New Password</label>
            <input type="password" name="confirm_password" required minlength="6" style="width:100%; padding:10px; border-radius:6px; border:none; background:#2A3140; color:var(--text-main);">
        </div>
        <button type="submit" class="gff-btn" style="width:fit-content;">Change Password</button>
    </form>
</div>

<?php include '../includes/customer_footer.php'; ?>
