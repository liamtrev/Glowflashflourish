<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_once '../includes/mpesa_functions.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    echo json_encode(['success' => false, 'message' => 'Please log in.']);
    exit;
}

$orderId = (int) ($_POST['order_id'] ?? 0);
$phone = $_POST['phone'] ?? '';

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND customer_id = ?");
$stmt->execute([$orderId, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    echo json_encode(['success' => false, 'message' => 'Order not found.']);
    exit;
}

$result = mpesa_stk_push($phone, $order['grand_total'], $order['order_number']);

if ($result['success']) {
    $pdo->prepare("UPDATE orders SET payment_method = 'mpesa', mpesa_checkout_request_id = ? WHERE id = ?")
        ->execute([$result['checkout_request_id'], $orderId]);
}

echo json_encode($result);
