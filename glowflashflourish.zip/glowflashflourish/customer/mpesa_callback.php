<?php
// Safaricom calls this URL automatically once the customer enters their PIN
// (or cancels/times out). It does NOT run in a browser - no session, no login.
require_once '../config/config.php';
require_once '../config/db.php';

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

// Log every callback for debugging - useful since you can't "see" what Safaricom sent otherwise.
file_put_contents(__DIR__ . '/../mpesa_callback_log.txt', date('Y-m-d H:i:s') . " - " . $rawInput . "\n", FILE_APPEND);

$callback = $data['Body']['stkCallback'] ?? null;

if ($callback) {
    $checkoutRequestId = $callback['CheckoutRequestID'];
    $resultCode = $callback['ResultCode'];

    if ($resultCode === 0) {
        // Payment succeeded - pull out the M-Pesa receipt number from the metadata
        $items = $callback['CallbackMetadata']['Item'] ?? [];
        $receiptNumber = null;
        foreach ($items as $item) {
            if ($item['Name'] === 'MpesaReceiptNumber') {
                $receiptNumber = $item['Value'];
            }
        }

        $pdo->prepare("UPDATE orders SET payment_status = 'paid', mpesa_receipt_number = ? WHERE mpesa_checkout_request_id = ?")
            ->execute([$receiptNumber, $checkoutRequestId]);
    }
    // If resultCode isn't 0, the customer cancelled or it timed out - order just stays unpaid,
    // they can retry payment or pay cash on delivery instead.
}

// Safaricom expects this exact response format to know we received it successfully.
header('Content-Type: application/json');
echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Accepted']);
