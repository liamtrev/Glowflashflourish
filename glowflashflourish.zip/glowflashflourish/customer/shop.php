<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['customer']);

// ---------- FILTERS ----------
$filterCategory = isset($_GET['category']) ? (int) $_GET['category'] : 0;
$searchTerm = isset($_GET['q']) ? clean($_GET['q']) : '';
$minPrice = isset($_GET['min_price']) && $_GET['min_price'] !== '' ? (float) $_GET['min_price'] : null;
$maxPrice = isset($_GET['max_price']) && $_GET['max_price'] !== '' ? (float) $_GET['max_price'] : null;
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'newest';
$selectedAttrs = $_GET['attr'] ?? []; // array of "AttributeName|Value" strings

// ---------- CATEGORIES (for filter sidebar, unlimited depth) ----------
$allCategories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();

// Filtering by any category (at any depth) includes all of its nested subcategories' products too
$categoryIds = [];
if ($filterCategory > 0) {
    $categoryIds = get_category_descendant_ids($pdo, $filterCategory);
}

// ---------- ATTRIBUTE FILTER OPTIONS (Color/Type/Litres/Dimensions across all products) ----------
$attributeRows = $pdo->query("SELECT DISTINCT attribute_name, attribute_value FROM product_variants ORDER BY attribute_name ASC, attribute_value ASC")->fetchAll();
$attrGroups = [];
foreach ($attributeRows as $row) {
    $attrGroups[$row['attribute_name']][] = $row['attribute_value'];
}

// ---------- BUILD PRODUCT QUERY ----------
$sql = "SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.is_active = 1";
$params = [];

if (!empty($categoryIds)) {
    $placeholders = implode(',', array_fill(0, count($categoryIds), '?'));
    $sql .= " AND p.category_id IN ($placeholders)";
    $params = array_merge($params, $categoryIds);
}
if ($searchTerm !== '') {
    $sql .= " AND p.name LIKE ?";
    $params[] = "%$searchTerm%";
}
if ($minPrice !== null) {
    $sql .= " AND p.selling_price >= ?";
    $params[] = $minPrice;
}
if ($maxPrice !== null) {
    $sql .= " AND p.selling_price <= ?";
    $params[] = $maxPrice;
}
if (!empty($selectedAttrs)) {
    $orConditions = [];
    foreach ($selectedAttrs as $pair) {
        if (strpos($pair, '|') === false) continue;
        [$n, $v] = explode('|', $pair, 2);
        $orConditions[] = "(pv.attribute_name = ? AND pv.attribute_value = ?)";
        $params[] = $n;
        $params[] = $v;
    }
    if (!empty($orConditions)) {
        $sql .= " AND EXISTS (SELECT 1 FROM product_variants pv WHERE pv.product_id = p.id AND (" . implode(' OR ', $orConditions) . "))";
    }
}

switch ($sort) {
    case 'price_low': $sql .= " ORDER BY p.selling_price ASC"; break;
    case 'price_high': $sql .= " ORDER BY p.selling_price DESC"; break;
    case 'name': $sql .= " ORDER BY p.name ASC"; break;
    default: $sql .= " ORDER BY p.created_at DESC";
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rawProducts = $stmt->fetchAll();

// Filter out anything with zero total stock (product stock, or summed variant stock)
$products = [];
foreach ($rawProducts as $p) {
    if (get_product_total_stock($pdo, $p) > 0) {
        $products[] = $p;
    }
}

// ---------- PAGINATION ----------
$perPage = 12;
$currentPage = max(1, (int) ($_GET['page'] ?? 1));
$totalProductsFound = count($products);
$totalPages = max(1, ceil($totalProductsFound / $perPage));
$currentPage = min($currentPage, $totalPages);
$products = array_slice($products, ($currentPage - 1) * $perPage, $perPage);

$pageTitle = "Shop";
include '../includes/customer_header.php';
?>

<div class="gff-shop-layout">
    <aside class="gff-filters">
        <form method="GET" id="filterForm">
            <?php if ($searchTerm !== ''): ?><input type="hidden" name="q" value="<?php echo clean($searchTerm); ?>"><?php endif; ?>

            <h3>Category</h3>
            <label>
                <input type="radio" name="category" value="0" onchange="this.form.submit()" <?php echo $filterCategory === 0 ? 'checked' : ''; ?>>
                All Categories
            </label>
            <?php
            function render_category_radios($categories, $filterCategory, $parentId = null, $depth = 0) {
                foreach ($categories as $c) {
                    if ($c['parent_id'] !== $parentId) continue;
                    $paddingLeft = $depth * 16;
                    $fontSize = $depth > 0 ? 'font-size:12px;' : '';
                    echo '<label style="padding-left:' . $paddingLeft . 'px; ' . $fontSize . '">';
                    echo '<input type="radio" name="category" value="' . $c['id'] . '" onchange="this.form.submit()" ' . ($filterCategory === (int)$c['id'] ? 'checked' : '') . '>';
                    echo htmlspecialchars($c['name']);
                    echo '</label>';
                    render_category_radios($categories, $filterCategory, $c['id'], $depth + 1);
                }
            }
            render_category_radios($allCategories, $filterCategory);
            ?>

            <h3>Price Range (KSh)</h3>
            <div class="gff-price-inputs">
                <input type="number" name="min_price" placeholder="Min" value="<?php echo $minPrice !== null ? $minPrice : ''; ?>">
                <span>-</span>
                <input type="number" name="max_price" placeholder="Max" value="<?php echo $maxPrice !== null ? $maxPrice : ''; ?>">
            </div>

            <?php foreach ($attrGroups as $attrName => $values): ?>
                <h3><?php echo clean($attrName); ?></h3>
                <?php foreach (array_unique($values) as $val):
                    $pairKey = $attrName . '|' . $val;
                    $isChecked = in_array($pairKey, $selectedAttrs);
                ?>
                    <label>
                        <input type="checkbox" name="attr[]" value="<?php echo clean($pairKey); ?>" onchange="this.form.submit()" <?php echo $isChecked ? 'checked' : ''; ?>>
                        <?php echo clean($val); ?>
                    </label>
                <?php endforeach; ?>
            <?php endforeach; ?>

            <button type="submit" class="gff-btn gff-btn-small" style="margin-top:10px; width:100%;">Apply</button>
        </form>
    </aside>

    <div class="gff-product-grid-area">
        <div class="gff-grid-toolbar">
            <div style="color:var(--text-muted); font-size:13px;">
                <?php echo count($products); ?> product<?php echo count($products) !== 1 ? 's' : ''; ?> found
                <?php if ($searchTerm !== ''): ?> for "<?php echo clean($searchTerm); ?>"<?php endif; ?>
            </div>
            <form method="GET">
                <?php if ($filterCategory > 0): ?><input type="hidden" name="category" value="<?php echo $filterCategory; ?>"><?php endif; ?>
                <?php if ($searchTerm !== ''): ?><input type="hidden" name="q" value="<?php echo clean($searchTerm); ?>"><?php endif; ?>
                <?php if ($minPrice !== null): ?><input type="hidden" name="min_price" value="<?php echo $minPrice; ?>"><?php endif; ?>
                <?php if ($maxPrice !== null): ?><input type="hidden" name="max_price" value="<?php echo $maxPrice; ?>"><?php endif; ?>
                <?php foreach ($selectedAttrs as $a): ?><input type="hidden" name="attr[]" value="<?php echo clean($a); ?>"><?php endforeach; ?>
                <select name="sort" onchange="this.form.submit()">
                    <option value="newest" <?php echo $sort === 'newest' ? 'selected' : ''; ?>>Newest</option>
                    <option value="price_low" <?php echo $sort === 'price_low' ? 'selected' : ''; ?>>Price: Low to High</option>
                    <option value="price_high" <?php echo $sort === 'price_high' ? 'selected' : ''; ?>>Price: High to Low</option>
                    <option value="name" <?php echo $sort === 'name' ? 'selected' : ''; ?>>Name: A-Z</option>
                </select>
            </form>
        </div>

        <?php if (empty($products)): ?>
            <div class="gff-empty-state">
                <h3>No products found</h3>
                <p>Try adjusting your filters or search term.</p>
            </div>
        <?php else: ?>
        <div class="gff-product-grid">
            <?php foreach ($products as $i => $p):
                $variants = get_product_variants($pdo, $p['id']);
                $basePrice = get_effective_price($p);
            ?>
            <div class="gff-product-card" style="animation-delay: <?php echo min($i * 0.03, 0.3); ?>s;">
                <?php if (!empty($p['image'])): ?>
                    <img src="<?php echo BASE_URL . $p['image']; ?>" class="gff-product-image gff-viewable-img" alt="<?php echo clean($p['name']); ?>">
                <?php else: ?>
                    <div class="gff-product-image-placeholder">No Image</div>
                <?php endif; ?>
                <div class="gff-product-info">
                    <div>
                        <?php if ($p['is_clearance']): ?><span class="gff-clearance-badge">CLEARANCE</span><?php endif; ?>
                        <?php if ($p['discount_amount'] > 0): ?><span class="gff-discount-badge">Save KSh <?php echo number_format($p['discount_amount'], 0); ?></span><?php endif; ?>
                    </div>
                    <div class="gff-product-category"><?php echo clean($p['category_name']); ?></div>
                    <div class="gff-product-name"><?php echo clean($p['name']); ?></div>
                    <div class="gff-product-price" data-base-price="<?php echo $basePrice; ?>">
                        <?php if ($p['discount_amount'] > 0): ?>
                            <span class="gff-original-price">KSh <?php echo number_format($p['selling_price'], 2); ?></span>
                        <?php endif; ?>
                        <span class="gff-current-price">KSh <?php echo number_format($basePrice, 2); ?></span>
                    </div>

                    <?php if (!empty($variants)): ?>
                        <select class="gff-variant-select" data-base-price="<?php echo $basePrice; ?>">
                            <?php foreach ($variants as $v): if ($v['stock_quantity'] <= 0) continue; ?>
                                <option value="<?php echo $v['id']; ?>" data-adjustment="<?php echo $v['price_adjustment']; ?>" data-stock="<?php echo $v['stock_quantity']; ?>">
                                    <?php echo clean($v['attribute_name']); ?>: <?php echo clean($v['attribute_value']); ?> (<?php echo $v['stock_quantity']; ?> left)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    <?php endif; ?>

                    <div class="gff-qty-stepper">
                        <button type="button" class="gff-qty-minus">-</button>
                        <input type="text" class="gff-qty-input" value="1" readonly>
                        <button type="button" class="gff-qty-plus">+</button>
                    </div>
                    <button class="gff-add-to-cart" data-product-id="<?php echo $p['id']; ?>">Add to Cart</button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <?php if ($totalPages > 1): ?>
        <div style="display:flex; justify-content:center; gap:8px; margin-top:30px;">
            <?php
            $baseParams = $_GET;
            for ($i = 1; $i <= $totalPages; $i++):
                $baseParams['page'] = $i;
                $url = '?' . http_build_query($baseParams);
            ?>
                <a href="<?php echo $url; ?>" class="gff-btn gff-btn-small <?php echo $i === $currentPage ? '' : 'gff-btn-outline'; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>
        </div>
        <?php endif; ?>

        <?php endif; ?>
    </div>
</div>

<?php include '../includes/customer_footer.php'; ?>
