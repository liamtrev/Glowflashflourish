<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    echo json_encode(['payment_status' => 'unknown']);
    exit;
}

$orderId = (int) ($_GET['order_id'] ?? 0);

$stmt = $pdo->prepare("SELECT payment_status FROM orders WHERE id = ? AND customer_id = ?");
$stmt->execute([$orderId, $_SESSION['user_id']]);
$order = $stmt->fetch();

echo json_encode(['payment_status' => $order ? $order['payment_status'] : 'unknown']);
