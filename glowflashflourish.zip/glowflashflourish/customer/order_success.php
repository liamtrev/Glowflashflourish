<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['customer']);

$orderNumber = isset($_GET['order']) ? clean($_GET['order']) : '';
$phone = isset($_GET['phone']) ? clean($_GET['phone']) : '';

$stmt = $pdo->prepare("SELECT * FROM orders WHERE order_number = ? AND customer_id = ?");
$stmt->execute([$orderNumber, $_SESSION['user_id']]);
$order = $stmt->fetch();

$pageTitle = "Order Placed";
include '../includes/customer_header.php';
?>

<div class="gff-empty-state">
    <h3 style="color:var(--status-confirmed); font-size:22px;">&#10003; Order Placed Successfully!</h3>
    <p style="margin-top:10px;">Your order number is:</p>
    <p style="font-size:20px; font-weight:bold; color:var(--accent-teal); margin-top:6px;"><?php echo clean($orderNumber); ?></p>

    <?php if ($order && $order['payment_method'] === 'mpesa' && $order['payment_status'] === 'unpaid'): ?>
        <div id="mpesaPaymentBox" class="gff-section" style="max-width:400px; margin:20px auto; text-align:left;">
            <h3 style="margin-bottom:10px;">Pay with M-Pesa</h3>
            <p style="font-size:13px; color:var(--text-muted); margin-bottom:12px;">
                We'll send a payment prompt to your phone. Enter your M-Pesa PIN there to complete payment.
            </p>
            <input type="text" id="mpesaPhone" value="<?php echo $phone; ?>" placeholder="07XXXXXXXX" style="width:100%; padding:10px; border-radius:6px; border:none; background:#2A3140; color:var(--text-main); margin-bottom:10px;">
            <button id="mpesaPayBtn" class="gff-btn" style="width:100%;" data-order-id="<?php echo $order['id']; ?>">
                Pay KSh <?php echo number_format($order['grand_total'], 2); ?> Now
            </button>
            <p id="mpesaStatus" style="font-size:13px; margin-top:10px; color:var(--text-muted);"></p>
        </div>
        <script>
        document.getElementById('mpesaPayBtn').addEventListener('click', function () {
            const btn = this;
            const orderId = btn.dataset.orderId;
            const phone = document.getElementById('mpesaPhone').value;
            const statusEl = document.getElementById('mpesaStatus');

            btn.disabled = true;
            btn.textContent = 'Sending prompt...';

            const formData = new FormData();
            formData.append('order_id', orderId);
            formData.append('phone', phone);

            fetch('mpesa_initiate.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        statusEl.textContent = data.message;
                        statusEl.style.color = 'var(--accent-teal)';
                        pollPaymentStatus(orderId, statusEl);
                    } else {
                        statusEl.textContent = data.message;
                        statusEl.style.color = 'var(--status-cancelled)';
                        btn.disabled = false;
                        btn.textContent = 'Try Again';
                    }
                })
                .catch(() => {
                    statusEl.textContent = 'Could not reach the server. Please try again.';
                    statusEl.style.color = 'var(--status-cancelled)';
                    btn.disabled = false;
                    btn.textContent = 'Try Again';
                });
        });

        function pollPaymentStatus(orderId, statusEl) {
            let attempts = 0;
            const interval = setInterval(() => {
                attempts++;
                fetch('order_status_check.php?order_id=' + orderId)
                    .then(res => res.json())
                    .then(data => {
                        if (data.payment_status === 'paid') {
                            clearInterval(interval);
                            statusEl.textContent = 'Payment received! Thank you.';
                            statusEl.style.color = 'var(--status-confirmed)';
                            document.getElementById('mpesaPaymentBox').style.opacity = '0.7';
                        } else if (attempts > 20) { // stop after ~1 minute
                            clearInterval(interval);
                            statusEl.textContent = 'Still waiting on payment. If you completed it on your phone, it may take a moment to reflect - check My Orders shortly.';
                        }
                    });
            }, 3000);
        }
        </script>
    <?php endif; ?>

    <p style="margin-top:14px;">We'll review your order and confirm payment shortly. You can track its status in My Orders.</p>
    <div style="margin-top:20px; display:flex; gap:12px; justify-content:center;">
        <a href="orders.php" class="gff-btn">View My Orders</a>
        <a href="shop.php" class="gff-btn gff-btn-outline">Continue Shopping</a>
    </div>
</div>

<?php include '../includes/customer_footer.php'; ?>
