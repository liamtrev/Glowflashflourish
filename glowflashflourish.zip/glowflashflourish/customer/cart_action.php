<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    echo json_encode(['success' => false, 'message' => 'Please log in as a customer to use the cart.']);
    exit;
}

$customerId = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';
$productId = (int) ($_POST['product_id'] ?? 0);
$variantId = !empty($_POST['variant_id']) ? (int) $_POST['variant_id'] : null;

function get_cart_count($pdo, $customerId) {
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(quantity),0) as cnt FROM cart_items WHERE customer_id = ?");
    $stmt->execute([$customerId]);
    return (int) $stmt->fetch()['cnt'];
}

function get_cart_grand_total($pdo, $customerId) {
    $stmt = $pdo->prepare("
        SELECT ci.quantity, p.selling_price, p.discount_amount, pv.price_adjustment
        FROM cart_items ci
        JOIN products p ON p.id = ci.product_id
        LEFT JOIN product_variants pv ON pv.id = ci.variant_id
        WHERE ci.customer_id = ?
    ");
    $stmt->execute([$customerId]);
    $total = 0;
    foreach ($stmt->fetchAll() as $row) {
        $base = max($row['selling_price'] - $row['discount_amount'], 0);
        $unitPrice = max($base + (float) ($row['price_adjustment'] ?? 0), 0);
        $total += $unitPrice * $row['quantity'];
    }
    return $total;
}

if ($action === 'add') {
    $quantity = max(1, (int) ($_POST['quantity'] ?? 1));

    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$productId]);
    $product = $stmt->fetch();

    if (!$product) {
        echo json_encode(['success' => false, 'message' => 'Product not found.']);
        exit;
    }
    if (!$product['is_active']) {
        echo json_encode(['success' => false, 'message' => 'This product is no longer available.']);
        exit;
    }

    // Check stock at the right level: variant stock if a variant was picked, else product stock
    if ($variantId) {
        $vStmt = $pdo->prepare("SELECT stock_quantity FROM product_variants WHERE id = ? AND product_id = ?");
        $vStmt->execute([$variantId, $productId]);
        $variant = $vStmt->fetch();
        if (!$variant) {
            echo json_encode(['success' => false, 'message' => 'Selected option not found.']);
            exit;
        }
        if ($variant['stock_quantity'] < $quantity) {
            echo json_encode(['success' => false, 'message' => 'Not enough stock available for that option.']);
            exit;
        }
    } else {
        if ($product['stock_quantity'] < $quantity) {
            echo json_encode(['success' => false, 'message' => 'Not enough stock available.']);
            exit;
        }
    }

    $existing = $pdo->prepare("SELECT * FROM cart_items WHERE customer_id = ? AND product_id = ? AND variant_id <=> ?");
    $existing->execute([$customerId, $productId, $variantId]);
    $row = $existing->fetch();

    if ($row) {
        $pdo->prepare("UPDATE cart_items SET quantity = quantity + ? WHERE id = ?")->execute([$quantity, $row['id']]);
    } else {
        $pdo->prepare("INSERT INTO cart_items (customer_id, product_id, variant_id, quantity) VALUES (?, ?, ?, ?)")->execute([$customerId, $productId, $variantId, $quantity]);
    }

    echo json_encode(['success' => true, 'message' => 'Added to cart!', 'cartCount' => get_cart_count($pdo, $customerId)]);
    exit;
}

if ($action === 'update') {
    $quantity = max(1, (int) ($_POST['quantity'] ?? 1));
    $pdo->prepare("UPDATE cart_items SET quantity = ? WHERE customer_id = ? AND product_id = ? AND variant_id <=> ?")
        ->execute([$quantity, $customerId, $productId, $variantId]);

    $stmt = $pdo->prepare("
        SELECT ci.quantity, p.selling_price, p.discount_amount, pv.price_adjustment
        FROM cart_items ci
        JOIN products p ON p.id = ci.product_id
        LEFT JOIN product_variants pv ON pv.id = ci.variant_id
        WHERE ci.customer_id = ? AND ci.product_id = ? AND ci.variant_id <=> ?
    ");
    $stmt->execute([$customerId, $productId, $variantId]);
    $line = $stmt->fetch();
    $lineTotal = 0;
    if ($line) {
        $base = max($line['selling_price'] - $line['discount_amount'], 0);
        $unitPrice = max($base + (float) ($line['price_adjustment'] ?? 0), 0);
        $lineTotal = $unitPrice * $line['quantity'];
    }

    echo json_encode([
        'success' => true,
        'cartCount' => get_cart_count($pdo, $customerId),
        'lineTotal' => number_format($lineTotal, 2),
        'cartTotal' => number_format(get_cart_grand_total($pdo, $customerId), 2)
    ]);
    exit;
}

if ($action === 'remove') {
    $pdo->prepare("DELETE FROM cart_items WHERE customer_id = ? AND product_id = ? AND variant_id <=> ?")->execute([$customerId, $productId, $variantId]);

    echo json_encode([
        'success' => true,
        'message' => 'Item removed.',
        'cartCount' => get_cart_count($pdo, $customerId),
        'cartTotal' => number_format(get_cart_grand_total($pdo, $customerId), 2)
    ]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Unknown action.']);
