<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['customer']);

$stmt = $pdo->prepare("SELECT * FROM orders WHERE customer_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$orders = $stmt->fetchAll();

$pageTitle = "My Orders";
include '../includes/customer_header.php';
?>

<h1 style="margin-bottom:20px;">My Orders</h1>

<?php if (empty($orders)): ?>
    <div class="gff-empty-state">
        <h3>No orders yet</h3>
        <p>Once you place an order, it will show up here.</p>
        <a href="shop.php" class="gff-btn" style="margin-top:16px; display:inline-block;">Browse Shop</a>
    </div>
<?php else: ?>
<div class="gff-section">
    <table class="gff-table">
        <tr>
            <th>Order #</th>
            <th>Date</th>
            <th>Total</th>
            <th>Payment</th>
            <th>Status</th>
        </tr>
        <?php foreach ($orders as $o): ?>
        <tr>
            <td><?php echo clean($o['order_number']); ?></td>
            <td><?php echo date('d M Y, h:i A', strtotime($o['created_at'])); ?></td>
            <td>KSh <?php echo number_format($o['grand_total'], 2); ?></td>
            <td>
                <span class="badge <?php echo $o['payment_status'] === 'paid' ? 'badge-confirmed' : 'badge-pending'; ?>">
                    <?php echo ucfirst($o['payment_status']); ?>
                </span>
            </td>
            <td>
                <?php
                $badgeClass = [
                    'pending' => 'badge-pending',
                    'completed' => 'badge-completed',
                    'cancelled' => 'badge-cancelled',
                    'refunded' => 'badge-refund'
                ][$o['status']];
                ?>
                <span class="badge <?php echo $badgeClass; ?>"><?php echo ucfirst($o['status']); ?></span>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
<?php endif; ?>

<?php include '../includes/customer_footer.php'; ?>
