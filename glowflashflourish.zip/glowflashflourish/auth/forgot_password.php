<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
verify_csrf();

$success = '';
$error = '';
$resetLink = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = clean($_POST['email']);

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Always show the same message whether or not the email exists,
    // so people can't use this form to guess registered emails.
    $success = "If an account exists with that email, a password reset link has been generated.";

    if ($user) {
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

        $pdo->prepare("UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?")
            ->execute([$token, $expires, $user['id']]);

        $resetLink = BASE_URL . "auth/reset_password.php?token=" . $token;

        // Try to send a real email if the server has mail configured.
        // On most local XAMPP setups this silently fails, which is fine -
        // the link is also shown on screen below as a fallback for local testing.
        @mail($email, "Reset your " . SITE_NAME . " password",
            "Click this link to reset your password (valid for 1 hour):\n\n" . $resetLink);
    }
}

$pageTitle = "Forgot Password";
include '../includes/header.php';
?>

<div class="gff-form">
    <h2>Forgot your password?</h2>
    <?php if ($success): ?>
        <div class="gff-success-msg"><?php echo $success; ?></div>
        <?php if ($resetLink): ?>
            <div style="background:#2A3140; padding:14px; border-radius:8px; margin-bottom:14px; word-break:break-all; font-size:12px;">
                <strong>Local testing note:</strong> since email isn't configured on this server yet, here's the reset link directly:<br>
                <a href="<?php echo $resetLink; ?>" style="color:var(--accent-teal);"><?php echo $resetLink; ?></a>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <p style="color:var(--text-muted); margin-bottom:14px; font-size:14px;">
            Enter the email on your account and we'll generate a password reset link.
        </p>
        <form method="POST">
            <?php echo csrf_field(); ?>
            <input type="email" name="email" placeholder="Email" required>
            <button type="submit">Send Reset Link</button>
        </form>
    <?php endif; ?>
    <p style="margin-top:14px; color:var(--text-muted);">
        <a href="login.php" style="color:var(--accent-teal);">Back to Login</a>
    </p>
</div>

<?php include '../includes/footer.php'; ?>
