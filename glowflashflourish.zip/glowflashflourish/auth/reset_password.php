<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
verify_csrf();

$token = $_GET['token'] ?? ($_POST['token'] ?? '');
$error = '';
$success = '';

$stmt = $pdo->prepare("SELECT * FROM users WHERE reset_token = ? AND reset_token_expires > NOW()");
$stmt->execute([$token]);
$user = $stmt->fetch();

if (!$user) {
    $error = "This reset link is invalid or has expired. Please request a new one.";
}

if ($user && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?")
            ->execute([$hashed, $user['id']]);
        $success = "Password updated! You can now log in with your new password.";
        $user = null; // hide the form now that it's done
    }
}

$pageTitle = "Reset Password";
include '../includes/header.php';
?>

<div class="gff-form">
    <h2>Reset Your Password</h2>
    <?php if ($error): ?><div class="gff-error"><?php echo $error; ?></div><?php endif; ?>
    <?php if ($success): ?><div class="gff-success-msg"><?php echo $success; ?></div><?php endif; ?>

    <?php if ($user): ?>
    <form method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="token" value="<?php echo clean($token); ?>">
        <input type="password" name="password" placeholder="New Password (min 6 characters)" required minlength="6">
        <input type="password" name="confirm_password" placeholder="Confirm New Password" required minlength="6">
        <button type="submit">Reset Password</button>
    </form>
    <?php endif; ?>

    <p style="margin-top:14px; color:var(--text-muted);">
        <a href="login.php" style="color:var(--accent-teal);">Back to Login</a>
    </p>
</div>

<?php include '../includes/footer.php'; ?>
