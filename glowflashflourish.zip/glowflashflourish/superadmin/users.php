<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['superadmin']);
verify_csrf();

$success = '';
$error = '';

// ---------- CREATE ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create') {
    $full_name = clean($_POST['full_name']);
    $email = clean($_POST['email']);
    $phone = clean($_POST['phone']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    if (!in_array($role, ['admin', 'staff'])) {
        $error = "Invalid role selected.";
    } elseif (empty($full_name) || empty($email) || empty($password)) {
        $error = "Please fill in all required fields.";
    } else {
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);
        if ($check->fetch()) {
            $error = "An account with that email already exists.";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (full_name, email, phone, password, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$full_name, $email, $phone, $hashed, $role]);
            $success = ucfirst($role) . " account created successfully.";
        }
    }
}

// ---------- UPDATE ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    $id = (int) $_POST['id'];
    $full_name = clean($_POST['full_name']);
    $email = clean($_POST['email']);
    $phone = clean($_POST['phone']);
    $role = $_POST['role'];

    if (in_array($role, ['admin', 'staff'])) {
        $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, role = ? WHERE id = ?");
        $stmt->execute([$full_name, $email, $phone, $role, $id]);

        // Optional password reset
        if (!empty($_POST['password'])) {
            $hashed = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hashed, $id]);
        }
        $success = "Account updated successfully.";
    }
}

// ---------- TOGGLE STATUS ----------
if (isset($_GET['toggle'])) {
    $id = (int) $_GET['toggle'];
    if ($id !== (int) $_SESSION['user_id']) { // don't let superadmin disable themselves
        $stmt = $pdo->prepare("SELECT status FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if ($row) {
            $newStatus = $row['status'] === 'active' ? 'disabled' : 'active';
            $pdo->prepare("UPDATE users SET status = ? WHERE id = ?")->execute([$newStatus, $id]);
        }
    }
    header("Location: users.php?toggled=1");
    exit;
}
if (isset($_GET['toggled'])) {
    $success = "Account status updated successfully.";
}

// ---------- FETCH FOR EDIT ----------
$editUser = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role IN ('admin','staff')");
    $stmt->execute([(int) $_GET['edit']]);
    $editUser = $stmt->fetch();
}

// ---------- FETCH LIST ----------
$users = $pdo->query("SELECT * FROM users WHERE role IN ('admin','staff') ORDER BY created_at DESC")->fetchAll();

$pageTitle = "Manage Admin & Staff";
include '../includes/header.php';
?>

<div class="gff-nav">
    <a href="dashboard.php">&larr; Back to Dashboard</a>
</div>

<h1>Manage Admin & Staff Accounts</h1>

<?php if ($success): ?><script>document.addEventListener('DOMContentLoaded', () => showToast(<?php echo json_encode($success); ?>, 'success'));</script><?php endif; ?>
<?php if ($error): ?><script>document.addEventListener('DOMContentLoaded', () => showToast(<?php echo json_encode($error); ?>, 'error'));</script><?php endif; ?>

<div class="gff-section">
    <h2><?php echo $editUser ? 'Edit Account' : 'Add New Admin or Staff'; ?></h2>
    <form method="POST" class="gff-form-inline">
        <?php echo csrf_field(); ?>
        <?php echo csrf_field(); ?>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="<?php echo $editUser ? 'update' : 'create'; ?>">
        <?php if ($editUser): ?>
            <input type="hidden" name="id" value="<?php echo $editUser['id']; ?>">
        <?php endif; ?>

        <div class="field">
            <label>Full Name</label>
            <input type="text" name="full_name" value="<?php echo $editUser ? clean($editUser['full_name']) : ''; ?>" required>
        </div>
        <div class="field">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo $editUser ? clean($editUser['email']) : ''; ?>" required>
        </div>
        <div class="field">
            <label>Phone</label>
            <input type="text" name="phone" value="<?php echo $editUser ? clean($editUser['phone']) : ''; ?>">
        </div>
        <div class="field">
            <label>Role</label>
            <select name="role">
                <option value="admin" <?php echo ($editUser && $editUser['role'] === 'admin') ? 'selected' : ''; ?>>Admin</option>
                <option value="staff" <?php echo ($editUser && $editUser['role'] === 'staff') ? 'selected' : ''; ?>>Staff</option>
            </select>
        </div>
        <div class="field">
            <label><?php echo $editUser ? 'New Password (optional)' : 'Password'; ?></label>
            <input type="password" name="password" <?php echo $editUser ? '' : 'required'; ?>>
        </div>
        <button type="submit" class="gff-btn"><?php echo $editUser ? 'Save Changes' : 'Create Account'; ?></button>
        <?php if ($editUser): ?>
            <a href="users.php" class="gff-btn gff-btn-outline">Cancel</a>
        <?php endif; ?>
    </form>
</div>

<div class="gff-section">
    <h2>All Admin & Staff Accounts</h2>
    <table class="gff-table">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Role</th>
            <th>Status</th>
            <th>Created</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($users as $u): ?>
        <tr>
            <td><?php echo clean($u['full_name']); ?></td>
            <td><?php echo clean($u['email']); ?></td>
            <td><?php echo clean($u['phone'] ?? ''); ?></td>
            <td><?php echo ucfirst($u['role']); ?></td>
            <td>
                <span class="badge <?php echo $u['status'] === 'active' ? 'badge-confirmed' : 'badge-cancelled'; ?>">
                    <?php echo ucfirst($u['status']); ?>
                </span>
            </td>
            <td><?php echo date('d M Y', strtotime($u['created_at'])); ?></td>
            <td>
                <a href="?edit=<?php echo $u['id']; ?>" class="gff-btn gff-btn-small gff-btn-outline">Edit</a>
                <?php if ((int)$u['id'] !== (int)$_SESSION['user_id']): ?>
                    <a href="?toggle=<?php echo $u['id']; ?>"
                       class="gff-btn gff-btn-small <?php echo $u['status'] === 'active' ? 'gff-btn-danger' : 'gff-btn-success'; ?> gff-confirm-action"
                       data-confirm="Are you sure you want to <?php echo $u['status'] === 'active' ? 'disable' : 'enable'; ?> this account?">
                        <?php echo $u['status'] === 'active' ? 'Disable' : 'Enable'; ?>
                    </a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($users)): ?>
        <tr><td colspan="7" style="color:var(--text-muted);">No Admin or Staff accounts yet.</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php include '../includes/footer.php'; ?>
