<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['customer']);

$orderNumber = isset($_GET['order']) ? clean($_GET['order']) : '';

$pageTitle = "Order Placed";
include '../includes/customer_header.php';
?>

<div class="gff-empty-state">
    <h3 style="color:var(--status-confirmed); font-size:22px;">&#10003; Order Placed Successfully!</h3>
    <p style="margin-top:10px;">Your order number is:</p>
    <p style="font-size:20px; font-weight:bold; color:var(--accent-teal); margin-top:6px;"><?php echo $orderNumber; ?></p>
    <p style="margin-top:14px;">We'll review your order and confirm payment shortly. You can track its status in My Orders.</p>
    <div style="margin-top:20px; display:flex; gap:12px; justify-content:center;">
        <a href="orders.php" class="gff-btn">View My Orders</a>
        <a href="shop.php" class="gff-btn gff-btn-outline">Continue Shopping</a>
    </div>
</div>

<?php include '../includes/customer_footer.php'; ?>
