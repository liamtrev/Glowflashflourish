<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['customer']);

$selectedAttrs = $_GET['attr'] ?? [];

// ---------- ATTRIBUTE FILTER OPTIONS ----------
$attributeRows = $pdo->query("SELECT DISTINCT attribute_name, attribute_value FROM product_variants ORDER BY attribute_name ASC, attribute_value ASC")->fetchAll();
$attrGroups = [];
foreach ($attributeRows as $row) {
    $attrGroups[$row['attribute_name']][] = $row['attribute_value'];
}

// ---------- BUILD QUERY: clearance items, newest first ----------
$sql = "SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.is_clearance = 1";
$params = [];

if (!empty($selectedAttrs)) {
    $orConditions = [];
    foreach ($selectedAttrs as $pair) {
        if (strpos($pair, '|') === false) continue;
        [$n, $v] = explode('|', $pair, 2);
        $orConditions[] = "(pv.attribute_name = ? AND pv.attribute_value = ?)";
        $params[] = $n;
        $params[] = $v;
    }
    if (!empty($orConditions)) {
        $sql .= " AND EXISTS (SELECT 1 FROM product_variants pv WHERE pv.product_id = p.id AND (" . implode(' OR ', $orConditions) . "))";
    }
}
$sql .= " ORDER BY p.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rawProducts = $stmt->fetchAll();

$products = [];
foreach ($rawProducts as $p) {
    if (get_product_total_stock($pdo, $p) > 0) {
        $products[] = $p;
    }
}

$pageTitle = "Clearance Sale";
include '../includes/customer_header.php';
?>

<div class="gff-shop-layout">
    <aside class="gff-filters">
        <form method="GET">
            <h3>Filter by Option</h3>
            <?php foreach ($attrGroups as $attrName => $values): ?>
                <h3><?php echo clean($attrName); ?></h3>
                <?php foreach (array_unique($values) as $val):
                    $pairKey = $attrName . '|' . $val;
                    $isChecked = in_array($pairKey, $selectedAttrs);
                ?>
                    <label>
                        <input type="checkbox" name="attr[]" value="<?php echo clean($pairKey); ?>" onchange="this.form.submit()" <?php echo $isChecked ? 'checked' : ''; ?>>
                        <?php echo clean($val); ?>
                    </label>
                <?php endforeach; ?>
            <?php endforeach; ?>
            <?php if (empty($attrGroups)): ?>
                <p style="color:var(--text-muted); font-size:12px;">No filter options yet.</p>
            <?php endif; ?>
        </form>
    </aside>

    <div class="gff-product-grid-area">
        <h1 style="margin-bottom:6px;">Clearance Sale</h1>
        <p style="color:var(--text-muted); font-size:13px; margin-bottom:16px;">Recently added products currently on clearance - <?php echo count($products); ?> found.</p>

        <?php if (empty($products)): ?>
            <div class="gff-empty-state">
                <h3>No clearance items right now</h3>
                <p>Check back soon, or browse the full shop instead.</p>
                <a href="shop.php" class="gff-btn" style="margin-top:16px; display:inline-block;">Go to Shop</a>
            </div>
        <?php else: ?>
        <div class="gff-product-grid">
            <?php foreach ($products as $i => $p):
                $variants = get_product_variants($pdo, $p['id']);
                $basePrice = get_effective_price($p);
            ?>
            <div class="gff-product-card" style="animation-delay: <?php echo min($i * 0.03, 0.3); ?>s;">
                <?php if (!empty($p['image'])): ?>
                    <img src="<?php echo BASE_URL . $p['image']; ?>" class="gff-product-image gff-viewable-img" alt="<?php echo clean($p['name']); ?>">
                <?php else: ?>
                    <div class="gff-product-image-placeholder">No Image</div>
                <?php endif; ?>
                <div class="gff-product-info">
                    <div>
                        <span class="gff-clearance-badge">CLEARANCE</span>
                        <?php if ($p['discount_amount'] > 0): ?><span class="gff-discount-badge">Save KSh <?php echo number_format($p['discount_amount'], 0); ?></span><?php endif; ?>
                    </div>
                    <div class="gff-product-category"><?php echo clean($p['category_name']); ?></div>
                    <div class="gff-product-name"><?php echo clean($p['name']); ?></div>
                    <div class="gff-product-price" data-base-price="<?php echo $basePrice; ?>">
                        <?php if ($p['discount_amount'] > 0): ?>
                            <span class="gff-original-price">KSh <?php echo number_format($p['selling_price'], 2); ?></span>
                        <?php endif; ?>
                        <span class="gff-current-price">KSh <?php echo number_format($basePrice, 2); ?></span>
                    </div>

                    <?php if (!empty($variants)): ?>
                        <select class="gff-variant-select" data-base-price="<?php echo $basePrice; ?>">
                            <?php foreach ($variants as $v): if ($v['stock_quantity'] <= 0) continue; ?>
                                <option value="<?php echo $v['id']; ?>" data-adjustment="<?php echo $v['price_adjustment']; ?>" data-stock="<?php echo $v['stock_quantity']; ?>">
                                    <?php echo clean($v['attribute_name']); ?>: <?php echo clean($v['attribute_value']); ?> (<?php echo $v['stock_quantity']; ?> left)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    <?php endif; ?>

                    <div class="gff-qty-stepper">
                        <button type="button" class="gff-qty-minus">-</button>
                        <input type="text" class="gff-qty-input" value="1" readonly>
                        <button type="button" class="gff-qty-plus">+</button>
                    </div>
                    <button class="gff-add-to-cart" data-product-id="<?php echo $p['id']; ?>">Add to Cart</button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/customer_footer.php'; ?>
