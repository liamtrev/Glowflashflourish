<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['customer']);

$stmt = $pdo->prepare("SELECT COALESCE(SUM(quantity),0) as cnt FROM cart_items WHERE customer_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$cartCount = $stmt->fetch()['cnt'];

$orderCountStmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM orders WHERE customer_id = ?");
$orderCountStmt->execute([$_SESSION['user_id']]);
$orderCount = $orderCountStmt->fetch()['cnt'];

$pageTitle = "My Account";
include '../includes/customer_header.php';
?>

<h1>Welcome, <?php echo clean($_SESSION['full_name']); ?></h1>
<p style="color:var(--text-muted); margin-top:8px;">
    Browse products, manage your cart, and track your orders here.
</p>

<div class="gff-overview" style="margin-top:24px;">
    <div class="gff-overview-card">
        <div class="gff-overview-icon" style="color:var(--accent-teal);">&#128722;</div>
        <div class="gff-overview-text">
            <div class="label">Items in Cart</div>
            <div class="value"><?php echo $cartCount; ?></div>
        </div>
    </div>
    <div class="gff-overview-card">
        <div class="gff-overview-icon" style="color:var(--accent-gold);">&#128230;</div>
        <div class="gff-overview-text">
            <div class="label">My Orders</div>
            <div class="value"><?php echo $orderCount; ?></div>
        </div>
    </div>
</div>

<div style="margin-top:24px; display:flex; gap:12px;">
    <a href="shop.php" class="gff-btn">Browse Shop</a>
    <a href="cart.php" class="gff-btn gff-btn-outline">View Cart</a>
    <a href="orders.php" class="gff-btn gff-btn-outline">My Orders</a>
</div>

<?php include '../includes/customer_footer.php'; ?>
