<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['customer']);

$stmt = $pdo->prepare("
    SELECT ci.*, p.name, p.selling_price, p.discount_amount, p.buying_price, p.image, p.stock_quantity,
           pv.attribute_name, pv.attribute_value, pv.price_adjustment, pv.stock_quantity as variant_stock
    FROM cart_items ci
    JOIN products p ON p.id = ci.product_id
    LEFT JOIN product_variants pv ON pv.id = ci.variant_id
    WHERE ci.customer_id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$cartItems = $stmt->fetchAll();

$error = '';

if (empty($cartItems)) {
    header("Location: cart.php");
    exit;
}

// Compute unit price per line: base effective price (after product discount) + variant adjustment
foreach ($cartItems as &$item) {
    $base = max($item['selling_price'] - $item['discount_amount'], 0);
    $item['unit_price'] = max($base + (float) ($item['price_adjustment'] ?? 0), 0);
    $item['available_stock'] = $item['variant_id'] ? $item['variant_stock'] : $item['stock_quantity'];
}
unset($item);

$subtotal = 0;
foreach ($cartItems as $item) {
    $subtotal += $item['unit_price'] * $item['quantity'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $addressLine = clean($_POST['address_line']);
    $city = clean($_POST['city']);
    $phone = clean($_POST['phone']);
    $notes = clean($_POST['notes']);

    if (empty($addressLine) || empty($city) || empty($phone)) {
        $error = "Please fill in your delivery address and phone number.";
    } else {
        // Re-check stock right before placing the order
        $stockOk = true;
        foreach ($cartItems as $item) {
            if ($item['quantity'] > $item['available_stock']) {
                $stockOk = false;
                $error = "Sorry, \"" . clean($item['name']) . "\" no longer has enough stock. Please update your cart.";
                break;
            }
        }

        if ($stockOk) {
            $deliveryAddress = "$addressLine, $city | Phone: $phone" . ($notes ? " | Notes: $notes" : "");
            $orderNumber = generate_order_number($pdo);

            $pdo->beginTransaction();

            $stmt = $pdo->prepare("INSERT INTO orders (order_number, customer_id, delivery_address, status, payment_status, discount_type, discount_mode, discount_value, subtotal, discount_amount, grand_total) VALUES (?, ?, ?, 'pending', 'unpaid', 'none', 'fixed', 0, ?, 0, ?)");
            $stmt->execute([$orderNumber, $_SESSION['user_id'], $deliveryAddress, $subtotal, $subtotal]);
            $orderId = $pdo->lastInsertId();

            foreach ($cartItems as $item) {
                $lineTotal = $item['unit_price'] * $item['quantity'];
                $variantLabel = $item['variant_id'] ? ($item['attribute_name'] . ': ' . $item['attribute_value']) : null;

                $pdo->prepare("INSERT INTO order_items (order_id, product_id, variant_id, variant_label, quantity, unit_price, buying_price_at_sale, item_discount, line_total) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)")
                    ->execute([$orderId, $item['product_id'], $item['variant_id'], $variantLabel, $item['quantity'], $item['unit_price'], $item['buying_price'], $lineTotal]);

                if ($item['variant_id']) {
                    $pdo->prepare("UPDATE product_variants SET stock_quantity = stock_quantity - ? WHERE id = ?")
                        ->execute([$item['quantity'], $item['variant_id']]);
                } else {
                    $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?")
                        ->execute([$item['quantity'], $item['product_id']]);
                }
            }

            $pdo->prepare("DELETE FROM cart_items WHERE customer_id = ?")->execute([$_SESSION['user_id']]);

            $pdo->commit();

            header("Location: order_success.php?order=" . urlencode($orderNumber));
            exit;
        }
    }
}

$pageTitle = "Checkout";
include '../includes/customer_header.php';
?>

<h1 style="margin-bottom:20px;">Checkout</h1>

<?php if ($error): ?><div class="gff-error"><?php echo $error; ?></div><?php endif; ?>

<div class="gff-shop-layout">
    <div class="gff-product-grid-area">
        <div class="gff-section">
            <h2>Delivery Address</h2>
            <form method="POST" id="checkoutForm">
                <div class="gff-form-inline" style="flex-direction:column; align-items:stretch;">
                    <div class="field">
                        <label>Address / Street</label>
                        <input type="text" name="address_line" placeholder="e.g. 123 Moi Avenue" required style="min-width:100%;">
                    </div>
                    <div class="field">
                        <label>Town / City</label>
                        <input type="text" name="city" placeholder="e.g. Nairobi" required style="min-width:100%;">
                    </div>
                    <div class="field">
                        <label>Phone Number</label>
                        <input type="text" name="phone" placeholder="e.g. 07XXXXXXXX" required style="min-width:100%;">
                    </div>
                    <div class="field">
                        <label>Delivery Notes (optional)</label>
                        <input type="text" name="notes" placeholder="e.g. Landmark, gate code..." style="min-width:100%;">
                    </div>
                </div>
            </form>
        </div>

        <div class="gff-section">
            <h2>Order Items</h2>
            <table class="gff-table">
                <tr><th>Product</th><th>Qty</th><th>Price</th><th>Total</th></tr>
                <?php foreach ($cartItems as $item): ?>
                <tr>
                    <td>
                        <?php echo clean($item['name']); ?>
                        <?php if ($item['variant_id']): ?>
                            <br><span style="color:var(--text-muted); font-size:12px;"><?php echo clean($item['attribute_name']); ?>: <?php echo clean($item['attribute_value']); ?></span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>KSh <?php echo number_format($item['unit_price'], 2); ?></td>
                    <td>KSh <?php echo number_format($item['unit_price'] * $item['quantity'], 2); ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>

    <div style="width:300px; flex-shrink:0;">
        <div class="gff-order-summary">
            <h3 style="margin-bottom:16px;">Order Summary</h3>
            <div class="row"><span>Subtotal</span><span>KSh <?php echo number_format($subtotal, 2); ?></span></div>
            <div class="row"><span>Delivery</span><span>Pay on confirmation</span></div>
            <div class="row total"><span>Total</span><span>KSh <?php echo number_format($subtotal, 2); ?></span></div>
            <button type="submit" form="checkoutForm" class="gff-btn" style="width:100%; margin-top:10px;">Place Order</button>
            <p style="font-size:11px; color:var(--text-muted); margin-top:10px;">
                Any discounts will be applied by our team when confirming your order. Payment is confirmed after order review.
            </p>
        </div>
    </div>
</div>

<?php include '../includes/customer_footer.php'; ?>
