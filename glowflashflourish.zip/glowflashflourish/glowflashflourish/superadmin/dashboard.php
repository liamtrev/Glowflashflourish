<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['superadmin']);

$pageTitle = "Super Admin Dashboard";
include '../includes/header.php';
?>

<div class="gff-nav">
    <a href="users.php">Manage Admin & Staff Accounts</a>
</div>

<h1>Welcome, <?php echo clean($_SESSION['full_name']); ?> (Super Admin)</h1>
<p style="color:var(--text-muted); margin-top:8px;">
    This is where you'll manage Admin accounts and system-wide settings.
</p>

<div style="margin-top:24px;">
    <div class="gff-card card-teal">
        <h3>Total Admins</h3>
        <div class="value">--</div>
    </div>
    <div class="gff-card card-gold">
        <h3>Total Shops (future multi-branch)</h3>
        <div class="value">1</div>
    </div>
    <div class="gff-card card-pink">
        <h3>System Status</h3>
        <div class="value">OK</div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
