<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = clean($_POST['full_name']);
    $email = clean($_POST['email']);
    $phone = clean($_POST['phone']);
    $password = $_POST['password'];

    if (empty($full_name) || empty($email) || empty($password)) {
        $error = "Please fill in all required fields.";
    } else {
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);

        if ($check->fetch()) {
            $error = "An account with that email already exists.";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (full_name, email, phone, password, role) VALUES (?, ?, ?, ?, 'customer')");
            $stmt->execute([$full_name, $email, $phone, $hashed]);

            header("Location: login.php?registered=1");
            exit;
        }
    }
}

$pageTitle = "Register";
include '../includes/header.php';
?>

<div class="gff-form">
    <h2>Create your account</h2>
    <?php if ($error): ?>
        <div class="gff-error"><?php echo $error; ?></div>
    <?php endif; ?>
    <form method="POST">
        <input type="text" name="full_name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="phone" placeholder="Phone (optional)">
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Register</button>
    </form>
    <p style="margin-top:14px; color:var(--text-muted);">
        Already have an account? <a href="login.php" style="color:var(--accent-teal);">Login here</a>
    </p>
</div>

<?php include '../includes/footer.php'; ?>
