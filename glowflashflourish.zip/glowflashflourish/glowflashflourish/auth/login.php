<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = clean($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        if ($user['status'] === 'disabled') {
            $error = "This account has been disabled. Contact the shop admin.";
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];

            switch ($user['role']) {
                case 'superadmin':
                    header("Location: " . BASE_URL . "superadmin/dashboard.php");
                    break;
                case 'admin':
                case 'staff':
                    header("Location: " . BASE_URL . "admin/dashboard.php");
                    break;
                default:
                    header("Location: " . BASE_URL . "customer/dashboard.php");
            }
            exit;
        }
    } else {
        $error = "Invalid email or password.";
    }
}

$pageTitle = "Login";
include '../includes/header.php';
?>

<div class="gff-form">
    <h2>Login to GFF</h2>
    <?php if (isset($_GET['registered'])): ?>
        <div style="background:var(--status-confirmed); padding:10px; border-radius:6px; margin-bottom:14px;">
            Account created! Please log in.
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="gff-error"><?php echo $error; ?></div>
    <?php endif; ?>
    <form method="POST">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
    <p style="margin-top:14px; color:var(--text-muted);">
        No account? <a href="register.php" style="color:var(--accent-teal);">Register here</a>
    </p>
</div>

<?php include '../includes/footer.php'; ?>
