<?php
// Starts the session for every page that includes this file.
session_start();

define('SITE_NAME', 'Glow Flash Flourish and Smile');
define('ORDER_PREFIX', 'GFF');

// Base URL - update if your folder name in htdocs is different
define('BASE_URL', 'http://localhost/glowflashflourish/');
