<?php
// Redirects a user if they are not logged in.
function require_login() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: " . BASE_URL . "auth/login.php");
        exit;
    }
}

// Redirects a user if they don't have one of the allowed roles.
function require_role($allowed_roles = []) {
    require_login();
    if (!in_array($_SESSION['role'], $allowed_roles)) {
        die("Access denied: you don't have permission to view this page.");
    }
}

// Basic input cleanup.
function clean($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Returns the price a customer actually pays after any flat discount_amount is subtracted.
function get_effective_price($product) {
    $discount = isset($product['discount_amount']) ? (float) $product['discount_amount'] : 0;
    $price = (float) $product['selling_price'] - $discount;
    return $price > 0 ? $price : 0;
}

// Fetches all variant rows for a product (Color/Type/Litres/Dimensions etc.)
function get_product_variants($pdo, $productId) {
    $stmt = $pdo->prepare("SELECT * FROM product_variants WHERE product_id = ? ORDER BY attribute_name ASC, attribute_value ASC");
    $stmt->execute([$productId]);
    return $stmt->fetchAll();
}

// Total available stock for a product: sums variant stock if any exist, else the product's own stock_quantity.
function get_product_total_stock($pdo, $product) {
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(stock_quantity),0) as total FROM product_variants WHERE product_id = ?");
    $stmt->execute([$product['id']]);
    $variantStock = (int) $stmt->fetch()['total'];

    $hasVariants = $pdo->prepare("SELECT COUNT(*) as cnt FROM product_variants WHERE product_id = ?");
    $hasVariants->execute([$product['id']]);
    if ($hasVariants->fetch()['cnt'] > 0) {
        return $variantStock;
    }
    return (int) $product['stock_quantity'];
}

// Effective price for one specific variant (base effective price + that variant's adjustment)
function get_variant_price($product, $variant) {
    $base = get_effective_price($product);
    $adjustment = $variant ? (float) $variant['price_adjustment'] : 0;
    $price = $base + $adjustment;
    return $price > 0 ? $price : 0;
}

// Generates the next order number in the format GFF/DDMMYYYY/001,
// resetting the counter to 001 automatically at midnight (new date row).
function generate_order_number($pdo) {
    $today = date('Y-m-d');       // used internally as the unique key
    $displayDate = date('dmY');   // used in the visible order number

    $prefixRow = $pdo->query("SELECT order_prefix FROM settings LIMIT 1")->fetch();
    $prefix = $prefixRow && !empty($prefixRow['order_prefix']) ? $prefixRow['order_prefix'] : ORDER_PREFIX;

    $pdo->beginTransaction();

    $stmt = $pdo->prepare("SELECT * FROM order_number_sequence WHERE sequence_date = ? FOR UPDATE");
    $stmt->execute([$today]);
    $row = $stmt->fetch();

    if ($row) {
        $nextNumber = $row['last_number'] + 1;
        $update = $pdo->prepare("UPDATE order_number_sequence SET last_number = ? WHERE sequence_date = ?");
        $update->execute([$nextNumber, $today]);
    } else {
        $nextNumber = 1;
        $insert = $pdo->prepare("INSERT INTO order_number_sequence (sequence_date, last_number) VALUES (?, ?)");
        $insert->execute([$today, $nextNumber]);
    }

    $pdo->commit();

    $paddedNumber = str_pad($nextNumber, 3, '0', STR_PAD_LEFT); // 001-999
    return $prefix . '/' . $displayDate . '/' . $paddedNumber;
}
