        </main>
        <footer class="gff-footer">
            <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
        </footer>
    </div>
</div>
<script src="<?php echo BASE_URL; ?>assets/js/admin.js"></script>
<script src="<?php echo BASE_URL; ?>assets/js/lightbox.js"></script>
</body>
</html>
