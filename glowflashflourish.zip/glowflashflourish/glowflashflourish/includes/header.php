<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - ' . SITE_NAME : SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
</head>
<body>
<div class="gff-toast-container" id="toastContainer"></div>
<header class="gff-header">
    <div class="gff-logo"><?php echo SITE_NAME; ?></div>
    <?php if (isset($_SESSION['user_id'])): ?>
        <div class="gff-user">
            <span><?php echo clean($_SESSION['full_name']); ?> (<?php echo clean($_SESSION['role']); ?>)</span>
            <a href="<?php echo BASE_URL; ?>auth/logout.php" class="gff-btn-logout">Logout</a>
        </div>
    <?php endif; ?>
</header>
<main class="gff-main">
