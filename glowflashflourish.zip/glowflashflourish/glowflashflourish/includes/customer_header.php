<?php
// Requires: $pdo, active session, $pageTitle set by including page.
$cartCount = 0;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(quantity),0) as cnt FROM cart_items WHERE customer_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $cartCount = $stmt->fetch()['cnt'];
}
$topLevelNav = $pdo->query("SELECT * FROM categories WHERE parent_id IS NULL ORDER BY name ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $pageTitle . ' - ' . SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
</head>
<body>

<div class="gff-toast-container" id="toastContainer"></div>

<header class="gff-shop-topbar">
    <a href="<?php echo BASE_URL; ?>customer/shop.php" class="gff-logo"><?php echo SITE_NAME; ?></a>

    <form class="gff-shop-search" method="GET" action="<?php echo BASE_URL; ?>customer/shop.php">
        <input type="text" name="q" placeholder="Search products..." value="<?php echo isset($_GET['q']) ? clean($_GET['q']) : ''; ?>">
        <button type="submit">&#128269;</button>
    </form>

    <div class="gff-shop-icons">
        <a href="<?php echo BASE_URL; ?>customer/cart.php" class="gff-icon-btn" title="Cart">
            &#128722;
            <?php if ($cartCount > 0): ?><span class="gff-icon-badge" id="cartBadge"><?php echo $cartCount; ?></span><?php endif; ?>
        </a>
        <a href="<?php echo BASE_URL; ?>customer/orders.php" class="gff-icon-btn" title="My Orders">&#128230;</a>
        <a href="<?php echo BASE_URL; ?>customer/dashboard.php" class="gff-icon-btn" title="My Account">&#128100;</a>
        <a href="<?php echo BASE_URL; ?>auth/logout.php" class="gff-btn-logout">Logout</a>
    </div>
</header>

<nav class="gff-category-nav">
    <a href="<?php echo BASE_URL; ?>customer/shop.php">All Products</a>
    <?php foreach ($topLevelNav as $cat): ?>
        <a href="<?php echo BASE_URL; ?>customer/shop.php?category=<?php echo $cat['id']; ?>"><?php echo clean($cat['name']); ?></a>
    <?php endforeach; ?>
</nav>

<main class="gff-shop-main">
