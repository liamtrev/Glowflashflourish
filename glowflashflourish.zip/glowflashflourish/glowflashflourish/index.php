<?php
require_once 'config/config.php';

if (isset($_SESSION['user_id'])) {
    switch ($_SESSION['role']) {
        case 'superadmin':
            header("Location: " . BASE_URL . "superadmin/dashboard.php");
            break;
        case 'admin':
        case 'staff':
            header("Location: " . BASE_URL . "admin/dashboard.php");
            break;
        default:
            header("Location: " . BASE_URL . "customer/dashboard.php");
    }
} else {
    header("Location: " . BASE_URL . "auth/login.php");
}
exit;
