-- =========================================================
-- Glow Flash Flourish and Smile (GFF) - Database Schema
-- Import this in phpMyAdmin: create a DB called `gff_db`,
-- then Import > select this file.
-- =========================================================

CREATE DATABASE IF NOT EXISTS gff_db;
USE gff_db;

-- ---------------------------------------------------------
-- USERS (Super Admin, Admin, Staff, Customer all live here)
-- ---------------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20) DEFAULT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('superadmin','admin','staff','customer') NOT NULL DEFAULT 'customer',
    status ENUM('active','disabled') NOT NULL DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- One Super Admin seeded by default (change password after first login!)
-- Password below is: Admin@123  (bcrypt hash, verified working with PHP's password_verify())
INSERT INTO users (full_name, email, password, role)
VALUES ('Super Admin', 'superadmin@gff.com', '$2b$10$xTiJ2xX62jFLH/9eo6WZRucrQFOenTZq5OROc5RMYbVlYuD2Eeo3W', 'superadmin');

-- ---------------------------------------------------------
-- CATEGORIES (supports 1 level of subcategories via parent_id)
-- ---------------------------------------------------------
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    parent_id INT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE CASCADE
);

INSERT INTO categories (name) VALUES
('Textiles'),
('Furniture - Plastic Chairs & Tables'),
('Kitchenware'),
('Shoes'),
('Stationery'),
('Clothing');

-- Subcategories under Clothing
INSERT INTO categories (name, parent_id) VALUES
('Men', (SELECT id FROM (SELECT id FROM categories WHERE name='Clothing') AS t)),
('Women', (SELECT id FROM (SELECT id FROM categories WHERE name='Clothing') AS t)),
('Kids', (SELECT id FROM (SELECT id FROM categories WHERE name='Clothing') AS t)),
('Uniforms', (SELECT id FROM (SELECT id FROM categories WHERE name='Clothing') AS t));

-- Subcategories under Shoes
INSERT INTO categories (name, parent_id) VALUES
('Men', (SELECT id FROM (SELECT id FROM categories WHERE name='Shoes') AS t)),
('Women', (SELECT id FROM (SELECT id FROM categories WHERE name='Shoes') AS t)),
('Kids', (SELECT id FROM (SELECT id FROM categories WHERE name='Shoes') AS t));

-- ---------------------------------------------------------
-- PRODUCTS
-- ---------------------------------------------------------
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    buying_price DECIMAL(10,2) NOT NULL,
    selling_price DECIMAL(10,2) NOT NULL,
    discount_amount DECIMAL(10,2) DEFAULT 0,
    is_clearance TINYINT(1) NOT NULL DEFAULT 0,
    stock_quantity INT NOT NULL DEFAULT 0,
    low_stock_threshold INT NOT NULL DEFAULT 5,
    image VARCHAR(255) DEFAULT NULL,
    created_by INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- ---------------------------------------------------------
-- PRODUCT VARIANTS (Color, Type, Litres, Dimensions, etc.)
-- Each row = one attribute+value option with its own stock.
-- ---------------------------------------------------------
CREATE TABLE product_variants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    attribute_name VARCHAR(50) NOT NULL,
    attribute_value VARCHAR(100) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    price_adjustment DECIMAL(10,2) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- ORDER NUMBER SEQUENCE (tracks daily counter + resets at midnight)
-- ---------------------------------------------------------
CREATE TABLE order_number_sequence (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sequence_date DATE NOT NULL UNIQUE,
    last_number INT NOT NULL DEFAULT 0
);

-- ---------------------------------------------------------
-- ORDERS
-- ---------------------------------------------------------
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(30) NOT NULL UNIQUE,   -- e.g. GFF/19072026/001
    customer_id INT NOT NULL,
    delivery_address VARCHAR(255) DEFAULT NULL,
    status ENUM('pending','completed','cancelled','refunded') NOT NULL DEFAULT 'pending',
    payment_status ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid',
    discount_type ENUM('none','grand_total','per_item') NOT NULL DEFAULT 'none',
    discount_mode ENUM('percentage','fixed') DEFAULT 'fixed',
    discount_value DECIMAL(10,2) DEFAULT 0,     -- % or fixed, applied per discount_type
    subtotal DECIMAL(10,2) NOT NULL DEFAULT 0,
    discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    grand_total DECIMAL(10,2) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(id)
);

-- ---------------------------------------------------------
-- ORDER ITEMS
-- ---------------------------------------------------------
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    variant_id INT NULL,
    variant_label VARCHAR(150) NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    buying_price_at_sale DECIMAL(10,2) DEFAULT 0, -- snapshot so profit reports stay accurate later
    item_discount DECIMAL(10,2) DEFAULT 0,      -- used when discount_type = per_item
    line_total DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- ---------------------------------------------------------
-- SHOPPING CART
-- ---------------------------------------------------------
CREATE TABLE cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    variant_id INT NULL,
    quantity INT NOT NULL DEFAULT 1,
    added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_cart_item (customer_id, product_id, variant_id),
    FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- SETTINGS (shop details, single row)
-- ---------------------------------------------------------
CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    shop_name VARCHAR(150) DEFAULT 'Glow Flash Flourish and Smile',
    logo VARCHAR(255) DEFAULT NULL,
    contact_email VARCHAR(150) DEFAULT NULL,
    contact_phone VARCHAR(20) DEFAULT NULL,
    order_prefix VARCHAR(10) DEFAULT 'GFF'
);

INSERT INTO settings (shop_name, order_prefix) VALUES ('Glow Flash Flourish and Smile', 'GFF');
