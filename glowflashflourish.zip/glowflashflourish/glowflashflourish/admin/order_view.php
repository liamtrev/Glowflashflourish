<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['admin', 'staff']);

$orderId = (int) ($_GET['id'] ?? 0);
$success = '';
$error = '';

$stmt = $pdo->prepare("SELECT o.*, u.full_name as customer_name, u.email as customer_email, u.phone as customer_phone FROM orders o JOIN users u ON u.id = o.customer_id WHERE o.id = ?");
$stmt->execute([$orderId]);
$order = $stmt->fetch();

if (!$order) {
    die("Order not found.");
}

// ---------- APPLY DISCOUNT (grand total mode) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'apply_grand_discount') {
    $discountMode = $_POST['discount_mode']; // percentage | fixed
    $discountValue = (float) $_POST['discount_value'];

    $itemsSubtotal = $pdo->prepare("SELECT COALESCE(SUM(unit_price * quantity),0) as subtotal FROM order_items WHERE order_id = ?");
    $itemsSubtotal->execute([$orderId]);
    $subtotal = $itemsSubtotal->fetch()['subtotal'];

    $discountAmount = $discountMode === 'percentage' ? ($subtotal * $discountValue / 100) : $discountValue;
    $discountAmount = min($discountAmount, $subtotal); // never discount below 0
    $grandTotal = $subtotal - $discountAmount;

    // Reset any per-item discounts since we're using grand-total mode now
    $pdo->prepare("UPDATE order_items SET item_discount = 0, line_total = unit_price * quantity WHERE order_id = ?")->execute([$orderId]);

    $pdo->prepare("UPDATE orders SET discount_type='grand_total', discount_mode=?, discount_value=?, subtotal=?, discount_amount=?, grand_total=? WHERE id=?")
        ->execute([$discountMode, $discountValue, $subtotal, $discountAmount, $grandTotal, $orderId]);

    $success = "Grand total discount applied.";
}

// ---------- APPLY DISCOUNT (per item mode) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'apply_item_discounts') {
    $itemDiscounts = $_POST['item_discount'] ?? []; // [item_id => percent]

    $subtotal = 0;
    $grandTotal = 0;

    foreach ($itemDiscounts as $itemId => $pct) {
        $pct = max(0, min(100, (float) $pct));
        $itemStmt = $pdo->prepare("SELECT unit_price, quantity FROM order_items WHERE id = ? AND order_id = ?");
        $itemStmt->execute([(int) $itemId, $orderId]);
        $item = $itemStmt->fetch();
        if ($item) {
            $lineOriginal = $item['unit_price'] * $item['quantity'];
            $lineTotal = $lineOriginal * (1 - $pct / 100);
            $pdo->prepare("UPDATE order_items SET item_discount = ?, line_total = ? WHERE id = ?")
                ->execute([$pct, $lineTotal, (int) $itemId]);
            $subtotal += $lineOriginal;
            $grandTotal += $lineTotal;
        }
    }

    $discountAmount = $subtotal - $grandTotal;
    $pdo->prepare("UPDATE orders SET discount_type='per_item', discount_mode='percentage', discount_value=0, subtotal=?, discount_amount=?, grand_total=? WHERE id=?")
        ->execute([$subtotal, $discountAmount, $grandTotal, $orderId]);

    $success = "Per-item discounts applied.";
}

// ---------- MARK PAID / UNPAID ----------
if (isset($_GET['mark_paid'])) {
    $pdo->prepare("UPDATE orders SET payment_status = 'paid' WHERE id = ?")->execute([$orderId]);
    header("Location: order_view.php?id=$orderId&msg=" . urlencode("Order marked as paid."));
    exit;
}
if (isset($_GET['mark_unpaid'])) {
    $pdo->prepare("UPDATE orders SET payment_status = 'unpaid' WHERE id = ?")->execute([$orderId]);
    header("Location: order_view.php?id=$orderId&msg=" . urlencode("Order marked as unpaid."));
    exit;
}

// ---------- CHANGE STATUS ----------
if (isset($_GET['set_status'])) {
    $newStatus = $_GET['set_status'];
    if (in_array($newStatus, ['pending', 'completed', 'cancelled', 'refunded'])) {
        // If cancelling/refunding a previously non-cancelled order, restock the items
        if (in_array($newStatus, ['cancelled', 'refunded']) && !in_array($order['status'], ['cancelled', 'refunded'])) {
            $items = $pdo->prepare("SELECT product_id, variant_id, quantity FROM order_items WHERE order_id = ?");
            $items->execute([$orderId]);
            foreach ($items->fetchAll() as $it) {
                if ($it['variant_id']) {
                    $pdo->prepare("UPDATE product_variants SET stock_quantity = stock_quantity + ? WHERE id = ?")->execute([$it['quantity'], $it['variant_id']]);
                } else {
                    $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity + ? WHERE id = ?")->execute([$it['quantity'], $it['product_id']]);
                }
            }
        }
        $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?")->execute([$newStatus, $orderId]);
    }
    header("Location: order_view.php?id=$orderId&msg=" . urlencode("Order status updated to " . ucfirst($newStatus) . "."));
    exit;
}

if (isset($_GET['msg'])) {
    $success = clean($_GET['msg']);
}

// Refresh order + items after any action
$stmt = $pdo->prepare("SELECT o.*, u.full_name as customer_name, u.email as customer_email, u.phone as customer_phone FROM orders o JOIN users u ON u.id = o.customer_id WHERE o.id = ?");
$stmt->execute([$orderId]);
$order = $stmt->fetch();

$itemsStmt = $pdo->prepare("SELECT oi.*, p.name FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ?");
$itemsStmt->execute([$orderId]);
$items = $itemsStmt->fetchAll();

$pageTitle = "Order " . $order['order_number'];
$activeNav = "orders";
include '../includes/admin_header.php';
?>

<div class="gff-nav">
    <a href="orders.php">&larr; Back to Orders</a>
    <a href="receipt.php?id=<?php echo $orderId; ?>" target="_blank">Print Receipt</a>
</div>

<?php if ($success): ?><div class="gff-success-msg"><?php echo $success; ?></div><?php endif; ?>
<?php if ($error): ?><div class="gff-error"><?php echo $error; ?></div><?php endif; ?>

<div class="gff-section">
    <h2>Order <?php echo clean($order['order_number']); ?></h2>
    <p style="color:var(--text-muted); margin-top:6px;">
        Customer: <?php echo clean($order['customer_name']); ?> (<?php echo clean($order['customer_email']); ?>)<br>
        Delivery: <?php echo clean($order['delivery_address'] ?? 'N/A'); ?><br>
        Placed: <?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?>
    </p>

    <div style="margin-top:14px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
        <span>Status:
            <?php $badgeClass = ['pending' => 'badge-pending', 'completed' => 'badge-completed', 'cancelled' => 'badge-cancelled', 'refunded' => 'badge-refund'][$order['status']]; ?>
            <span class="badge <?php echo $badgeClass; ?>"><?php echo ucfirst($order['status']); ?></span>
        </span>
        <span>Payment:
            <span class="badge <?php echo $order['payment_status'] === 'paid' ? 'badge-confirmed' : 'badge-pending'; ?>"><?php echo ucfirst($order['payment_status']); ?></span>
        </span>

        <?php if ($order['payment_status'] === 'unpaid'): ?>
            <a href="?id=<?php echo $orderId; ?>&mark_paid=1" class="gff-btn gff-btn-small gff-btn-success">Mark as Paid</a>
        <?php else: ?>
            <a href="?id=<?php echo $orderId; ?>&mark_unpaid=1" class="gff-btn gff-btn-small gff-btn-outline">Mark as Unpaid</a>
        <?php endif; ?>

        <?php if ($order['status'] === 'pending'): ?>
            <a href="?id=<?php echo $orderId; ?>&set_status=completed" class="gff-btn gff-btn-small gff-btn-success gff-confirm-action"
               data-confirm="Confirm this order as completed?">Confirm Order</a>
            <a href="?id=<?php echo $orderId; ?>&set_status=cancelled" class="gff-btn gff-btn-small gff-btn-danger gff-confirm-action"
               data-confirm="Cancel this order? Stock will be restored.">Cancel Order</a>
        <?php elseif ($order['status'] === 'completed'): ?>
            <a href="?id=<?php echo $orderId; ?>&set_status=refunded" class="gff-btn gff-btn-small gff-btn-danger gff-confirm-action"
               data-confirm="Mark this order as refunded? Stock will be restored.">Refund Order</a>
        <?php endif; ?>
    </div>
</div>

<div class="gff-section">
    <h2>Order Items</h2>
    <table class="gff-table">
        <tr><th>Product</th><th>Qty</th><th>Unit Price</th><th>Item Discount %</th><th>Line Total</th></tr>
        <?php foreach ($items as $it): ?>
        <tr>
            <td>
                <?php echo clean($it['name']); ?>
                <?php if (!empty($it['variant_label'])): ?>
                    <br><span style="color:var(--text-muted); font-size:12px;"><?php echo clean($it['variant_label']); ?></span>
                <?php endif; ?>
            </td>
            <td><?php echo $it['quantity']; ?></td>
            <td>KSh <?php echo number_format($it['unit_price'], 2); ?></td>
            <td><?php echo number_format($it['item_discount'], 1); ?>%</td>
            <td>KSh <?php echo number_format($it['line_total'], 2); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <div style="text-align:right; margin-top:14px; font-size:14px;">
        <div>Subtotal: KSh <?php echo number_format($order['subtotal'], 2); ?></div>
        <div style="color:var(--status-cancelled);">Discount: -KSh <?php echo number_format($order['discount_amount'], 2); ?></div>
        <div style="font-weight:bold; font-size:18px; color:var(--accent-teal);">Grand Total: KSh <?php echo number_format($order['grand_total'], 2); ?></div>
    </div>
</div>

<?php if ($order['status'] === 'pending'): ?>
<div class="gff-section">
    <h2>Apply Discount</h2>

    <h3 style="font-size:14px; margin-bottom:10px;">Option A: Discount on Grand Total</h3>
    <form method="POST" class="gff-form-inline" style="margin-bottom:24px;">
        <input type="hidden" name="action" value="apply_grand_discount">
        <div class="field">
            <label>Type</label>
            <select name="discount_mode">
                <option value="percentage">Percentage (%)</option>
                <option value="fixed">Fixed Amount (KSh)</option>
            </select>
        </div>
        <div class="field">
            <label>Value</label>
            <input type="number" step="0.01" min="0" name="discount_value" required>
        </div>
        <button type="submit" class="gff-btn">Apply to Grand Total</button>
    </form>

    <h3 style="font-size:14px; margin-bottom:10px;">Option B: Discount Per Item (%)</h3>
    <form method="POST">
        <input type="hidden" name="action" value="apply_item_discounts">
        <table class="gff-table">
            <tr><th>Product</th><th>Qty</th><th>Unit Price</th><th>Discount %</th></tr>
            <?php foreach ($items as $it): ?>
            <tr>
                <td><?php echo clean($it['name']); ?></td>
                <td><?php echo $it['quantity']; ?></td>
                <td>KSh <?php echo number_format($it['unit_price'], 2); ?></td>
                <td>
                    <input type="number" step="0.1" min="0" max="100" name="item_discount[<?php echo $it['id']; ?>]" value="<?php echo $it['item_discount']; ?>" style="width:80px; padding:6px; border-radius:6px; border:none; background:#2A3140; color:var(--text-main);">
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <button type="submit" class="gff-btn" style="margin-top:14px;">Apply Per-Item Discounts</button>
    </form>
</div>
<?php endif; ?>

<?php include '../includes/admin_footer.php'; ?>
