<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['admin', 'staff']);

// ---------- OVERVIEW NUMBERS ----------
$totalProducts = $pdo->query("SELECT COUNT(*) as cnt FROM products")->fetch()['cnt'];
$totalCategories = $pdo->query("SELECT COUNT(*) as cnt FROM categories WHERE parent_id IS NULL")->fetch()['cnt'];
$lowStockCount = $pdo->query("SELECT COUNT(*) as cnt FROM products WHERE stock_quantity <= low_stock_threshold")->fetch()['cnt'];
$stockValue = $pdo->query("SELECT COALESCE(SUM(stock_quantity * selling_price),0) as val FROM products")->fetch()['val'];

// ---------- PRODUCTS + STOCK GROUPED BY TOP-LEVEL CATEGORY ----------
$categoryStats = $pdo->query("
    SELECT COALESCE(parent.id, c.id) as top_id,
           COALESCE(parent.name, c.name) as top_name,
           COUNT(p.id) as product_count,
           COALESCE(SUM(p.stock_quantity), 0) as total_stock
    FROM categories c
    LEFT JOIN categories parent ON c.parent_id = parent.id
    LEFT JOIN products p ON p.category_id = c.id
    GROUP BY top_id, top_name
    ORDER BY top_name ASC
")->fetchAll();

$chartColors = ['#00E6A0', '#FFD23F', '#FF6EC7', '#2E6BFF', '#9B6BFF', '#FF9F45'];

// Build donut chart (conic-gradient) based on product_count
$totalProductsForChart = array_sum(array_column($categoryStats, 'product_count'));
$conicStops = [];
$cumulative = 0;
foreach ($categoryStats as $i => $cat) {
    $pct = $totalProductsForChart > 0 ? ($cat['product_count'] / $totalProductsForChart) * 100 : 0;
    $color = $chartColors[$i % count($chartColors)];
    $start = $cumulative;
    $end = $cumulative + $pct;
    $conicStops[] = "$color {$start}% {$end}%";
    $cumulative = $end;
}
$donutStyle = !empty($conicStops) ? "background: conic-gradient(" . implode(', ', $conicStops) . ");" : "background: #2A3140;";

// Bar chart max (stock)
$maxStock = 0;
foreach ($categoryStats as $cat) {
    if ($cat['total_stock'] > $maxStock) $maxStock = $cat['total_stock'];
}
if ($maxStock == 0) $maxStock = 1;

// ---------- RECENT PRODUCTS ----------
$recentProducts = $pdo->query("
    SELECT p.*, c.name as category_name
    FROM products p JOIN categories c ON p.category_id = c.id
    ORDER BY p.created_at DESC LIMIT 5
")->fetchAll();

$pageTitle = "Dashboard";
$activeNav = "dashboard";
include '../includes/admin_header.php';
?>

<div class="gff-overview">
    <div class="gff-overview-card">
        <div class="gff-overview-icon" style="color:var(--accent-teal);">&#128230;</div>
        <div class="gff-overview-text">
            <div class="label">Total Products</div>
            <div class="value"><?php echo $totalProducts; ?></div>
        </div>
    </div>
    <div class="gff-overview-card">
        <div class="gff-overview-icon" style="color:var(--accent-gold);">&#128193;</div>
        <div class="gff-overview-text">
            <div class="label">Categories</div>
            <div class="value"><?php echo $totalCategories; ?></div>
        </div>
    </div>
    <div class="gff-overview-card">
        <div class="gff-overview-icon" style="color:var(--status-cancelled);">&#9888;</div>
        <div class="gff-overview-text">
            <div class="label">Low Stock Items</div>
            <div class="value"><?php echo $lowStockCount; ?></div>
        </div>
    </div>
    <div class="gff-overview-card">
        <div class="gff-overview-icon" style="color:var(--accent-pink);">&#128176;</div>
        <div class="gff-overview-text">
            <div class="label">Stock Value (KSh)</div>
            <div class="value"><?php echo number_format($stockValue, 0); ?></div>
        </div>
    </div>
</div>

<div class="gff-chart-row">
    <div class="gff-chart-panel">
        <h3>Products by Category</h3>
        <div class="gff-donut-wrap">
            <div class="gff-donut" style="<?php echo $donutStyle; ?>"></div>
            <ul class="gff-legend">
                <?php foreach ($categoryStats as $i => $cat): ?>
                <li>
                    <span class="gff-legend-dot" style="background:<?php echo $chartColors[$i % count($chartColors)]; ?>;"></span>
                    <?php echo clean($cat['top_name']); ?> (<?php echo $cat['product_count']; ?>)
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <div class="gff-chart-panel">
        <h3>Stock Levels by Category</h3>
        <div class="gff-bars">
            <?php foreach ($categoryStats as $i => $cat):
                $heightPct = ($cat['total_stock'] / $maxStock) * 100;
            ?>
            <div class="gff-bar-col">
                <div class="gff-bar" style="height:<?php echo $heightPct; ?>%; background:<?php echo $chartColors[$i % count($chartColors)]; ?>;"></div>
                <div class="gff-bar-label"><?php echo clean($cat['top_name']); ?><br><?php echo $cat['total_stock']; ?> units</div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="gff-section" style="margin-top:20px;">
    <h2>Recently Added Products</h2>
    <table class="gff-table">
        <tr>
            <th>Image</th>
            <th>Product</th>
            <th>Category</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Added</th>
        </tr>
        <?php foreach ($recentProducts as $p): ?>
        <tr>
            <td>
                <?php if (!empty($p['image'])): ?>
                    <img src="<?php echo BASE_URL . $p['image']; ?>" class="gff-thumb" alt="">
                <?php else: ?>
                    <div class="gff-thumb-placeholder">No Image</div>
                <?php endif; ?>
            </td>
            <td><?php echo clean($p['name']); ?></td>
            <td><?php echo clean($p['category_name']); ?></td>
            <td>KSh <?php echo number_format($p['selling_price'], 2); ?></td>
            <td><?php echo $p['stock_quantity']; ?></td>
            <td><?php echo date('d M Y', strtotime($p['created_at'])); ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($recentProducts)): ?>
        <tr><td colspan="6" style="color:var(--text-muted);">No products added yet. <a href="products.php" style="color:var(--accent-teal);">Add your first product</a>.</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php include '../includes/admin_footer.php'; ?>
