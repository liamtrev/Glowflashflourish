<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['admin', 'staff']);

$productId = (int) ($_GET['product_id'] ?? 0);
$success = '';
$error = '';

$productStmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$productStmt->execute([$productId]);
$product = $productStmt->fetch();
if (!$product) die("Product not found.");

// ---------- ADD VARIANT ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add') {
    $attrName = clean($_POST['attribute_name']);
    $attrValue = clean($_POST['attribute_value']);
    $stock = (int) $_POST['stock_quantity'];
    $adjustment = (float) $_POST['price_adjustment'];

    if (empty($attrName) || empty($attrValue)) {
        $error = "Please fill in both the attribute name and value.";
    } else {
        $pdo->prepare("INSERT INTO product_variants (product_id, attribute_name, attribute_value, stock_quantity, price_adjustment) VALUES (?, ?, ?, ?, ?)")
            ->execute([$productId, $attrName, $attrValue, $stock, $adjustment]);
        $success = "Variant added successfully.";
    }
}

// ---------- UPDATE VARIANT ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update') {
    $variantId = (int) $_POST['variant_id'];
    $attrName = clean($_POST['attribute_name']);
    $attrValue = clean($_POST['attribute_value']);
    $stock = (int) $_POST['stock_quantity'];
    $adjustment = (float) $_POST['price_adjustment'];

    $pdo->prepare("UPDATE product_variants SET attribute_name=?, attribute_value=?, stock_quantity=?, price_adjustment=? WHERE id=? AND product_id=?")
        ->execute([$attrName, $attrValue, $stock, $adjustment, $variantId, $productId]);
    $success = "Variant updated successfully.";
}

// ---------- DELETE VARIANT ----------
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM product_variants WHERE id = ? AND product_id = ?")->execute([(int) $_GET['delete'], $productId]);
    header("Location: product_variants.php?product_id=$productId&deleted=1");
    exit;
}
if (isset($_GET['deleted'])) {
    $success = "Variant deleted successfully.";
}

$variants = get_product_variants($pdo, $productId);

$pageTitle = "Variants: " . $product['name'];
$activeNav = "products";
include '../includes/admin_header.php';
?>

<?php if ($success): ?><script>document.addEventListener('DOMContentLoaded', () => showToast(<?php echo json_encode($success); ?>, 'success'));</script><?php endif; ?>
<?php if ($error): ?><script>document.addEventListener('DOMContentLoaded', () => showToast(<?php echo json_encode($error); ?>, 'error'));</script><?php endif; ?>

<div class="gff-nav">
    <a href="products.php">&larr; Back to Products</a>
</div>

<h1>Variants for: <?php echo clean($product['name']); ?></h1>
<p style="color:var(--text-muted); margin-top:6px;">
    Add options like Color, Type, Litres, or Dimensions - each with its own stock count and, if needed, a price adjustment
    (e.g. a bigger size costs KSh 200 more - enter 200; a smaller size costs less - enter -100).
</p>

<div class="gff-section" style="margin-top:20px;">
    <h2>Add New Variant</h2>
    <form method="POST" class="gff-form-inline">
        <input type="hidden" name="action" value="add">
        <div class="field">
            <label>Attribute Name (e.g. Color, Litres, Dimensions)</label>
            <input type="text" name="attribute_name" placeholder="Color" required>
        </div>
        <div class="field">
            <label>Value (e.g. Red, 5L, 100x50cm)</label>
            <input type="text" name="attribute_value" placeholder="Red" required>
        </div>
        <div class="field">
            <label>Stock Quantity</label>
            <input type="number" min="0" name="stock_quantity" value="0" required>
        </div>
        <div class="field">
            <label>Price Adjustment (KSh, can be negative)</label>
            <input type="number" step="0.01" name="price_adjustment" value="0">
        </div>
        <button type="submit" class="gff-btn">Add Variant</button>
    </form>
</div>

<div class="gff-section">
    <h2>Existing Variants</h2>
    <table class="gff-table">
        <tr>
            <th>Attribute</th>
            <th>Value</th>
            <th>Stock</th>
            <th>Price Adjustment</th>
            <th>Final Price</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($variants as $v):
            $finalPrice = get_variant_price($product, $v);
        ?>
        <tr>
            <td><?php echo clean($v['attribute_name']); ?></td>
            <td><?php echo clean($v['attribute_value']); ?></td>
            <td><?php echo $v['stock_quantity']; ?></td>
            <td><?php echo $v['price_adjustment'] >= 0 ? '+' : ''; ?>KSh <?php echo number_format($v['price_adjustment'], 2); ?></td>
            <td>KSh <?php echo number_format($finalPrice, 2); ?></td>
            <td>
                <a href="?product_id=<?php echo $productId; ?>&delete=<?php echo $v['id']; ?>" class="gff-btn gff-btn-small gff-btn-danger gff-confirm-action"
                   data-confirm="Delete this variant?">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($variants)): ?>
        <tr><td colspan="6" style="color:var(--text-muted);">No variants yet. This product uses its own single stock count (<?php echo $product['stock_quantity']; ?>) until you add variants here.</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php include '../includes/admin_footer.php'; ?>
