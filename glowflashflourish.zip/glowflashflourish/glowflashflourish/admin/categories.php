<?php
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../includes/functions.php';
require_role(['admin', 'staff']);

$success = '';
$error = '';

// ---------- CREATE ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create') {
    $name = clean($_POST['name']);
    $parent_id = !empty($_POST['parent_id']) ? (int) $_POST['parent_id'] : null;

    if (empty($name)) {
        $error = "Category name is required.";
    } else {
        $check = $pdo->prepare("SELECT id FROM categories WHERE name = ? AND (parent_id <=> ?)");
        $check->execute([$name, $parent_id]);
        if ($check->fetch()) {
            $error = "That category/subcategory already exists in this location.";
        } else {
            $pdo->prepare("INSERT INTO categories (name, parent_id) VALUES (?, ?)")->execute([$name, $parent_id]);
            $success = $parent_id ? "Subcategory added successfully." : "Category added successfully.";
        }
    }
}

// ---------- UPDATE ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    $id = (int) $_POST['id'];
    $name = clean($_POST['name']);
    $parent_id = !empty($_POST['parent_id']) ? (int) $_POST['parent_id'] : null;

    if ($parent_id === $id) {
        $error = "A category cannot be its own parent.";
    } elseif (!empty($name)) {
        $pdo->prepare("UPDATE categories SET name = ?, parent_id = ? WHERE id = ?")->execute([$name, $parent_id, $id]);
        $success = "Category updated successfully.";
    }
}

// ---------- DELETE ----------
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $checkProducts = $pdo->prepare("SELECT COUNT(*) as cnt FROM products WHERE category_id = ?");
    $checkProducts->execute([$id]);
    $checkChildren = $pdo->prepare("SELECT COUNT(*) as cnt FROM categories WHERE parent_id = ?");
    $checkChildren->execute([$id]);

    if ($checkProducts->fetch()['cnt'] > 0) {
        $error = "Cannot delete - this category still has products assigned to it.";
    } elseif ($checkChildren->fetch()['cnt'] > 0) {
        $error = "Cannot delete - this category still has subcategories. Delete or reassign those first.";
    } else {
        $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
        header("Location: categories.php?deleted=1");
        exit;
    }
}
if (isset($_GET['deleted'])) {
    $success = "Category deleted successfully.";
}

// ---------- FETCH FOR EDIT ----------
$editCategory = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->execute([(int) $_GET['edit']]);
    $editCategory = $stmt->fetch();
}

// ---------- FETCH ALL (with product counts), build hierarchy ----------
$allCategories = $pdo->query("
    SELECT c.*, COUNT(p.id) as product_count
    FROM categories c
    LEFT JOIN products p ON p.category_id = c.id
    GROUP BY c.id
    ORDER BY c.parent_id IS NULL DESC, c.name ASC
")->fetchAll();

$topLevel = array_filter($allCategories, fn($c) => $c['parent_id'] === null);
$childrenByParent = [];
foreach ($allCategories as $c) {
    if ($c['parent_id'] !== null) {
        $childrenByParent[$c['parent_id']][] = $c;
    }
}

$pageTitle = "Categories";
$activeNav = "categories";
include '../includes/admin_header.php';
?>

<?php if ($success): ?><script>document.addEventListener('DOMContentLoaded', () => showToast(<?php echo json_encode($success); ?>, 'success'));</script><?php endif; ?>
<?php if ($error): ?><script>document.addEventListener('DOMContentLoaded', () => showToast(<?php echo json_encode($error); ?>, 'error'));</script><?php endif; ?>

<div class="gff-section">
    <h2><?php echo $editCategory ? 'Edit Category' : 'Add New Category or Subcategory'; ?></h2>
    <form method="POST" class="gff-form-inline">
        <input type="hidden" name="action" value="<?php echo $editCategory ? 'update' : 'create'; ?>">
        <?php if ($editCategory): ?>
            <input type="hidden" name="id" value="<?php echo $editCategory['id']; ?>">
        <?php endif; ?>
        <div class="field">
            <label>Name</label>
            <input type="text" name="name" value="<?php echo $editCategory ? clean($editCategory['name']) : ''; ?>" required>
        </div>
        <div class="field">
            <label>Parent (leave as "None" for a top-level category)</label>
            <select name="parent_id">
                <option value="">None (Top-Level Category)</option>
                <?php foreach ($topLevel as $top): ?>
                    <?php if (!$editCategory || $editCategory['id'] != $top['id']): ?>
                        <option value="<?php echo $top['id']; ?>" <?php echo ($editCategory && $editCategory['parent_id'] == $top['id']) ? 'selected' : ''; ?>>
                            <?php echo clean($top['name']); ?>
                        </option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="gff-btn"><?php echo $editCategory ? 'Save Changes' : 'Add'; ?></button>
        <?php if ($editCategory): ?>
            <a href="categories.php" class="gff-btn gff-btn-outline">Cancel</a>
        <?php endif; ?>
    </form>
</div>

<div class="gff-section">
    <h2>All Categories</h2>
    <table class="gff-table">
        <tr>
            <th>Name</th>
            <th># of Products</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($topLevel as $top): ?>
        <tr>
            <td><strong><?php echo clean($top['name']); ?></strong></td>
            <td><?php echo $top['product_count']; ?></td>
            <td>
                <a href="?edit=<?php echo $top['id']; ?>" class="gff-btn gff-btn-small gff-btn-outline">Edit</a>
                <a href="?delete=<?php echo $top['id']; ?>" class="gff-btn gff-btn-small gff-btn-danger gff-confirm-action"
                   data-confirm="Delete this category? Only works if it has no products or subcategories.">Delete</a>
            </td>
        </tr>
        <?php if (!empty($childrenByParent[$top['id']])): ?>
            <?php foreach ($childrenByParent[$top['id']] as $child): ?>
            <tr>
                <td style="padding-left:30px; color:var(--text-muted);">&mdash; <?php echo clean($child['name']); ?></td>
                <td><?php echo $child['product_count']; ?></td>
                <td>
                    <a href="?edit=<?php echo $child['id']; ?>" class="gff-btn gff-btn-small gff-btn-outline">Edit</a>
                    <a href="?delete=<?php echo $child['id']; ?>" class="gff-btn gff-btn-small gff-btn-danger gff-confirm-action"
                       data-confirm="Delete this subcategory? Only works if it has no products.">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        <?php endforeach; ?>
        <?php if (empty($topLevel)): ?>
        <tr><td colspan="3" style="color:var(--text-muted);">No categories yet.</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php include '../includes/admin_footer.php'; ?>
